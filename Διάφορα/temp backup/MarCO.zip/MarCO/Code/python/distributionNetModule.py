####################################################################################################
# 1) RUN BESTDHNS FUNCTION IN ORDER TO FIND THE BEST LOCATION TO PLACE THE DISTRIBUTION HUB NODE
# 2) RUN DISTRIBUTION_STUFF TO GET SHAPE FILES WITH EDGES/NODES AND PRINT COSTS
####################################################################################################
####################################################################################################
# IMPORT LIBS AND FILES
##########################################################################
import networkx as nx
import timeit
import csv
import sys # read variables passed from PHP exec
import json # convert a string to list of lists
import ast
import pickle

import cProfile



from all_functions import (set_new_attribute_to_nodes,change_length_attr,find_building_edges_and_update_nodes,restore_attributes,population_to_int,
akcom0_smsms_fixed_norm,norm_akcom0_smsms_fixed_norm,print_mass,akcom0_smsms_fixed_norm_max_mass_only,find_best_dhn,alphas_distribution,omhns_cl_def,
mhns_cost_d,cluster_invs_dummy22,cluster_to_subready,find_best_CO,write_shp,prepare_shapefile)



##########################################################################
# GET THE INPUTS FROM TEXTFIELDS
##########################################################################
numberOfClusters = int(sys.argv[1])
shapeFilePath =  sys.argv[2]
cap_list = json.loads("["+sys.argv[3]+"]") # THE FORMAT THAT THANASI'S CODE WORKS
cap_list_cost = json.loads("["+sys.argv[4]+"]") 
DHN_cost = int(sys.argv[5]) # INPUT - THE COST OF THE KV
lmin = int(sys.argv[6]) # MIN DISTANCE TO PLACE MANHOLE
lmax = int(sys.argv[7]) # MAX DISTANCE TO PLACE MANHOLE
mhn_cost = json.loads(sys.argv[8]) # COST OF MANHOLES BASED ON STRATEGY
PercentageOfCoverageDHN = int(sys.argv[9]) # PERCENTAGE OF COVERAGE
mhn_c_l =  json.loads(sys.argv[10])  # PARAMETERS FOR MANHOLE STRATEGY/NEW COST OF MAHOLE/LOW COST/HIGH COST MANHOLE
d =  int(sys.argv[11]) # TYPE OF STRATEGY TO BE USED FOR THE MANHOLES - VALUES: {3, 2, 1, 32, 31, 21, 321}



rr = 0.1 # values in [0,1], if it is 0 then just take the comP

##########################################################################
# GET THE CLUSTER COORDINATES FROM TEXT FILE
##########################################################################
with open('python/tmp/clusterCoords.txt' ,'rb') as f:
	cls000 = pickle.load(f)

##########################################################################
# CREATE GRAPH USING THE SHAPE FILE
##########################################################################
larissa =  nx.DiGraph.to_undirected(nx.read_shp(shapeFilePath))#forNetX

#Initializing NSF
set_new_attribute_to_nodes(larissa,'population',-1.0)
set_new_attribute_to_nodes(larissa,'building_i',-1)
set_new_attribute_to_nodes(larissa,'block_id',-1)
set_new_attribute_to_nodes(larissa,'manhole',-1)

change_length_attr(larissa)
num = find_building_edges_and_update_nodes(larissa)
restore_attributes(larissa)
check = [nod for nod in larissa.degree() if larissa.degree(nod) > 1 and larissa.node[nod]['population'] != -1]

#Initialize Main Graph G
G = larissa.copy()
population_to_int(G)
l = print_mass(G,cls000)[:]
mplith = akcom0_smsms_fixed_norm_max_mass_only(G,numberOfClusters) #1976

##########################################################################
# DEFINE LIST WITH ALL THE DHN VALUES FOR THIS CENTRAL OFFICE CLUSTER
########################################################################## 
dhns = []
dhns_info=[]
##########################################################################
# EXECUTE FOR EACH CLUSTER: best_dhns (define the best location to place KV)
########################################################################## 

for numberOfClusters in range(0,numberOfClusters):
    
    
    
    tic=timeit.default_timer()
    
    set_new_attribute_to_nodes(G.subgraph(cls000[numberOfClusters]),'cluster',numberOfClusters)
    gamma_list_of_tuples = cls000[numberOfClusters][:]    
    gamma = [list(elem) for elem in gamma_list_of_tuples] # CONVERT LIST OF TUPLES TO LIST OF LISTS
    shapeFileNameOne = 'nodesDistributionHubNetwork'+str(numberOfClusters)
    shapeFileNameTwo = 'edgesDistributionHubNetwork'+str(numberOfClusters)
    
    
    ### uncomment if you use find_best_dhn
    #d shapeFilePath: a string with the directorty of the input shape file
    fbd = find_best_dhn(G,gamma,rr,cap_list,cap_list_cost,shapeFilePath) # EXECUTE best_dhns
    #fbd = find_best_dhn_by_dim(G,gamma,rr,cap_list,cap_list_cost) # EXECUTE best_dhns
    
    toc=timeit.default_timer()
    a = int(toc - tic)
    print 'timeBest'
    print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds
        
    
    tic=timeit.default_timer()
    ##########################################################################
    # EXECUTE distribution_stuff
    ########################################################################## 
    ##########################################################################
    # INPUTS FOR THE REQUIRED FUNCTION
    ########################################################################## 
    
    ### uncomment if you use find_best_dhn
    dhn_gamma = fbd[1][:] # OUTPUT FROM best_dhns - THE X,Y COORDS OF THE BEST LOCATION FOR THE DISTRIBUTION HUB
    #dhn_gamma = fbd
    
    #print dhn_gamma #(365238.936628, 4385304.4983749995)
    ##########################################################################
    # Distribution Run
    ##########################################################################
    ath = alphas_distribution(G,gamma,dhn_gamma,lmin,lmax,d,cap_list,cap_list_cost,shapeFileNameOne,shapeFileNameTwo,shapeFilePath)
    #print ath[1]
    omhns_cl = omhns_cl_def(ath[1]) # definition explained in all_functions.py
    #print omhns_cl
    mhns_costing = mhns_cost_d(ath[0],mhn_c_l,mhn_cost,omhns_cl,d) # definition explained in all_functions.py 
    bomd = ath[2][:]
    ##########################################################################
    # Distribution Output
    ##########################################################################
    if PercentageOfCoverageDHN == 100:
        out_distribution = [ath[2][3],ath[2][2],omhns_cl, mhns_costing]
    else:
        gf, nf, cf = cluster_invs_dummy22(G,cluster_to_subready(G,ath[0].nodes()),dhn_gamma,PercentageOfCoverageDHN,cap_list,cap_list_cost)
        ath = alphas_distribution(G,gf.nodes(),dhn_gamma,lmin,lmax,d,cap_list,cap_list_cost,shapeFileNameOne,shapeFileNameTwo)[:]
        omhns_cl = omhns_cl_def(ath[1])[:] # assumption: an array with four values for the total number of manholes of each type [1way,2ways,3ways,new manholes]
        mhns_costing = mhns_cost_d(ath[0],mhn_c_l,mhn_cost,omhns_cl,d)
        bomd = ath[2][:]
        #dhn_gamma = ath[3]
        out_distribution = [ath[2][3],ath[2][2],omhns_cl, mhns_costing][:]
   
    ###############################################################################
    ############################ Distribution Output ##############################
    ###############################################################################
    # APPEND COORDS VALUES INTO list_all_dhn
    
    ### uncomment if you use find_best_dhn
    dhns.append(fbd[1])
    merge_tuple = fbd[1]
    #dhns.append(fbd)
    #merge_tuple = fbd
    
    
    # cast it to list
    a = list(merge_tuple)
    a.append(ath[0].node[dhn_gamma]['#splices'])
    #cast it to tuple again
    a = tuple(a)
    # cast it to list
    dhns_info.append(list(a))
    

    #print bomd
    # Append more outputs in csv file
    with open('python/csv/outputMetrics.csv', 'a') as fp:
		writer = csv.writer(fp, delimiter=';')
		writer.writerow(["KV:" + str(numberOfClusters)])
		writer.writerow(["Coverage of the network", str(PercentageOfCoverageDHN)])
		writer.writerow(["Length of f/c Grans (m)", str(cap_list[0]) + " is: " + str(bomd[3][0][0])])
		writer.writerow(["Length of s/d Grans (m)", str(cap_list[2]) + " is: " + str(bomd[3][1][0])])
		writer.writerow(["Length of d Grans (m)", str(cap_list[3]) + " is: " + str(bomd[3][2][0])])
		writer.writerow(["Unit Costs", str(cap_list_cost)])   
		writer.writerow(["Total Distribution Network Length (m)", str(bomd[2][0])])
		writer.writerow(["Total Distribution Network Cost ($)",  str(bomd[2][1] + mhns_costing + DHN_cost)])
		writer.writerow(["Total Distribution Network Trench Cost ($)", str(bomd[2][2])])
		writer.writerow(["Total Distribution Network Gran Cost ($)", str(bomd[2][3])])
		writer.writerow(["Number of Manholes Oneway", str(omhns_cl[0])])
		writer.writerow(["Number of Manholes Twoway", str(omhns_cl[1])])
		writer.writerow(["Number of Manholes Threeway", str(omhns_cl[2])])
		writer.writerow(["Number of New Manholes", str(omhns_cl[3])])
		writer.writerow(["Manholes Cost ($)", mhns_costing])
		writer.writerow(["Number of Splices in DHN", str(ath[0].node[dhn_gamma]['#splices'])])
		writer.writerow(["DHN cost", str(DHN_cost)])
    
    toc=timeit.default_timer()
    a = int(toc - tic)
    print 'timeStuff'
    print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds
    
        

print dhns
print dhns_info

##########################################################################
# Save the dhns and dhns_info in order to load it later in centralOfficeModule.py
##########################################################################
with open('python/tmp/dhns.txt', 'wb') as f:
	pickle.dump(dhns, f)
	
with open('python/tmp/dhns_info.txt', 'wb') as f:
	pickle.dump(dhns_info, f)



