#!/usr/bin/python
import csv
import sys
import networkx as nx
import math
import random
import copy
from heapq import heappop, heappush
import copy
import profile
import timeit

###############################################################################
############################### General Defs ##################################
################                                             ##################
###############################################################################


def set_new_attribute_to_nodes(graph,attribute,value):
    for n in graph.nodes_iter():
        nx.set_node_attributes(graph, attribute, {n: value})


def find_nodes_by_attribute(graph,attribute,value):
        nodes = list()
        for n in graph.nodes_iter():
            try:
                if (graph.node[n][attribute] == value):
                    nodes.append(n)
            except:
                pass
        if len(nodes) > 1:
            return nodes
        else:
            return False


def find_edges_by_attribute(graph,attribute,value):
    edges = list()
    for u,v,d in graph.edges(data=True):
        try:
            if d[attribute]==value:
                edges.append((u,v,d))
        except:
            pass
    if len(edges) > 1:
        return edges
    else:
        return False

#d: Gets as input the graph. For all the nodes which are not buildings
# and they are connected with with more than 1 street, set the 
# attributes population/building_i and manhole to -1
def restore_attributes(graph):
    for u,v,d in graph.edges(data=True):
        try:
            if d['building_i'] != -1:
                if (graph.degree(u) > 1 and graph.degree(v) > 1):
                    d['population'] = -1
                    d['building_i'] = -1
                    d['manhole'] = -1
        except:
            pass


def change_length_attr(graph):
    for u,v,d in graph.edges(data=True):
        nx.set_edge_attributes(graph, 'weight', {(u,v): d['length']})


def find_building_edges(graph):
    edges = list()
    for u,v,d in graph.edges(data=True):
        try:
            #print d['BUILDING_I']
            if d['building_i'] != -1:
                edges.append((u,v,d))
        except:
            pass
    if len(edges) > 1:
        return edges
    else:
        return False


def find_building_edges_and_update_nodes(graph):
    building_edges = find_building_edges(graph)
    for u,v,d in building_edges:
        degreeofu = graph.degree(u) # returns the degree of this node. The node degree is the number of edges adjacent to that node.
        degreeofv = graph.degree(v)
        if degreeofv == 1:
            nx.set_node_attributes(graph, 'population', {v: d['population']})
            nx.set_node_attributes(graph, 'building_i', {v: d['building_i']})
            nx.set_node_attributes(graph, 'block_id', {v: d['block_id']})
            #nx.set_node_attributes(graph, 'manhole', {v: d['manhole']})
        elif degreeofu == 1:
            nx.set_node_attributes(graph, 'population', {u: d['population']})
            nx.set_node_attributes(graph, 'building_i', {u: d['building_i']})
            nx.set_node_attributes(graph, 'block_id', {u: d['block_id']})
            #nx.set_node_attributes(graph, 'manhole', {u: d['manhole']})
    return len(building_edges)


#ceiling-flooring the population of a graph G
#d: make population integer
def population_to_int(GG):
    G = GG
    import math
    for n in G.nodes():
        if math.floor(G.node[n]['population']) == 0:
            G.node[n]['population'] = int(1)
        else:
            if G.node[n]['population'] - math.floor(G.node[n]['population']) <= 0.5:
                G.node[n]['population'] = int(math.floor(G.node[n]['population']))
            else:
                G.node[n]['population'] = int(math.ceil(G.node[n]['population']))


# Distance function
def adistance(x,y):
    import math # 'math' needed for 'sqrt'
    sq1 = (x[0] - y[0])**2
    sq2 = (x[1] - y[1])**2
    return math.sqrt(sq1 + sq2)


#create 3vectors of G.nodes() 
def graph_n_vec(GG):
    G = GG
    nn_list = G.nodes()[:]
    n_vec = []
    for i in range(len(nn_list)):
        n_vec.append(list(nn_list[i]))
        n_vec[i].append(G.node[nn_list[i]]['population'])
    return n_vec


##clear the previous list (NO null nodes)
def graph_c_vec(GG):
    G = GG
    n_vec = graph_n_vec(G)[:]
    c_vec = []
    for i in range(len(n_vec)):
        if n_vec[i][2] != -1:
            c_vec.append(n_vec[i])
    return c_vec


#sumofmass for G ;)
def sumofmass(L):
    """
    Returns the sum of masses of the points of a list.
    Each point p is of the form p = (x,y,|p|), where x,y are its coordinates
    and |p| is the "mass" of it.
    """
    som = 0
    if len(L) == 0:
        som = 0
    elif len(L)>=1:
        for i in range(len(L)):
            if L[i][2] != -1: #not the null nodes
                som = float(som + L[i][2])
            else:
                som = som + 0
    return som


#change the lmnts of a list from 2 to 3 dims
def change_dims(G,LL):
    listn = []
    for i in LL:
        n = (i[0],i[1])
        listn.append([i[0],i[1],G.node[n]['population']])
    return listn


#returns the closest em node to point. using in com ;)
def point_to_node(xx,L):
    x = xx
    PP = L[:]
    dd_l = []
    ssorted_d_l = []
    for j in range(len(PP)):
        dd_l.append([PP[j],adistance(xx,PP[j])])
    from operator import itemgetter, attrgetter
    ssorted_d_l = sorted(dd_l, key=itemgetter(1))
    if ssorted_d_l != []:
        rs = ssorted_d_l[0][0]
    else:
        rs = (0,0)
    return rs



#specifically for best_CO.py
def centerofmass3(G,LL):
    """
    Returns the coordinates of the center of mass of a list of points.
    Each point p is of the form p = (x,y,|p|), where x,y are its coordinates
    and |p| is the "mass" of it.
    """
    comx = 0
    comy = 0
    com = (0,0)
    if len(LL) == 0:
        com = (0,0)
    elif len(LL)==1:
        if LL[0][2] != -1:
            com = (LL[0][0],LL[0][1])
        else:
            com = (0,0)
    elif len(LL) > 1:
        for i in range(len(LL)):
            if LL[i][2] != -1: #not the null nodes
                comx = float(comx + LL[i][0]*LL[i][2])
                comy = float(comy + LL[i][1]*LL[i][2])
        com = (float(comx/sumofmass(LL)),float(comy/sumofmass(LL)))
    p = point_to_node(com,G.nodes())
    if G.node[p]['population'] != -1:
        p = G.neighbors(p)[0]
    return (p[0],p[1])


#centerofmass for G
def centerofmass0(G,LLL):
    """
    Returns the coordinates of the center of mass of a list of points.
    Each point p is of the form p = (x,y,|p|), where x,y are its coordinates
    and |p| is the "mass" of it.
    """
    LL = change_dims(G,LLL)[:]
    comx = 0
    comy = 0
    com = (0,0)
    if len(LL) == 0:
        com = (0,0)
    elif len(LL)==1:
        if LL[0][2] != -1:
            com = (LL[0][0],LL[0][1])
        else:
            com = (0,0)
    elif len(LL) > 1:
        for i in range(len(LL)):
            if LL[i][2] != -1: #not the null nodes
                comx = float(comx + LL[i][0]*LL[i][2])
                comy = float(comy + LL[i][1]*LL[i][2])
        com = (float(comx/sumofmass(LL)),float(comy/sumofmass(LL)))
    ll = []
    xx = com
    dd_l = []
    ssorted_d_l = []
    iinl = []
    for j in range(len(LL)):
        dd_l.append([LL[j],adistance(xx,LL[j])])
    from operator import itemgetter, attrgetter
    if len(dd_l) != 0:
        ssorted_d_l = sorted(dd_l, key=itemgetter(1))
        ll.append(ssorted_d_l[0][0])
        com = (ssorted_d_l[0][0][0],ssorted_d_l[0][0][1])
    p = point_to_node(com,LL)
    return (p[0],p[1])


#computes the center of a list of points regarding their coordinates 
#and NOT the mass of them!
def centerofmass(LL):
    """
    Returns the coordinates of the center of a list of points.
    Each point p is of the form p = (x,y), where x,y are its coordinates
    """
    comx = 0
    comy = 0
    com = (0,0)
    if len(LL) == 0:
        com = (0,0)
    else: 
        for i in range(len(LL)):
            comx = float(comx + LL[i][0])
            comy = float(comy + LL[i][1])
            com = (float(comx/len(LL)),float(comy/len(LL)))
    p = point_to_node(com,LL)
    return (p[0],p[1])


#sum of mass of a graph
def sumofmass_graph(GG):
    c_vec = []
    c_vec = graph_c_vec(GG)[:]
    return sumofmass(c_vec)


#center of mass of a graph \in Graph
def centerofmass_graph(GG):
    G = GG
    n_vec = []
    n_vec = graph_n_vec(G)[:]
    p = point_to_node(centerofmass0(G,n_vec),n_vec)
    return (p[0],p[1])


def centerofmass_graph0(GG):
    G = GG
    c_vec = []
    c_vec = graph_c_vec(G)[:]
    p = point_to_node(centerofmass0(G,c_vec),c_vec)
    return (p[0],p[1])


#random nodes of the Graph as initial points for clustering
def ran_points(PP,kk):
    k = kk
    s = PP[:]
    l = []
    l_points = []
    for i in s:
        l.append((i[0],i[1]))
    for j in range(k):
        r = random.choice(l)
        l_points.append(r)
        l.remove(r)
    return l_points


#creates equidistance-points on a circle
def cycpoints(cp,R,np):
    import math
    p0 = cp[:]
    r = R
    n = np
    pL = []
    num = 2*math.pi/n
    x0 = p0[0] #initial point is the center
    y0 = p0[1]
    import math
    for i in range(n):
        x = x0 + r*math.cos(i*num)
        y = y0 + r*math.sin(i*num)
        a = (x,y)
        pL.append(a)
    return pL


#given a point x returns the min. & max. distance of it from a set of points
#and the corresponding points
def minmaxp(PP,x):
    import math
    d_l = []
    sorted_d_l = []
    for j in range(len(PP)):
        d_l.append([PP[j],adistance(x,PP[j])])
    from operator import itemgetter, attrgetter
    sorted_d_l = sorted(d_l, key=itemgetter(1))
    if len(sorted_d_l) >1:
        return (sorted_d_l[0], sorted_d_l[len(sorted_d_l)-1])
    else:
        return (sorted_d_l[0], sorted_d_l[0])


#given a point x returns the min. & max. distance of it from a set of points
#and the corresponding points sp!!!
def minmaxp_sp(g,PP,x):
    import math
    d_l = []
    sorted_d_l = []
    for j in range(len(PP)):
        #d_l.append([PP[j],adistance(x,PP[j])])
        d_l.append( [PP[j], nx.dijkstra_path_length(g, source=x, target=PP[j])])
    from operator import itemgetter, attrgetter
    sorted_d_l = sorted(d_l, key=itemgetter(1))
    if len(sorted_d_l) >1:
        return (sorted_d_l[0], sorted_d_l[len(sorted_d_l)-1])
    else:
        return (sorted_d_l[0], sorted_d_l[0])


#given the initial input graph G and after clustering, creates the subgraph g
#that corresponds to a cluster. so it is ready for the Cost functions!
def cluster_to_subgraph(GG,cluster):
    G = GG
    cl = cluster[:]
    l = []
    for i in cl: #3ades-2ades
        l.append((i[0],i[1]))
    comP = point_to_node(centerofmass0(G,cl),l) #finds comP
    #returns all the nodes 
    l_null = []
    s = []
    for node in l:
        s = nx.dijkstra_path(G,comP,node)[:]
        if comP in s:
            s.remove(comP)
        if node in s:
            s.remove(node)
        for n in s:
            if n not in l_null:
                l_null.append(n)
        s = []
    cluster_nodes = l[:]
    for i in l_null:
        cluster_nodes.append(i)
    g = G.subgraph(cluster_nodes)
    return [g,comP]


#given the initial input graph G and after clustering, creates the subgraph g
#that corresponds to a cluster. so it is ready for the Cost functions!
def cluster_to_subgraph_f(GG,cluster,comP):
    G = GG.copy()
    cl = cluster[:]
    l = []
    for i in cl: #3ades-2ades
        l.append((i[0],i[1]))
    l_null = []
    s = []
    for node in l:
        s = nx.dijkstra_path(G,comP,node)[:]
        if comP in s:
            s.remove(comP)
        if node in s:
            s.remove(node)
        for n in s:
            if n not in l_null:
                l_null.append(n)
        s = []
    cluster_nodes = l[:]
    for i in l_null:
        cluster_nodes.append(i)
    cluster_nodes.append(comP)
    g = G.subgraph(cluster_nodes)
    return [g,comP]


#give the attributes to subtrees
def att_to_subtrees(gg,qq):
    q = qq[:]
    sub_list = []
    for i in range(len(q)):
        graph = q[i]
        for ee in graph.edges():
            if (ee[0],ee[1]) in gg:
                graph.add_edge(ee[0],ee[1], weight = gg.edge[ee[0]][ee[1]]['weight'])
            if (ee[1],ee[0]) in gg:
                graph.add_edge(ee[0],ee[1], weight = gg.edge[ee[1]][ee[0]]['weight'])
            #graph.add_edge(ee[0],ee[1], efficiency = gg.edge[ee[0]][ee[1]]['efficiency'])
        for n in graph.nodes():
            graph.node[n] = gg.node[n]
        sub_list.append(graph)
    return sub_list



def aprims_mst(G, weight = 'weight', data = True):
    """Edges in a minimum spanning forest of an undirected graph
    """
    tic=timeit.default_timer()# for 3 clusters and the subset shape file of larissa we
    
    
    if G.is_directed():
        raise nx.NetworkXError("Mimimum spanning tree not defined for directed graphs.")
    nodes = G.nodes() 
    e = []
    while nodes:
        u = nodes.pop(0) #choose each time the first node of the list nodes and remove it from the list
        frontier = []
        visited = [u]
        for u, v in G.edges(u):
            heappush(frontier, (G[u][v].get(weight, 1), u, v))
        while frontier:
            W, u, v = heappop(frontier)
            if v in visited:
                continue
            visited.append(v)
            nodes.remove(v)
            e.append((u,v))
            for v, w  in G.edges(v):
                if not w in visited:
                    heappush(frontier, (G[v][w].get(weight, 1), v, w))
      
    toc=timeit.default_timer()
    a = int(toc - tic)
    print 'MST'
    print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds 
      
                    
    print 'e'
    print e
    return e



#returns the total length of a graph G
def alength_graph(GG):
    G = GG
    s = 0
    alpha = G.edges()[:]
    for e in alpha:
        s = s + G[alpha[0][0]][alpha[0][1]]['weight']
    return s



#makes All the main paths of init_node, directed graphs
#actually creates a tree with root the init_node and the main paths are its 
#subtrees
def a_di_main_paths(DDD,L):
    G = DDD
    l = L[:]
    subtrees = []
    lll = []
    subgraphs = []
    for i in range(len(l)): #computes the subtrees
        sub = []
        for j in range(len(l[i])):
            path = l[i][j][:]
            for k in range(len(path)):
                e = path[k][:]
                if e not in sub:
                    sub.append(e)
        subtrees.append(sub)
    list_node = [] # to define the K.graph we want the nodes of it
    for jj in range(len(subtrees)):
        path = subtrees[jj][:]
        list_node = []
        for k in range(len(path)):
            e = path[k][:]
            if e[0] not in list_node:
                list_node.append(e[0])
            if e[1] not in list_node:
                list_node.append(e[1])
        lll.append(list_node) #define the main paths as directed subgraphs 
    for k in range(len(lll)):
        K = nx.DiGraph()
        K.add_nodes_from(lll[k])
        K.add_edges_from(subtrees[k])
        for n in K.nodes():
            K.node[n]['population'] = G.node[n]['population']
        for ee in K.edges():
            if (ee[0],ee[1]) in G.edges():
                K[ee[0]][ee[1]]['weight'] = G.edge[ee[0]][ee[1]]['weight']
            if (ee[1],ee[0]) in G.edges():
                K[ee[0]][ee[1]]['weight'] = G.edge[ee[1]][ee[0]]['weight']
        subgraphs.append(K)
    return subgraphs

#returns the path of two nodes as a directed graph
#input is one of the subtrees
def path(DD,s_node,e_node):
    l = []
    for path in nx.all_simple_paths(DD, s_node, e_node):
        l = path
    e_list = []
    for i in range(len(l)-1):
        e_list.append((l[i],l[i+1]))
    d = nx.DiGraph()
    d.add_nodes_from(l)
    d.add_edges_from(e_list)
    graph = d
    for ee in graph.edges():
        if (ee[0],ee[1]) in DD.edges():
            graph[ee[0]][ee[1]]['weight'] = DD[ee[0]][ee[1]]['weight']
        if (ee[1],ee[0]) in DD.edges():
            graph[ee[0]][ee[1]]['weight'] = DD[ee[1]][ee[0]]['weight']
        #graph.add_edge(ee[0],ee[1], efficiency = D.edge[ee[0]][ee[1]]['efficiency'])
    for n in graph.nodes():
        graph.node[n] = DD.node[n]
    return [d,l,e_list]


def depth_node(DD,s_node,e_node):
    l = len(path(DD,s_node,e_node)[1])-1
    return l


#computes the length of the path from path()
def path_length(DD,snn,enn):
    dd = DD
    sn = snn
    en = enn
    graph,nodess,edgess = path(dd,sn,en)
    lt = 0
    for i in range(len(nodess)-1):
        if (nodess[i], nodess[i+1]) in graph.edges():
            lt = lt + graph[nodess[i]][nodess[i+1]]['weight']
    return float(lt)


#we need it to the following
def reverse_numeric(x, y):
    return y - x


#arrange lmnts of a list from max->min (multiplicity = 1)
def arrange_list(listt):
    a = listt[:]
    n = 0
    l = []
    for i in a:
        n = i
        if n not in l:
            l.append(i)
    return sorted(l,cmp=reverse_numeric)


#prepare the graph for perinv_cluster()
def cluster_to_subready(G,aman1):
    l_nodes = []
    for i in aman1:
        l_nodes.append((i[0],i[1]))
    gg = G.subgraph(l_nodes)
    comP = centerofmass0(G,l_nodes)
    l_paths = nx.single_source_dijkstra_path(G,comP)
    all_nodes = []
    for n in gg.nodes():
        all_nodes.append(l_paths[n])
    end_list = []
    for i in all_nodes:
        for j in i:
            if j not in end_list:
                end_list.append(j)
    ll0 = end_list[:]
    population_to_int(G)
    set_new_attribute_to_nodes(G,'sucgload',[0,0])
    set_new_attribute_to_nodes(G,'suc2gload',[0,0])
    set_new_attribute_to_nodes(G,'sucggload',[0,0])
    set_new_attribute_to_nodes(G,'root_node', 0)
    g = G.subgraph(ll0)
    cutoff_null_leafs0(g)
    for e in g.edges():
        g_e = g[e[0]][e[1]]
        g_e['grans'] = {}
        g_e['ALPHA'] = {}
        g_e['grans_f'] = {}
        g_e['grans_c'] = {}
        g_e['grans_s'] = {}
        g_e['grans_d'] = {}
        g_e['dum_cost'] = 0
        g_e['gr_cost'] = 0
        g_e['tr_cost'] = 0
        g_e['dum_cost'] = 0
        g_e['efficiency'] = 0
    return g


#prepare the graph for perinv_cluster()
def cluster_to_subready_feeder(G,aman1,comP_dhns,dhns,dhns_info):
    l_nodes = []
    for i in aman1:
        l_nodes.append((i[0],i[1]))
    gg = G.subgraph(l_nodes)
    #comP = centerofmass_graph(gg)
    comP = comP_dhns
    l_paths = nx.single_source_dijkstra_path(G,comP)
    all_nodes = []
    for n in gg.nodes():
        all_nodes.append(l_paths[n])
    end_list = []
    for i in all_nodes:
        for j in i:
            if j not in end_list:
                end_list.append(j)
    ll0 = end_list[:]
    #population_to_int(G)
    set_new_attribute_to_nodes(G,'sucgload',[0,0])
    set_new_attribute_to_nodes(G,'suc2gload',[0,0])
    set_new_attribute_to_nodes(G,'sucggload',[0,0])
    set_new_attribute_to_nodes(G,'root_node', 0)
    g = G.subgraph(ll0)
    #cutoff_null_leafs0(g)
    for e in g.edges():
        g_e = g[e[0]][e[1]]
        g_e['grans'] = {}
        g_e['ALPHA'] = {}
        g_e['grans_f'] = {}
        g_e['grans_c'] = {}
        g_e['grans_s'] = {}
        g_e['grans_d'] = {}
        g_e['dum_cost'] = 0
        g_e['gr_cost'] = 0
        g_e['tr_cost'] = 0
        g_e['dum_cost'] = 0
        g_e['efficiency'] = 0
    return g


#arrange all leafs according to their edges eff
def leafs_f(gg):
    leafs_list = []
    for n in gg.nodes():
        if G.node[n]['population'] != -1:
            e = gg.edges(n)[0]
            leafs_list.append([n,gg[e[0]][e[1]]['efficiency']])
    from operator import itemgetter, attrgetter
    sorted_leafs_list = sorted(leafs_list, key=itemgetter(1))
    return sorted_leafs_list


#finds dhn
def find_dhn(G,g):
    #comP = centerofmass_graph(gg)
    comPP = centerofmass0(G,g.nodes())
    dhn = 0
    for n in g.neighbors(comPP):
        if g.node[n]['population'] == -1:
            dhn = n
    return dhn


#given a directed graph and an edge of it, returns the edges of the subtree of 
#the starting node of that edge
def fedge_sub(D,worst_fedge):
    #initial step
    a = worst_fedge
    D_edges = D.edges(a)[:]
    D_edges.remove(a)
    for e in D_edges:
        if e[0] == a[0]:
            D_edges.remove(e)
    l_a = D_edges[:] #very first edges of the subtree without root edge
    #recursive step
    for a in l_a:
        for edd in D.edges(a):
            if edd not in l_a:
                l_a.append(edd)
    #add the root edge
    l_a.append(worst_fedge)
    return l_a


#finds the nodes of a list of edges
def edges_nodes(fedge_subedges):
    l_n = []
    for e in fedge_subedges:
        n0 = e[0]
        n1 = e[1]
        if n0 not in l_n:
            l_n.append(n0)
        if n1 not in l_n:
            l_n.append(n1)
    return l_n


#finds the mass of a cluster
def cluster_m(G,cluster):
    s = 0
    for i in cluster:
        n = (i[0],i[1])
        if G.node[n]['population'] != -1:
            s = s + G.node[n]['population']
    return s


def change_dims_graph(g):
    l0 = []
    for i in g.nodes():
        l0.append([i[0],i[1]])
    return l0


###################    play with blocks init    ###################

def print_mass(G,alphag):
    l = []
    for a in alphag:
        l.append(cluster_m(G,a))
    return l



#instead of all the nodes we play with only one node of each block
def gblock_graph(G):
    Gb = G.copy()
    Gb_blocks = graph_blocks_all(Gb)[:]
    gamma = []
    for i in range(len(Gb_blocks)):
        n = Gb_blocks[i][2]
        gamma.append(n) #the set of Nodes of blocks; the init set
        Gb.node[n]['population'] = Gb_blocks[i][1] #changing the population of these nodes
    g = cluster_to_subready(Gb,gamma)
    return g
#------------------------------------------------------------------------------


#for all
#create a list with all the nodes of the blocks to the corresponding alphags
def lalphags(G,alphag):
    Gb = G.copy()
    Gb_blocks = graph_blocks_all(Gb)[:]
    lalphag = []
    for a in alphag:
        ll = []
        k = 0
        s = 0
        for n in a:
            na = (n[0],n[1])
            for bl in Gb_blocks:
                if bl[2] == (n[0],n[1]):
                    k = k + 1
                    s = s + G.node[na]['population']
                    for i in bl[0]:
                        ll.append(i)
        lalphag.append(ll)
    return lalphag






#------------------------------------------------------------------------------
##### CONVEX HULL #####
def convex_hull(points):
    """Computes the convex hull of a set of 2D points.
 
    Input: an iterable sequence of (x, y) pairs representing the points.
    Output: a list of vertices of the convex hull in counter-clockwise order,
      starting from the vertex with the lexicographically smallest coordinates.
    Implements Andrew's monotone chain algorithm. O(n log n) complexity.
    """
 
    # Sort the points lexicographically (tuples are compared lexicographically).
    # Remove duplicates to detect the case we have just one unique point.
    points = sorted(set(points))
 
    # Boring case: no points or a single point, possibly repeated multiple times.
    if len(points) <= 1:
        return points
 
    # 2D cross product of OA and OB vectors, i.e. z-component of their 3D cross product.
    # Returns a positive value, if OAB makes a counter-clockwise turn,
    # negative for clockwise turn, and zero if the points are collinear.
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
 
    # Build lower hull 
    lower = []
    for p in points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
 
    # Build upper hull
    upper = []
    for p in reversed(points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
 
    # Concatenation of the lower and upper hulls gives the convex hull.
    # Last point of each list is omitted because it is repeated at the beginning of the other list. 
    return lower[:-1] + upper[:-1]
#------------------------------------------------------------------------------


def x_range(start, end, step):
    while start <= end:
        yield start
        start += step


def diff(a, b):
    b = set(b)
    return [aa for aa in a if aa not in b]


def unique(a):
    """ return the list with duplicate elements removed """
    return list(set(a))


def intersect(a, b):
    """ return the intersection of two lists """
    return list(set(a) & set(b))


def union(a, b):
    """ return the union of two lists """
    return list(set(a) | set(b))


#checks if a point belongs to a triangle
#tri is the list of the vertices of the triangle
def in_trigon(pt,tri):
    ## ADD THE NEXT TWO LINES
    paranomastis = (-tri[1][1]*tri[2][0]+tri[0][1]*(-tri[1][0]+tri[2][0])+tri[0][0]*(tri[1][1]-tri[2][1])+tri[1][0]*tri[2][1])
    #print("paranom")
    #print(paranomastis)
    if (paranomastis !=0):
        a = 1/paranomastis
        s = a*(tri[2][0]*tri[0][1]-tri[0][0]*tri[2][1]+(tri[2][1]-tri[0][1])*pt[0]+(tri[0][0]-tri[2][0])*pt[1])
        #print(s)
        if s<0: 
            return False
        else: 
            t = a*(tri[0][0]*tri[1][1]-tri[1][0]*tri[0][1]+(tri[0][1]-tri[1][1])*pt[0]+(tri[1][0]-tri[0][0])*pt[1])
            return ((t>0) and (1-s-t>0))





#determines if a point belongs to the convex hull
def p_convex_hull(G,p,ch):
    gp = cluster_to_subready(G,ch)
    #find com of gp
    com = centerofmass_graph(gp)
    #check if p belongs to ch of p_list
    #by checking if belongs to one of its triangles
    met = 0
    t = 0
    while met < len(ch)-1:
        a = ch[met]
        b = ch[met+1]
        if in_trigon(p,[a,b,com]):
            t = 1
            break
        else:
            met = met+1
    if t == 1:
        return True


#determines if a point belongs to the convex hull
def p_convex_hull_dhn(G,dhn,p,ch):
   
    com = dhn
    ###check if p belongs to ch of p_list
    #by checking if belongs to one of its triangles
    #print(len(ch))
    met = 0
    t = 0
    while met < len(ch)-1:
        a = ch[met]
        b = ch[met+1]
        #print("a+b")
        #print(a)
        #print(b)
        if in_trigon(p,[a,b,com]):
            t = 1
            break
        else:
            met = met+1
    if t == 1:
        return True


#checks if an integer is prime
def isPrime(n):
    import math
    #n is a nonnegative integer
    if n < 2: 
        return False;
    if n % 2 == 0:
        # return False
        return n == 2
    k = 3
    while k*k <= n:
        if n % k == 0:
            return False
        k += 2
    return True


#returns a list with primes up to n
def primes(n):
    p_l = []
    for i in range(n):
        if isPrime(i):
            p_l.append(i)
    return p_l



###############################################################################
############################### General Defs ##################################
################                   The End                   ##################
###############################################################################

###############################################################################
###################### About Caps, Grans & Their Costs ########################
################                                             ##################
###############################################################################
#given a number and a list returns the next greater lmnt of the list, of that number
#number Must be not greater than the max lmnt of the list
def cap(mm,bb): 
    m = mm
    list_b = bb[:]
    d = 0
    for i in range(len(bb)):
        if m == bb[i]:
            return m
        else:
            d = bb[i]-m
            if d > 0:
                return bb[i]


#output is the number of kind of cables/tubes/subducts/ducts we need to use
def cap_gran(mm,bb):
    m = mm
    list_b = bb[:]
    mx = max(list_b)
    list_gran = []
    for iii in range(len(list_b)): #initializes list_gran := /
        list_gran.append(0)
    alpha = m/mx
    list_gran[list_b.index(mx)] = alpha
    beta = m%mx
    if len(list_b) > 1:
        mx_1 = list_b[list_b.index(mx) -1] #checks if beta is between last and previous lmnts of list
        if beta > mx_1:
            list_gran[list_b.index(mx)] = list_gran[list_b.index(mx)] + 1
        else:
            if beta != 0:
                list_gran[list_b.index(cap(beta,list_b))] = 1
            else:
                list_gran[list_b.index(cap(beta,list_b))] = 0
        return list_gran
    else:
        if beta == 0:
            return list_gran
        else:
            list_gran[0] = list_gran[0] + 1
            return list_gran

#from fibers/cables we go to cables/subducts. to compute this since here we have
#that cable/subduct 1/1 we have to add the lnts of cap_grans list
#to see how many subducts we want for the node we examine

#compute the cost of a given node according to gran tables
#not the cost actually, but what kind of gran we will use for it!
def cap_gran_cost(DD,cost_node,cap_list):
    D = DD
    c_node = cost_node
    load_p = D.node[c_node]['population']
    #computing
    #the input list of the next cap_gran is the sum of the previous output of it
    cap_gran_list = []
    res_gran_list = []
    m = load_p #init time
    for i in range(len(cap_list)):
        b_list = cap_list[i][:] #one gran at the time
        res_gran_list = cap_gran(m,b_list)[:] #output of cap_gran
        cap_gran_list.append(res_gran_list) #append it to final gran list
        res_gran = 0 #compute the sum of lmnts of the res_gran_list in order to have them as input to the next cap_list lmnt
        for j in range(len(res_gran_list)):
            res_gran = res_gran + res_gran_list[j]
        m = res_gran
    return cap_gran_list



#returns a list with the NOT null nodes of a null node
def null_suc(DD,null_node):
    D = DD
    n_node = null_node
    D_suc = []
    d = D.successors(n_node)
    for i in range(len(d)):
        if D.node[d[i]]['population'] != -1:
            D_suc.append(d[i])
    return D_suc


#returns a list with the Null nodes of a null node
def null_suc_null(DD,null_node):
    D = DD
    n_node = null_node
    D_suc = []
    d = D.successors(n_node)
    for i in range(len(d)):
        if D.node[d[i]]['population'] == -1:
            D_suc.append(d[i])
    return D_suc


#initialize the 'sucggload' of null nodes
def init_null(DD):
    D = DD
    for n in D.nodes():
        if D.node[n]['population'] == -1:
            D.node[n]['sucggload'] = [0,0]


#for all leaf nodes we run the above algo. The sum of the 3rd lmnt 
#(depending on the kind network) of the cap_gran_list is info that null nodes
# must have. 
def cap_gran_null(DD,null_node,cap_list):
    D = DD
    nulln = null_node
    n = 0
    n_list = []
    for i in range(len(cap_list[2])):#initialize n_list
        n_list.append(0)
    not_null_nodes = null_suc(D,nulln)[:]
    for jj in range(len(cap_list[2])): 
        summ=0
        for j in not_null_nodes:
            summ = summ + cap_gran_cost(D,j,cap_list)[2][jj]
            n_list[jj] = summ
    D.node[nulln]['sucgload'] = n_list[:]


def all_cap_gran_null(DD,cap_list): #cap_gran_null' s
    D = DD
    for n in D.nodes():
        if D.node[n]['population']==-1:
                cap_gran_null(D,n,cap_list)


def cap_gran_null_null(DD,null_node,cap_list): 
    D = DD
    nulln = null_node
    n = 0
    n_list = []
    for i in range(len(cap_list[2])):#initialize n_list
        n_list.append(0)
    null_nodes = null_suc_null(D,nulln)[:]
    for jj in range(len(cap_list[2])): 
        summ=0
        for j in null_nodes: #
            summ = summ + D.node[j]['sucgload'][jj] + D.node[nulln]['sucgload'][jj]
            n_list[jj] = summ
    D.node[nulln]['sucggload'] = n_list[:]


def depth_nodes_list(D,dhn):
    nl = []
    D_nodes_list = D.nodes()[:]
    D_nodes_list.remove(dhn)
    for n in D_nodes_list: #create a list with null nodes depending on their depth
        if D.node[n]['population'] == -1:
            nl.append([n,depth_node(D,dhn,n)])
    from operator import itemgetter, attrgetter
    sorted_nl = sorted(nl, key=itemgetter(1))
    nl = sorted_nl[:]
    nl0 = []
    k = len(nl) - 1
    while k > -1:
        nl0.append(nl[k])
        k = k -1
    l = []
    for lmnt in nl0:
        l.append(lmnt[0])
    return l


def cap_gran_null_null000(D,dhn,cap_list):
    d_list = depth_nodes_list(D,dhn)[:]
    for n in d_list:
        n_list = []
        for i in range(len(cap_list[2])):#initialize n_list
            n_list.append(0)
        l_suc_null = len(null_suc_null(D,n))
        if l_suc_null != 0:
            summ=0
            for jj in range(len(cap_list[2])): 
                summ = summ + l_suc_null
                n_list[jj] = cap_gran(summ,cap_list[2])[jj]
        D.node[n]['suc2gload'] = n_list[:]


def cap_gran_null_null_null000(D,cap_list):
    for n in D.nodes():
        if D.node[n]['population'] == -1:
            n_list = []
            for i in range(len(cap_list[2])):#initialize n_list
                n_list.append(0)
            #l_suc_null = len(null_suc_null(D,n))
            #if l_suc_null != 0:
            summ=0
            for jj in range(len(cap_list[2])): 
                n_list[jj] = D.node[n]['sucgload'][jj] + D.node[n]['suc2gload'][jj]
            D.node[n]['sucggload'] = n_list[:]




def cap_gran_null_null0(DD,null_node,cap_list): #thes to root node
    D = DD
    nulln = null_node
    n_list = []
    for i in range(len(cap_list[2])):#initialize n_list
        n_list.append(0)
    null_nodes = null_suc_null(D,nulln)[:]
    #nl = []
    #nl = depth_nodes_list(D,root)[:]
    k = 0
    for jj in range(len(cap_list[2])): 
        summ=0
        for j in D.nodes(): 
            j_suc = D.successors(j)[:]
            for n in j_suc:
                if D.node[n]['population'] != -1:
                    k = k +1
            if k != 0:
                summ = summ + D.node[j]['sucgload'][jj] + D.node[nulln]['sucgload'][jj]
        n_list[jj] = summ
    D.node[nulln]['sucggload'] = n_list[:]


def cap_gran_null_null00(DD,null_node,cap_list): #thes to root node
    D = DD
    nulln = null_node
    n_list = []
    for i in range(len(cap_list[2])):#initialize n_list
        n_list.append(0)
    null_nodes = null_suc_null(D,nulln)[:]
    #nl = []
    #nl = depth_nodes_list(D,root)[:]
    k = 0
    for jj in range(len(cap_list[2])): 
        summ=0
        for j in D.nodes(): 
            if D.node[j]['population'] != -1:
                j_suc = D.successors(j)[:]
                for n in j_suc:
                    if D.node[n]['population'] != -1:
                        k = k +1
                if k != 0:
                    summ = summ + D.node[j]['sucgload'][jj] + D.node[nulln]['sucgload'][jj]
        n_list[jj] = summ
    D.node[nulln]['sucggload'] = n_list[:]



def all_cap_gran_null_null(DD):
    D = DD
    for n in D.nodes():
        if D.node[n]['population']==-1 and len(null_suc_null(D,n))==1:
                cap_gran_null_null(D,n)


def cap_gran_null_null2(DD,null_node,cap_list):
    D = DD
    nulln = null_node
    n = 0
    n_list = []
    for i in range(len(cap_list[2])):#initialize n_list
        n_list.append(0)
    null_nodes = null_suc_null(D,nulln)[:]
    for jj in range(len(cap_list[2])): 
        summ=0
        for j in null_nodes:
            summ = summ + D.node[j]['sucggload'][jj]
            n_list[jj] = summ
    D.node[nulln]['sucggload'] = n_list[:]




#leaf node cost!!!
def semi_ln_cost(DD,nn,ggfather,cap_list_cost):
    D = DD
    nd = nn
    ggf = ggfather
    #finds the cost of gran
    cc_list = []
    cc = cap_gran_cost(D,nd,cap_list)
    for i in range(len(cc)):
        for j in range(len(cc[i])):
            lmnt = cc[i][j]
            if lmnt != 0:
                ind = cc[i].index(lmnt)
                cc_list.append(lmnt*cap_list_cost[i][ind])
    #the cable and subduct go all way to the Root!
    path_node_cost1 =  path_length(D,ggf, nd) *  cc_list[0] #price for the f/c
    path_node_cost2 =  path_length(D,ggf, nd) *  cc_list[1] #price for the c/s
    #[7,24] s/d Only at its edge!
    path_node_cost3 =  path_length(D, D.predecessors(nd)[0], nd) *  cc_list[2]
    #prepei na valo to [7,24] s/d sta miki prin apo to leaf-edge
    pnca = path_node_cost1 + path_node_cost2 + path_node_cost3
    return pnca


#all the semi cost for the leaf nodes !!
def semi_ln_costs(DD,ggfather):
    D = DD
    ggf = ggfather
    cost_semi_ln = 0
    for n in D.nodes():
        if D.node[n]['population'] != -1 and D.out_degree(n) == 0:
            cost_semi_ln = cost_semi_ln + semi_ln_cost(D,n,ggf)
    return cost_semi_ln


#pame gia to kostos kathe akmis me akro null node
def null_node_cost(DD,null_node,cap_list):
    D = DD
    nn=null_node
    nn_edge_cost = 0
    if D.node[nn]['sucggload'][0] <= cap_list[2][0] and not 0:
        nn_edge_cost1 = path_length(D, D.predecessors(nn)[0], nn) * cap_sd_cost[0]
    if D.node[nn]['sucggload'][1] <= cap_list[2][1] and not 0:
        nn_edge_cost2 = path_length(D, D.predecessors(nn)[0], nn) * cap_sd_cost[1]
    nn_edge_cost = nn_edge_cost1 + nn_edge_cost2
    return nn_edge_cost


#all the null node costs !!
def all_null_node_costs(DD):
    D = DD
    cost_null = 0
    for n in D.nodes():
        if D.node[n]['population'] == -1:
            cost_null = cost_null + null_node_cost(D,n)
    return cost_null


def all_length(DD):
    D = DD
    s = 0
    for e in D.edges():
        s = s + path_length(D, e[0], e[1])
    return s


#costs that have to do with length
def all_length_cost(DD):
    D = DD
    length = all_length(D)
    trench_cost = length * 7 #price for the trench/meter
    main_duct_cost = length * cap_d_cost[0] #price for the main duct/meter
    return trench_cost + main_duct_cost


#change is here
#given a mst graph GG, and a node of it as root, returns the DiGraph tree.
def root_tree(GG,root0):
    L = []
    init_N = GG.nodes()
    init_N.remove(root0)
    N = []
    for i in  GG.edges(root0):
        if i[1] in init_N:
            L.append(i)
            N.append(i[1])
    for root in N:
        if root in init_N:
            init_N.remove(root)
            for i in  GG.edges(root):
                if i[1] in init_N:
                    L.append(i)
                    N.append(i[1])
    N.append(root0)
    GGGG =nx.DiGraph()
    GGGG.add_edges_from(L)
    #tora prepei na vlao ta attrs pantou!
    for e in GGGG.edges():
        if (e[0],e[1]) in G.edges():
            GGGG[e[0]][e[1]]['weight'] = GG.edge[e[0]][e[1]]['weight']
        if (e[1],e[0]) in G.edges():
            GGGG[e[0]][e[1]]['weight'] = GG.edge[e[0]][e[1]]['weight']
    for n in GGGG.nodes():
        GGGG.node[n]['population'] = GG.node[n]['population'] 
    return GGGG


def grans_to_edges(D,cap_list):
    #gives to the leaf edges of not null nodes the 'grans'
    for e in D.edges():
        if D.node[e[1]]['population'] != -1:
            D[e[0]][e[1]]['grans'] =  cap_gran_cost(D,e[1],cap_list)
    #creates the list of the paths
    l_paths = []
    for n in D.nodes():
        if D.node[n]['population'] != -1:
            p = path(D,dhn,n)[2]
            p.remove(p[len(p)-1]) #last edge of path is done from above
            l_paths.append([p,n,len(p)])
    #from this list, we choose the larger one
    from operator import itemgetter, attrgetter
    sorted_l_paths = sorted(l_paths, key=itemgetter(2))
    longest_path = sorted_l_paths[len(sorted_l_paths)-1][0]
    #gives grans to edges!!!
    for e in longest_path:
        listedge = []
        le = []
        c = []
        for l in sorted_l_paths:
            if e in l[0]:
                c = cap_gran_cost(D,l[1],cap_list)
                le.append([c[0],c[1]])
        dgg = D.node[e[1]]['sucggload']
        dg = D.node[e[1]]['sucgload']
        n_dgg = cap_gran(dgg[0] ,cap_list[2])
        n_dg = cap_gran(dg[0],cap_list[2])
        f_dgg = [0,0]
        f_dg = [0,0]
        f_dgg[0], f_dgg[1] = n_dgg[0], dgg[1]
        f_dg[0], f_dg[1] = n_dg[0], dg[1]
        if f_dgg != [0,0]:
            listedge.append([le,f_dgg,c[3]])
            #D[e[0]][e[1]]['grans'] = listedge[:]
            #D[e[0]][e[1]]['grans'][0][1] = D.node[e[1]]['sucggload']
        else:
            listedge.append([le,f_dg,c[3]])
            #D[e[0]][e[1]]['grans'] = listedge
        D[e[0]][e[1]]['grans'] = listedge


#gives to the leaf edges of not null nodes the 'grans'
def grans_to_edges0(D,dhn,cap_list):
    for e in D.edges():
        if D.node[e[1]]['population'] != -1:
            D[e[0]][e[1]]['grans'] =  cap_gran_cost(D,e[1],cap_list)
    #creates the list of the paths
    l_paths = [] #this list is ok!!!
    #dhn = find_dhn(D,D)
    for n in D.nodes():
        if D.node[n]['population'] != -1:
            p = path(D,dhn,n)[2]
            p.remove(p[len(p)-1]) #last edge of path is done from above
            l_paths.append([p,n,len(p)])
    #from this list, we choose the larger one
    #wrong!!!
    from operator import itemgetter, attrgetter
    sorted_l_paths = sorted(l_paths, key=itemgetter(2))
    #longest_path = sorted_l_paths[len(sorted_l_paths)-1][0]
    #gives grans to edges!!!
    for slp in sorted_l_paths:
        for e in slp[0]:
            listedge = []
            le = []
            c = []
            for l in sorted_l_paths:
                if e in l[0]:
                    c = cap_gran_cost(D,l[1],cap_list)
                    le.append([c[0],c[1]])
            dgg = D.node[e[1]]['sucggload']
            dg = D.node[e[1]]['sucgload']
            n_dgg = cap_gran(dgg[0] ,cap_list[2])
            n_dg = cap_gran(dg[0],cap_list[2])
            f_dgg = [0,0]
            f_dg = [0,0]
            f_dgg[0], f_dgg[1] = n_dgg[0], dgg[1]
            f_dg[0], f_dg[1] = n_dg[0], dg[1]
            if f_dgg != [0,0]:
                listedge.append([le,f_dgg,c[3]])
                #D[e[0]][e[1]]['grans'] = listedge[:]
                #D[e[0]][e[1]]['grans'][0][1] = D.node[e[1]]['sucggload']
            else:
                listedge.append([le,f_dg,c[3]])
                #D[e[0]][e[1]]['grans'] = listedge
            D[e[0]][e[1]]['grans'] = listedge


def grans_again0(D):
    for e in D.edges():
        D_e = D[e[0]][e[1]]
        l = D_e['grans']
        if len(l) == 1:
            lg = []
            l0 = l[0][0][:]
            Lg = []
    #        print str(l0), " --- ",  str(len(l0))
            if len(l0) == 1:
                #print l0[0]
                for i in l0[0]:
                    lg.append(i)
                for i in range(1,len(l[0])):
                    lg.append(l[0][i])
            else:
                #print l0
                for i in l0:
                    for j in i:
                        jj_list = []
                        for k in range(len(j)):
                            jj_list.append(0)
                        #print jj_list
                        lg.append(jj_list)
                lgg = []
                for i in range(2):
                    lgg.append(lg[i])
                #print lgg
                for i in range(len(l0)):
                    for j in range(len(l0[i])):
                        for k in range(len(l0[i][j])):
                            lgg[j][k] = lgg[j][k] + l0[i][j][k]
                lg = lgg[:]
                for i in range(1,len(l[0])):
                    lg.append(l[0][i])
            Lg = []
            for i in lg:
                Lg.append(i)
            #print Lg
            D_e['grans'] = Lg[:]
            D_e['ALPHA'] = Lg[:]
        else:
            D_e['ALPHA'] = l


def granss0(D):
    for e in D.edges():
        D_e = D[e[0]][e[1]]
        a = D_e['grans']
        if a != {}:
            D_e['grans_f'] = a[0] 
            D_e['grans_c'] = a[1] 
            D_e['grans_s'] = a[2]
            D_e['grans_d'] = a[3]


def grans_to_edges_cool(D,cap_list):
    for e in D.edges():
        D_e = D[e[0]][e[1]]
        D_e_gran = D_e['grans']
        if D_e_gran != {}:
            if D.node[e[1]]['population'] == -1:
                a = cap_gran(D_e_gran[1][0],cap_list[2])
                D_e_gran[2] = a
                D_e['grans_s'] = a


def init_edges(D):
    for e in D.edges():
        D_e = D[e[0]][e[1]]
        D_e['grans'] = {}
        D_e['grans_f'] = {}
        D_e['grans_c'] = {}
        D_e['grans_s'] ={}
        D_e['grans_d'] ={}
        D_e['gr_cost'] = 0
        D_e['tr_cost'] = 0
        D_e['dum_cost'] = 0
        D_e['ALPHA'] = {}


#computes the dummy cost of each edge!
def cost_to_edges0(D,cap_list_cost):
    for e in D.edges():
        D_e = D[e[0]][e[1]]
        D_e_weight = D_e['weight']
        D_e_gran = D_e['grans']
        #prices and costs of each edge
        if D_e_gran != {}:
            grans_value = 0
            alpha = 0
            alpha_c = 0
            beta = 0
            gamma = 0
            if D.node[e[1]]['population'] == -1 and D.successors(e[1]) != []:
                #price of f
                cc_list = []
                cc = D_e_gran[0]
                if len(cc) != 0:
                    for i in range(len(cc)):
                        lmnt = cc[i]
                        if lmnt != 0:
                            ind = cc.index(lmnt)
                            cc_list.append(lmnt*cap_list_cost[0][ind])
                alpha = sum(cc_list)
                #price of c
                cc_list = []
                cc = D_e_gran[1]
                if len(cc) != 0:
                    for i in range(len(cc)):
                        lmnt = cc[i]
                        if lmnt != 0:
                            ind = cc.index(lmnt)
                            cc_list.append(lmnt*cap_list_cost[1][ind])
                alpha_c = sum(cc_list)
                #price of s/d
                cc_list = []
                cc = D_e_gran[2]
                if len(cc) != 0:
                    for i in range(len(cc)):
                        lmnt = cc[i]
                        if lmnt != 0:
                            ind = cc.index(lmnt)
                            cc_list.append(lmnt*cap_list_cost[2][ind])
                beta = sum(cc_list)
                #price of d
                cc_list = []
                cc = D_e_gran[3]
                if len(cc) != 0:
                    for i in range(len(cc)):
                        lmnt = cc[i]
                        if lmnt != 0:
                            ind = cc.index(lmnt)
                            cc_list.append(lmnt*cap_list_cost[3][ind])
                gamma = sum(cc_list)
                grans_value = alpha + alpha_c + beta + gamma
            if D.node[e[1]]['population'] != -1:
                ###for leaf nodes
                #price of d
                cc_list = []
                cc = D_e_gran
                if len(cc) != 0:
                    for i in range(len(cc)):
                        for j in range(len(cc[i])):
                            lmnt = cc[i][j]
                            if lmnt != 0:
                                ind = cc[i].index(lmnt)
                                cc_list.append(lmnt*cap_list_cost[i][ind])
                grans_value = sum(cc_list)
            e_cost_gran = grans_value * D_e_weight
            e_cost_trench = 7 * D_e_weight
            e_cost = e_cost_gran + e_cost_trench
            D_e['gr_cost'] = e_cost_gran
            D_e['tr_cost'] = e_cost_trench
            D_e['dum_cost'] = e_cost


#gives efficiency to edges of D
def efficiency_to_edges(D,gg):
    for e in D.edges():
        if (e[0],e[1]) in gg.edges():
            D[e[0]][e[1]]['efficiency'] = gg[e[0]][e[1]]['efficiency']
        if (e[1],e[0]) in gg.edges():
            D[e[0]][e[1]]['efficiency'] = gg[e[1]][e[0]]['efficiency']


#cutoff null leafs from area
def cutoff_null_leafs(D):
    l_cutoff = []
    for n in D.nodes():
        if D.node[n]['population'] == -1 and len(D.successors(n)) == 0:
            l_cutoff.append(n)
            n_pred = D.predecessors(n)[:]
            for i in n_pred:
                if D.node[i]['population'] == -1 and D.out_degree(i) == 1:
                    l_cutoff.append(i)
    for j in l_cutoff:
        D.remove_node(j)


#cutoff_null_leafs0
def cutoff_null_leafs0(g):
    check = [0]
    while len(check) > 0:
        check = [nod for nod in g.degree() if g.degree(nod) == 1 and g.node[nod]['population'] == -1]
        g.remove_nodes_from(check)
###############################################################################
###################### About Caps, Grans & Their Costs ########################
###########################       The End        ##############################
###############################################################################

###############################################################################
########################### Network Cost Dummies ##############################
################                                             ##################
###############################################################################


#given only the G and gamma,
def netwrk_cost_dummy000_best_dhn_0(G,gamma,dhn,cap_list,cap_list_cost):
    g = cluster_to_subready(G,gamma)
    cutoff_null_leafs0(g)
    g.node[dhn]['root_node'] = 1
    inv_or_not = 'notInv'
    l, gg, leafs, null_l = a_graph_efficiency(g,dhn,1,inv_or_not)
    q = a_di_main_paths(G,l)
    sub_list = att_to_subtrees(G,q)[:]
    cost_list = []
    network_cost = 0
    for i in range(len(sub_list)):
        D = sub_list[i]
        #for e in D.edges():
            #D_e = D[e[0]][e[1]]
            #D_e['grans'] = {}
            #D_e['ALPHA'] = {}
            #D_e['dum_cost'] = 0
        init_edges(D)
        init_null(D)
        all_cap_gran_null(D,cap_list) #gives sucgload to the null nodes for not null leafs
        cap_gran_null_null000(D,dhn,cap_list) #gives suc2gload to the null nodes for null nodes
        cap_gran_null_null_null000(D,cap_list) #gives sucggload to the null nodes 
        grans_to_edges0(D,dhn,cap_list)#okz!!!
        grans_again0(D)
        granss0(D)
        grans_to_edges_cool(D,cap_list)
        cost_to_edges0(D,cap_list_cost) #okz!!!!
        efficiency_to_edges(D,gg)
        for e in D.edges():
            network_cost = network_cost + D[e[0]][e[1]]['dum_cost']
        cost_list.append(network_cost)
    for e in g.edges():
        g_e = g[e[0]][e[1]]
        if g_e['grans_f'] == {}:
            g.remove_edge(e[0],e[1])
    return [g, dhn, network_cost]


#given G, gamma and a range percentage rr, returns the Best regarding cost, place for DHN
#d: Inputs: G: the graph
# gamma: a list with the cluster coordinates
# rr: a parameter between 0-1 (default: 0.1) which is used to set the area to look for potential KV 
# cap_list: list with granularities
# cap_list_cost: list with costs of fiber/subducts
# shapeFilePath: string with the directory of the path
# OUTPUT: sorted_best_dhns_list[0]: the x,y coordinates for the best location to place the KV
def find_best_dhn(G,gamma,rr,cap_list,cap_list_cost,shapeFilePath):
    
    tic=timeit.default_timer()# for 3 clusters and the subset shape file of larissa we
    
    # got the following times: 7secs, 29sec, 54 secs
    
    
    #print(G.nodes(data=True)[:])
    g = cluster_to_subready(G,gamma) # prepare the graph
    dhn = centerofmass_graph0(g) # get the center of mass of the graph g. This will be used as initial coordinates
    print("center of mass")
    print(dhn)
    dhn_x = dhn[0] # center of mass x
    dhn_y = dhn[1] # center of mass y 

    if G.node[dhn]['population'] != -1:
        dhn = G.neighbors(dhn)[0] #d: return a list of the nodes connected with the node (dhn) and get the first element of the list
    
    print 'before Execute bomInit Find'    
    bom = bom_init_dhn(G,gamma,dhn,cap_list,cap_list_cost,shapeFilePath) #d: is executed once for each cluster
    ggg_gamma = bom[4] #d: assign the output of bom_init_dhn to variable ggg_gamma
    deg3 = deg_nnn(G,ggg_gamma,3)
    deg3_copy = deg3[:]
    
    
    toc=timeit.default_timer()
    a = int(toc - tic)
    print 'find_bomInit'
    print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds 
    
    tic=timeit.default_timer()# for 3 clusters and the subset shape file of larissa we
    
    #print("deg3")
    #print(deg3) # [(365249.217877, 4385570.498374), (365243.35743499995, 4385053.430597),...]
    #print deg3[0] # (365249.217877, 4385570.498374)

    import math # math.hypot: calculates euclidean distance
    
    deg3Coords_minDistDict = {} #d: a dictionary contains key:value pairs of minimum distance and coords of deg3 nodes (3 junction points)
    for coords in deg3_copy:

        dist = math.sqrt((dhn_x - coords[0])**2 + (dhn_y - coords[1])**2)
        deg3Coords_minDistDict[coords] = dist
    #print deg3Coords_minDistDict
    minCoords = min(deg3Coords_minDistDict, key=deg3Coords_minDistDict.get)
    print minCoords
    
    # if the coordinates already exist in the list of coordinates with the 3way junction then remove it.
    if dhn in deg3_copy:
        deg3_copy.remove(dhn)
    
    minmax_ns = minmaxp(deg3_copy,dhn)
    rmm = rr*(minmax_ns[1][1] - minmax_ns[0][1]) + minmax_ns[0][1]
    cps = cycpoints(dhn,rmm,12)
    cvcps = convex_hull(cps)
    cvcps_l = []
    
    for i in cvcps:
        x = point_to_node(i,g.nodes())
        if x not in cvcps_l:
            cvcps_l.append(x)
            
    minmax_d3_l = []
    for i in deg3:
        if p_convex_hull_dhn(G,dhn,i,cvcps_l):
            minmax_d3_l.append(i)
     
    # 
    
     
         
    best_dhns_list = []
    for i in minmax_d3_l:
        best_dhns_list.append(netwrk_cost_dummy000_best_dhn_0(G,gamma,i,cap_list,cap_list_cost))
    from operator import itemgetter, attrgetter
    sorted_best_dhns_list = sorted(best_dhns_list, key=itemgetter(2))
    
    toc=timeit.default_timer()
    a = int(toc - tic)
    print 'find_rest'
    print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds 
    
    
    #print sorted_best_dhns_list[0] # [<networkx.classes.graph.Graph object at 0x5027fd0>, (364967.530378, 4385309.4983749995), 267676.22769265063]
    
    return sorted_best_dhns_list[0]
 

#find best comP_dhns
def find_best_CO(G,dhns,dhns_info,rr,cap_list_feed,cap_list_cost_feed):
    comP_dhns = centerofmass3(G,dhns_info)
    gamma = change_dims_graph(G)[:]
    g = cluster_to_subready(G,gamma)
    dhn = comP_dhns
    
    deg3 = deg_nnn(G,g,3)
    deg3_copy = deg3[:]
    if dhn in deg3_copy:
        deg3_copy.remove(dhn)
    
    minmax_ns = minmaxp(deg3_copy,dhn)
    rmm = rr*(minmax_ns[1][1] - minmax_ns[0][1]) + minmax_ns[0][1]
    
    cps = cycpoints(dhn,rmm,12)
    cvcps = convex_hull(cps)
    cvcps_l = []
    for i in cvcps:
        x = point_to_node(i,g.nodes())
        if x not in cvcps_l:
            cvcps_l.append(x)
    
    minmax_d3_l = []
    for i in deg3:
        if p_convex_hull_dhn(G,dhn,i,cvcps_l):
            minmax_d3_l.append(i)
    
    best_CO_list = []
    for comP_dhns in minmax_d3_l:
    
        dhns_splices = []
        s = 0
        for i in range(len(dhns_info)):
            s = s + dhns_info[i][2]
        dhns_splices.append([comP_dhns,s])
        for i in range(len(dhns)):
            dhns_splices.append([dhns[i],dhns_info[i][2]])
        #
        g_feeder = feeder_graph(G,comP_dhns,dhns)
        init_edges(g_feeder)
        #give to dhns the #splices attribute
        for ds in dhns_splices:
            g_feeder.node[ds[0]]['#splices'] = ds[1]
        init_nodes(g_feeder,comP_dhns,dhns)
        gx, fsd, eall, nall = cap_gran_cost_feed_costall(G,g_feeder,comP_dhns,dhns,cap_list_feed,cap_list_cost_feed)
        best_CO_list.append([comP_dhns,costs_tr(gx)[1]])
    
    from operator import itemgetter, attrgetter
    sorted_best_CO_list = sorted(best_CO_list, key=itemgetter(1))
    
    return sorted_best_CO_list[0]



#for iteration to count the cost of null nodes
#following to netwrk_cost_dummy2
#used in alphas!!!
#akrivos idio me to netwrk_cost_dummy000 apla sto output exei to sub_list ;)
def netwrk_cost_dummy000sub(G,g,dhn,cap_list,cap_list_cost,dist_feed_boolean):
    if (dist_feed_boolean=='distribution'):
        cutoff_null_leafs0(g)
    g.node[dhn]['root_node'] = 1
    inv_or_not = 'notInv'
    l, gg, leafs, null_l = a_graph_efficiency(g, dhn,1,inv_or_not)
    q = a_di_main_paths(G,l)
    sub_list = att_to_subtrees(G,q)[:]
    cost_list = []
    network_cost = 0
    for i in range(len(sub_list)):
        D = sub_list[i]
        init_edges(D)
        init_null(D)
        all_cap_gran_null(D,cap_list) #gives sucgload to the null nodes for not null leafs
        cap_gran_null_null000(D,dhn,cap_list) #gives suc2gload to the null nodes for null nodes
        cap_gran_null_null_null000(D,cap_list) #gives sucggload to the null nodes 
        grans_to_edges0(D,dhn,cap_list)#okz!!!
        grans_again0(D)
        granss0(D)
        grans_to_edges_cool(D,cap_list)
        cost_to_edges0(D,cap_list_cost) #okz!!!!
        efficiency_to_edges(D,gg)
        for e in D.edges():
            network_cost = network_cost + D[e[0]][e[1]]['dum_cost']
        cost_list.append(network_cost)
        for n in D.nodes():
            if n != dhn:
                g.node[n]['sucggload'] = str(D.node[n]['sucggload'])
                g.node[n]['sucgload'] = str(D.node[n]['sucgload'])
                g.node[n]['suc2gload'] = str(D.node[n]['suc2gload'])
        for e in D.edges():
            ee = (e[0],e[1])
            D_e = D[e[0]][e[1]]
            #D_e['grans'] = {}
            #D_e['grans_c'] = {}
            #D_e['ALPHA'] = {}
            if (e[0],e[1]) in g.edges():
                g[e[0]][e[1]]['grans_f'] = str(D[e[0]][e[1]]['grans_f'])
                g[e[0]][e[1]]['grans_c'] = str(D[e[0]][e[1]]['grans_c'])
                g[e[0]][e[1]]['grans_s'] = str(D[e[0]][e[1]]['grans_s'])
                g[e[0]][e[1]]['grans_d'] = str(D[e[0]][e[1]]['grans_d'])
                g[e[0]][e[1]]['gr_cost'] = str(D[e[0]][e[1]]['gr_cost'])
                g[e[0]][e[1]]['tr_cost'] = str(D[e[0]][e[1]]['tr_cost'])
                g[e[0]][e[1]]['dum_cost'] = str(D[e[0]][e[1]]['dum_cost'])
                g[e[0]][e[1]]['grans'] = str(D[e[0]][e[1]]['grans'])
                g[e[0]][e[1]]['ALPHA'] = str(D[e[0]][e[1]]['ALPHA'])
                g[e[0]][e[1]]['efficiency'] = str(D[e[0]][e[1]]['efficiency'])
            if (e[1],e[0]) in g.edges():
                g[e[1]][e[0]]['grans_f'] = str(D[e[0]][e[1]]['grans_f'])
                g[e[1]][e[0]]['grans_c'] = str(D[e[0]][e[1]]['grans_c'])
                g[e[1]][e[0]]['grans_s'] = str(D[e[0]][e[1]]['grans_s'])
                g[e[1]][e[0]]['grans_d'] = str(D[e[0]][e[1]]['grans_d'])
                g[e[1]][e[0]]['gr_cost'] = str(D[e[0]][e[1]]['gr_cost'])
                g[e[1]][e[0]]['tr_cost'] = str(D[e[0]][e[1]]['tr_cost'])
                g[e[1]][e[0]]['dum_cost'] = str(D[e[0]][e[1]]['dum_cost'])
                g[e[1]][e[0]]['grans'] = str(D[e[0]][e[1]]['grans'])
                g[e[1]][e[0]]['ALPHA'] = str(D[e[0]][e[1]]['ALPHA'])
                g[e[1]][e[0]]['efficiency'] = str(D[e[0]][e[1]]['efficiency'])
    for e in g.edges():
        g_e = g[e[0]][e[1]]
        if g_e['grans_f'] == {}:
            g.remove_edge(e[0],e[1])
    return [g, dhn, network_cost, sub_list]



#for output in .shp. (after we find the minimum cost network)
#sto output exei k ta directed sub_graphs tou g
# einai sxedon idio me to netwrk_cost_dummy2 ektos ton del k tou output

#d: dist_feed_boolean: a parameter which takes a string as a value: 'distribution' or 'feeder'. Used in order to 
# merge functions which are used both in feeder and distribution network calculation and differ only by some lines  
# #d: function used both for feeder/distribution network
# d: clust_invs_boolean is a string variable which takes values either 'clust_invs_used' (a function) or 'clust_invs_not_used'
def netwrk_cost_dummy22(G,g,dhn,cap_list,cap_list_cost,dist_feed_boolean,clust_invs_boolean): 
    if (dist_feed_boolean=='distribution'):
        cutoff_null_leafs0(g)
    g.node[dhn]['root_node'] = 1
    inv_or_not = 'notInv'
    l, gg, leafs, null_l = a_graph_efficiency(g, dhn,1,inv_or_not)
    q = a_di_main_paths(G,l)
    sub_list = att_to_subtrees(G,q)[:]
    cost_list = []
    network_cost = 0
    for i in range(len(sub_list)):
        D = sub_list[i]
        init_edges(D)
        init_null(D)
        all_cap_gran_null(D,cap_list) #gives sucgload to the null nodes for not null leafs
        cap_gran_null_null000(D,dhn,cap_list) #gives suc2gload to the null nodes for null nodes
        cap_gran_null_null_null000(D,cap_list) #gives sucggload to the null nodes 
        grans_to_edges0(D,dhn,cap_list)#okz!!!
        grans_again0(D)
        granss0(D)
        grans_to_edges_cool(D,cap_list)
        cost_to_edges0(D,cap_list_cost) #okz!!!!
        efficiency_to_edges(D,gg)
        for e in D.edges():
            network_cost = network_cost + D[e[0]][e[1]]['dum_cost']
        cost_list.append(network_cost)
        for n in D.nodes():
            if n != dhn:
                g.node[n]['sucggload'] = str(D.node[n]['sucggload'])
                g.node[n]['sucgload'] = str(D.node[n]['sucgload'])
                g.node[n]['suc2gload'] = str(D.node[n]['suc2gload'])
        for e in D.edges():
            ee = (e[0],e[1])
            D_e = D[e[0]][e[1]]
            #D_e['grans'] = {}
            #D_e['grans_c'] = {}
            #D_e['ALPHA'] = {}
            if (e[0],e[1]) in g.edges():
                g[e[0]][e[1]]['grans_f'] = str(D[e[0]][e[1]]['grans_f'])
                g[e[0]][e[1]]['grans_c'] = str(D[e[0]][e[1]]['grans_c'])
                g[e[0]][e[1]]['grans_s'] = str(D[e[0]][e[1]]['grans_s'])
                g[e[0]][e[1]]['grans_d'] = str(D[e[0]][e[1]]['grans_d'])
                g[e[0]][e[1]]['gr_cost'] = str(D[e[0]][e[1]]['gr_cost'])
                g[e[0]][e[1]]['tr_cost'] = str(D[e[0]][e[1]]['tr_cost'])
                g[e[0]][e[1]]['dum_cost'] = str(D[e[0]][e[1]]['dum_cost'])
                g[e[0]][e[1]]['grans'] = str(D[e[0]][e[1]]['grans'])
                g[e[0]][e[1]]['ALPHA'] = str(D[e[0]][e[1]]['ALPHA'])
                g[e[0]][e[1]]['efficiency'] = str(D[e[0]][e[1]]['efficiency'])
            if (e[1],e[0]) in g.edges():
                g[e[1]][e[0]]['grans_f'] = str(D[e[0]][e[1]]['grans_f'])
                g[e[1]][e[0]]['grans_c'] = str(D[e[0]][e[1]]['grans_c'])
                g[e[1]][e[0]]['grans_s'] = str(D[e[0]][e[1]]['grans_s'])
                g[e[1]][e[0]]['grans_d'] = str(D[e[0]][e[1]]['grans_d'])
                g[e[1]][e[0]]['gr_cost'] = str(D[e[0]][e[1]]['gr_cost'])
                g[e[1]][e[0]]['tr_cost'] = str(D[e[0]][e[1]]['tr_cost'])
                g[e[1]][e[0]]['dum_cost'] = str(D[e[0]][e[1]]['dum_cost'])
                g[e[1]][e[0]]['grans'] = str(D[e[0]][e[1]]['grans'])
                g[e[1]][e[0]]['ALPHA'] = str(D[e[0]][e[1]]['ALPHA'])
                g[e[1]][e[0]]['efficiency'] = str(D[e[0]][e[1]]['efficiency'])
    for e in g.edges():
        g_e = g[e[0]][e[1]]
        if g_e['grans_f'] == {}:
            g.remove_edge(e[0],e[1])
    g.node[dhn]['sucggload'] = str(D.node[dhn]['sucggload'])
    g.node[dhn]['sucgload'] = str(D.node[dhn]['sucgload'])
    g.node[dhn]['suc2gload'] = str(D.node[dhn]['suc2gload'])
    for u,v,d in g.edges(data=True):
        if 'ALPHA' in d:
            del d['ALPHA']
        if 'grans' in d:
            del d['grans']
        if 'grans_c' in d:
            del d['grans_c']
        if 'mun_code' in d:
            del d['mun_code']
        if 'mun_name' in d:
            del d['mun_name']
        if 'name' in d:
            del d['name']
        if 'population' in d:
            del d['population']
        if 'length' in d:
            del d['length']
        if 'x___gid' in d:
            del d['x___gid']
        if 'building_i' in d:
            del d['building_i']
        if 'gid' in d:
            del d['gid']
        if 'id' in d:
            del d['id']
        if 'x_gid' in d:
            del d['x_gid']
        if 'block_id' in d:
            del d['block_id']
    for n,d in g.nodes(data=True):
        if 'suc2gload' in d:
            del d['suc2gload']
        if 'sucgload' in d:
            del d['sucgload']
        if 'sucggload' in d:
            del d['sucggload']
    if (clust_invs_boolean == 'clust_invs_used'):
        return [g, dhn, network_cost]
    elif (clust_invs_boolean == 'clust_invs_not_used'):
        return [g, dhn, network_cost,sub_list]


    
###############################################################################
########################### Network Cost Dummies ##############################
###########################       The End        ##############################
###############################################################################

###############################################################################
###################### About Block IDs and NNN of them  #######################
################                                             ##################
###############################################################################


#returns 3dim list of block nodes,sumofmass of them,and the Node 
def graph_blocks_all(G):
    l_ids = []
    #creates list with all block ids except null nodes -1
    for n in G.nodes():
        if G.node[n]['block_id'] != -1:
            l_ids.append(G.node[n]['block_id'])
    new_l = []
    for i in l_ids:
        if i not in new_l:
            new_l.append(i)
    #creates empty lists
    list_ids = []
    for j in range(len(new_l)):
        list_ids.insert(0,[])
    #put nodes to lists according to their block_id
    for ii in new_l:
        for nn in G.nodes():
            if G.node[nn]['block_id'] == ii:
                list_ids[new_l.index(ii)].append(nn)
    #computes som of block_nodes and the Node lmnt
    list_ids1 = []
    for l in list_ids:
        lista = change_dims(G,l)[:]
        list_ids1.append([l,cluster_m(G,l),centerofmass0(G,l)])
    return list_ids1


#returns a list with the ids of all the blocks of G
def blocks_id(G):
    l_ids = []
    #creates list with all block ids except null nodes -1
    for n in G.nodes():
        if G.node[n]['block_id'] != -1 and G.node[n]['block_id'] not in l_ids:
            l_ids.append(G.node[n]['block_id'])
    return l_ids


#returns a list with the not null nodes of a block with given id
def bid_nodes(G,idi):
    bid = blocks_id(G)[:]
    list_ids = []
    for n in G.nodes():
        if G.node[n]['block_id'] == idi:
            list_ids.append(n)
    return list_ids
###############################################################################
###################### About Block IDs and NNN of them  #######################
###########################       The End        ##############################
###############################################################################

###############################################################################
############################# About Writing SHP  ##############################
################                                             ##################
################################################################################
### DIFFERENCE FROM THANASIS ALL_CAPS: ADDED shapeFileNameOne,shapeFileNameTwo

#d: This definition is used in order to output the edges and nodes into shapefiles.
# Inputs: The graph G, the directorty (string) to create the shapefile, 
# the two names of the shapefiles (one for the nodes and one for the edges)
def write_shp(G, outdir,shapeFileNameOne,shapeFileNameTwo):
    try:
        from osgeo import ogr
    except ImportError:
        raise ImportError("write_shp requires OGR: http://www.gdal.org/")
    def netgeometry(key, data, node = False):
        if not node:
            if data.has_key('Wkb'):
                geom = ogr.CreateGeometryFromWkb(data['Wkb'])
            elif data.has_key('Wkt'):
                geom = ogr.CreateGeometryFromWkt(data['Wkt'])
            elif type(key[0]).__name__  == 'tuple': # edge keys are packed tuples
                geom = ogr.Geometry(ogr.wkbLineString)
                _from, _to = key[0], key[1]
                try:
                    geom.SetPoint(0, *_from)
                    geom.SetPoint(1, *_to)
                except TypeError:
                    # assume user used tuple of int and choked ogr
                    _ffrom = [float(x) for x in _from]
                    _fto = [float(x) for x in _to]
                    geom.SetPoint(0, *_ffrom)
                    geom.SetPoint(1, *_fto)
            else:
                geom = ogr.Geometry(ogr.wkbPoint)
                try:
                    geom.SetPoint(0, *key)
                except TypeError:
                    # assume user used tuple of int and choked ogr
                    fkey = [float(x) for x in key]
                    geom.SetPoint(0, *fkey)
        else:
                geom = ogr.Geometry(ogr.wkbPoint)
                try:
                    geom.SetPoint(0, *key)
                except TypeError:
                    # assume user used tuple of int and choked ogr
                    fkey = [float(x) for x in key]
                    geom.SetPoint(0, *fkey)
        return geom
    def create_feature(geometry, lyr, attributes=None):
        feature = ogr.Feature(lyr.GetLayerDefn())
        feature.SetGeometry(g)
        if attributes != None:
            for field, data in attributes.iteritems(): 
                feature.SetField(field,data)
        lyr.CreateFeature(feature)
        feature.Destroy()
    drv = ogr.GetDriverByName("ESRI Shapefile")
    shpdir = drv.CreateDataSource(outdir)
    try:
        shpdir.DeleteLayer(shapeFileNameOne)
    except:
        pass
    nodes = shpdir.CreateLayer(shapeFileNameOne, None, ogr.wkbPoint)
    #print nodes
    #sys.exit(1)
    nodeDict = dict(G.nodes(data=True))
    OGRTypes = {int:ogr.OFTInteger, str:ogr.OFTString, float:ogr.OFTReal}
    fields = {}
    attributes = {}
    for n in G:
        data = G.node[n].values() or [{}]
        g = netgeometry(n, data[0], True)
        for key, data in nodeDict[n].iteritems():
            if (key != 'Json' and key != 'Wkt' and key != 'Wkb' 
                and key != 'ShpName'):
                if key not in fields:
                    if type(data) in OGRTypes:
                         fields[key] = OGRTypes[type(data)]
                    else:
                         fields[key] = ogr.OFTString
                    newfield = ogr.FieldDefn(key, fields[key])
                    nodes.CreateField(newfield)
                    attributes[key] = data
                else:
                    attributes[key] = data
        create_feature(g, nodes, attributes)
    try:
        shpdir.DeleteLayer(shapeFileNameTwo)
    except:
        pass
    edges = shpdir.CreateLayer(shapeFileNameTwo, None, ogr.wkbLineString)
    # New edge attribute write support merged into edge loop
    fields = {}
    attributes = {}
    OGRTypes = {int:ogr.OFTInteger, str:ogr.OFTString, float:ogr.OFTReal}
    for e in G.edges(data=True):
        data = G.get_edge_data(*e)
        g = netgeometry(e, data)
        # Loop through data in edges
        for key, data in e[2].iteritems():
            # Reject data not for attribute table
            if (key != 'Json' and key != 'Wkt' and key != 'Wkb' 
                and key != 'ShpName'):
                  # Add new attributes for each feature
                  if key not in fields:
                     if type(data) in OGRTypes:
                         fields[key] = OGRTypes[type(data)]
                     else:
                         fields[key] = ogr.OFTString
                     newfield = ogr.FieldDefn(key, fields[key])
                     edges.CreateField(newfield)
                     attributes[key] = data
                  # Create dict of single feature's attributes
                  else:
                     attributes[key] = data
         # Create the feature with attributes
        create_feature(g, edges, attributes)
    nodes, edges = None, None
###############################################################################
############################# About Writing SHP  ##############################
###########################       The End        ##############################
###############################################################################

###############################################################################
############################# About Clustering ################################
##################                                          ###################
###############################################################################
#MUST for em
def acluster2(Q,ccc,ki):
    S = Q[:]
    com_l = ccc
    k = ki
    clusters = []
    distance_l = []
    min_ind = 0
    x_l = []
    D_l = []
    cl = []
    for i in range(k): #creates k-clusters
        cl.insert(0,[])
    for j in range(len(S)):
        x = S[j] #choose a point from S
        dis_l = []
        min_dis_l = []
        for i in range(k): #list of distances of x from coms
            dis_l.append([adistance(x,com_l[i]), i])
        from operator import itemgetter, attrgetter
        min_dis_l = min(dis_l, key=itemgetter(0))
        cl[min_dis_l[1]].append(x)
    clusters = cl
    comall0 = []
    for i in range(k):
        comall0.append((point_to_node(centerofmass(clusters[i]),S)[0],point_to_node(centerofmass(clusters[i]),S)[1]))
    ll = []
    for xx in comall0:
        dd_l = []
        ssorted_d_l = []
        iinl = []
        for j in range(len(S)):
            dd_l.append([S[j],adistance(xx,S[j])])
        from operator import itemgetter, attrgetter
        ssorted_d_l = sorted(dd_l, key=itemgetter(1))
        ll.append(ssorted_d_l[0][0])
    comall0 = ll[:]
    return([comall0, clusters, x_l])


#MUST for em
#ak-com clustering
def akcom0(Q0,ccc0,ki0,it0):
    C = acluster2(Q0,ccc0,ki0)
    Ca = [0]
    Cb = [1]
    for i in range(it0-1):
        if Ca != Cb:
            C = acluster2(Q0,C[0],ki0)
            Ca = Cb
            Cb = C[0]
        else:
            break
    return([C,i])



def akcom0_smsms_fixed_norm(G_input,kk):
    k_init = kk #d: number of clusters we want (input from form)
    Gin = G_input.copy() #d: copy the graph
    P_init = graph_c_vec(Gin)[:] # clear the previous list
    P_plith = sumofmass(P_init) # ) # #d: total number of population
    import math
    # WHY WE ADD +1
    max_frac = float(P_plith)/float(k_init+1)  #d: it was like this float(P_plith)/float(k_init+1) 
    cluster_plith_max = math.ceil(max_frac) #max som. per cluster #d: get the ceiling value of max_frac (upper rounding of value)
    med_plith = math.ceil(P_plith/len(P_init)) #median of the plithismos/node
    max_plith = cluster_plith_max - med_plith #synthiki gia to som (d:sum of masses) ton clusters
    #max_plith = cluster_plith_max - 0.08*cluster_plith_max #synthiki gia to som ton clusters

    #
    CL_list = []
    while  kk != 1:
        X_minus = []
        X_plus = []
        i = 0 #seperates the input Points to 2 sets. 
        P_init0 = graph_c_vec(Gin)[:]
        while i < len(P_init0):
            if P_init0[i][2] == 0:
                X_minus.append(P_init0[i])
                i = i + 1
            else:
                X_plus.append(P_init0[i])
                i = i +1
        P_init = X_plus[:] 
        P00 = P_init[:]
        C = []
        
        
        
        #d: Definition: akcom0(Q0, ccc0, ki0, it0)
        # Description: ki0 means clustering algorithm with it0 iterations on Q0 list as initial input.
        # Input:1) Q0 the elements of Q0 are at least 2-dimensional vectors
        # 2) ran_points(P00,kk): definition ranpoints(): creates initial centers of coordinates of clusters
        # 3) kk: total number of clusters we want
        # 4) 23: GOD KNOWS?
        C = akcom0(P00,ran_points(P00,kk),kk,23) #em #d: what is this 23?
        #
        Cmass = print_mass(G_input,C[0][1])
        mi = min(Cmass)
        mi_index = Cmass.index(mi)
        #make the output of akcom0 to a list with the clusters
        gammas = []
        for c in C[0][1]:
            c_l = []
            for i in c:
                c_l.append([i[0],i[1]])
            gammas.append(c_l)
        #create the corresponding graph of the cluster
        gammas_g0 = cluster_to_subready(Gin,gammas[mi_index]) #good
        nodes_l = []
        nodes_l = gammas_g0.nodes()[:]
        G1 = Gin.copy()
        #remove from G1 the nodes of g0
        for i in nodes_l:
            G1.remove_node(i)
        #find the isolated nodes, if they exist
        iso_nodes = []
        for i in G1.nodes():
            if G1.degree(i) == 0:
                iso_nodes.append(i)
        #remove isolated nodes from G1
        for i in iso_nodes:
            G1.remove_node(i)
            nodes_l.append(i)
        #find the nodes of the connected_components of G1
        CG1_nodes=nx.connected_components(G1)[:]
        


        #remove the maximum (it is the cluster we have chosen)
        CG1_nodes.remove(CG1_nodes[0])
        #add all the nodes of all the subgraphs of CG1_nodes to nodes_l
        for c in CG1_nodes:
            for i in c:
                if i not in nodes_l:
                    nodes_l.append(i)
        #
        gg = Gin.subgraph(nodes_l)
        comP = centerofmass_graph0(gg)
        #check if sumgg > max_plith or not
        sumgg = sumofmass_graph(gg)
        #take all ems from comP
        l_paths0 = []
        for i in Gin.nodes():
            l_paths0.append([i,adistance(i,comP)])
        #creates the pairs [node,sp-distance from comP]
        l = l_paths0[:]
        #ordering from min -> max em-distance
        from operator import itemgetter, attrgetter
        sorted_l = sorted(l, key=itemgetter(1))
        #filling up the sp-cluster
        cl_nodes = [] #nodes of the cluster
        s_nodes = 0
    #
        for lmnt in sorted_l:
            if s_nodes < max_plith:
                if Gin.node[lmnt[0]]['population'] == -1 and s_nodes + Gin.node[lmnt[0]]['population'] <= max_plith:
                    cl_nodes.append(lmnt[0])
                if Gin.node[lmnt[0]]['population'] != -1 and s_nodes + Gin.node[lmnt[0]]['population'] <= max_plith:
                    s_nodes = s_nodes + Gin.node[lmnt[0]]['population']
                    cl_nodes.append(lmnt[0])
            else:
                break
        #
        G2 = Gin.copy()
        G0 = Gin.copy()
        for i in cl_nodes:
            G2.remove_node(i)
        #find the isolated nodes, if they exist
        iso_nodes0 = []
        for i in G2.nodes():
            if G2.degree(i) == 0:
                iso_nodes0.append(i)
        #
        if len(iso_nodes) != 0:
            #remove iso_nodes0 from cl_nodes
            for i in iso_nodes0:
                ni = Gin.neighbors(i)[0]
                if ni in cl_nodes:
                    cl_nodes.remove(ni)
            #normalize nodes
            n_l = []
            for i in cl_nodes:
                if Gin.node[i]['population'] != -1:
                    n_l.append(i)
            #graph
            gg00 = cluster_to_subready(Gin,n_l)
            #add all the nnn that do not already belong to n_l and they have neighbor in n_l
            n_ll = n_l[:]
            for i in Gin.nodes():
                if Gin.node[i]['population'] != -1:
                    ni = Gin.neighbors(i)[0]
                    if ni in gg00.nodes() and ni not in n_ll:
                        n_ll.append(ni)
            gg000 = cluster_to_subready(Gin,n_ll)
            #
            G3 = Gin.copy()
            for i in gg000.nodes():
                G3.remove_node(i)
            #find the isolated nodes, if they exist
            iso_nodes00 = []
            for i in G3.nodes():
                if G3.degree(i) == 0:
                    iso_nodes00.append(i)
            #add iso to n_ll
            for i in iso_nodes00:
                n_ll.append(i)
            gg1 = cluster_to_subready(Gin,n_ll)
            #
            for i in gg1.nodes():
                if i in Gin.nodes():
                    Gin.remove_node(i)
            #find the isolated nodes, if they exist
            iso_nodes000 = []
            for i in Gin.nodes():
                if Gin.degree(i) == 0:
                    iso_nodes000.append(i)
            #add iso to n_lll
            n_lll = gg1.nodes()[:]
            for i in iso_nodes000:
                n_lll.append(i)
            for i in iso_nodes000:
                if i not in n_lll:
                    n_lll.append(i)
            #remove iso from Gin
            for i in n_lll:
                if i in Gin.nodes():
                    Gin.remove_node(i)
            #
            #find the nodes of the connected_components of G1
            CGin_nodes=nx.connected_components(Gin)[:]
            #remove the maximum (it is the cluster we have chosen)
            if len(CGin_nodes) != 0:
                CGin_nodes.remove(CGin_nodes[0])
            #add all the nodes of all the subgraphs of CG1_nodes to nodes_l
            CG_l = []
            for c in CGin_nodes:
                for i in c:
                    if i not in n_lll:
                        CG_l.append(i)
            for i in CG_l:
                n_lll.append(i)
            #
            #remove iso from Gin
            for i in n_lll:
                if i in Gin.nodes():
                    Gin.remove_node(i)
            #
        #gg11 = cluster_to_subready(Gin,n_lll)
        else:
            for i in cl_nodes:
                if i in Gin.nodes():
                    Gin.remove_node(i)
            n_lll = cl_nodes[:]
        #########################################################################
        g_nlll = cluster_to_subready(G_input,n_lll)
        #comPg = centerofmass_graph(g_nlll) we will choose for comPg the farest lmnt of g_nlll.nodes
        nn = []
        for i in g_nlll.nodes():
            if G_input.node[i]['population'] == -1:
                nn.append(i)
        #
        ms = minmaxp(nn,centerofmass_graph(g_nlll))
        comPg = ms[1][0]
        #take all sps from comP
        l_paths00 = []
        l_paths00 = nx.single_source_dijkstra_path_length(g_nlll,comPg)
        #creates the pairs [node,sp-distance from comP]
        lg = []
        for n in g_nlll.nodes():
            lg.append([n,l_paths00[n]])
        #ordering from min -> max sp-distance
        from operator import itemgetter, attrgetter
        sorted_lg = sorted(lg, key=itemgetter(1))
        #filling up the sp-cluster
        cll_nodes = [] #nodes of the cluster
        ss_nodes = 0
        for lmnt in sorted_lg:
            if G_input.node[lmnt[0]]['population'] != -1 and ss_nodes + G_input.node[lmnt[0]]['population'] <= max_plith:
                ss_nodes = ss_nodes + G_input.node[lmnt[0]]['population']
                cll_nodes.append(lmnt[0])
        #
        g_e = cluster_to_subready(g_nlll,cll_nodes)
        n_lll_g_e = g_e.nodes()[:]
        #
        #remove all nodes of g_e from G0
        for i in g_e.nodes():
            if i in G0.nodes():
                G0.remove_node(i)
        #find the nodes of the connected_components of G1
        CGin_nodes0 = []
        CGin_nodes0=nx.connected_components(G0)[:]
        #remove the maximum (it is the cluster we have chosen)
        if len(CGin_nodes0) != 0:
            CGin_nodes0.remove(CGin_nodes0[0])
        #add all the nodes of all the subgraphs of CG1_nodes to nodes_l
        CG_l0 = []
        for c in CGin_nodes0:
            for i in c:
                if i not in g_e.nodes():
                    CG_l0.append(i)
        for i in CG_l0:
            n_lll_g_e.append(i)
        for i in CG_l0:
            if i in G0.nodes():
                G0.remove_node(i)
        Gin = 0
        Gin = G0.copy()
        #########################################################################
        kk = kk -1
        CL_list.append(n_lll_g_e)
        # ADD VALUE TO CSV
        '''
        with open('csv/clusterCoords.csv', 'w') as f:
            writer = csv.writer(f)
            writer.writerows(n_lll_g_e)
        '''
    CL_list.append(Gin.nodes())
    return CL_list


#normalization of the clusters above
def norm_akcom0_smsms_fixed_norm(cls00,kk):
    cls000 = []
    cl = []
    for c in cls00:
            for i in c:
                if i not in cl:
                    cl.append(i)
    #
    clc = cl[:]
    k = 0
    while k != kk:
        l = []
        for i in cls00[k]:
            if i in clc:
                l.append(i)
                cl.remove(i)
            clc = cl[:]
            #print(l)
        cls000.append(l)
        k = k +1
    return cls000


def akcom0_smsms_fixed_norm_max_mass_only(G_input,kk):
    k_init = kk
    Gin = G_input.copy()
    P_init = graph_c_vec(Gin)[:]
    P_plith = sumofmass(P_init) #global
    import math
    max_frac = float(P_plith)/float(k_init)
    cluster_plith_max = math.ceil(max_frac) #max som. per cluster
    med_plith = math.ceil(P_plith/len(P_init)) #median of the plithismos/node
    max_plith = cluster_plith_max - 2*med_plith #synthiki gia to som ton clusters
    return max_plith


###############################################################################
############################# About Clustering ################################
###########################       The End        ##############################
###############################################################################

###############################################################################
####################### About Efficiencies & Invs #############################
##################                                          ###################
###############################################################################

#d: inv_or_not is a string variable, which takes two values. Either 'Inv' or 'notInv'. Its used to execute function 
# depending on different cases (merging almost identical functions)
def a_graph_efficiency(Gke,i_node,nu,inv_or_not):
    
    tic=timeit.default_timer()
    
    G = Gke
    alpha = aprims_mst(G,'weight') #our spanning tree
    # define the mst graph
    GG=nx.Graph()
    #GG.add_edges_from(alpha)
    GG.add_nodes_from(G.nodes())
    #get node attributes info
    nx.set_node_attributes(GG,'population', nx.get_node_attributes(G,'population'))
    GG.add_edges_from(alpha)
    #give the weights
    for e in GG.edges():
        if e in G.edges():
            GG.add_edge(e[0],e[1],weight = G.edge[e[0]][e[1]]['weight'])
        if (e[1],e[0]) in G.edges():
            GG.add_edge(e[0],e[1],weight = G.edge[e[1]][e[0]]['weight'])
    #take all the sps from chosen init_node = 'O'
    init_node = i_node
    #to xreiazomaste k gia to cable cost!
    l = []
    for i in GG.nodes():
        if i != init_node:
            if nu == 0: #avoid null nodes!
                if GG.node[i]['population'] != -1: #avoid null nodes! (we can change it later and put 'population' =-1 and for the sum of loads if 'population' == -1 then 0 will be added to the sum)
                    nL_ON = [] #first the nodes
                    list_ON = nx.dijkstra_path(GG,init_node,i)[:]
                    #now the edges of the path
                    for ii in range(len(list_ON)-1):
                        nL_ON.append((list_ON[ii],list_ON[ii+1]))
                    l.append(nL_ON)
            if nu == 1: #accept all nodes!
                nL_ON = [] #first the nodes
                list_ON = nx.dijkstra_path(GG,init_node,i)[:]
                #now the edges of the path
                for ii in range(len(list_ON)-1):
                    nL_ON.append((list_ON[ii],list_ON[ii+1]))
                l.append(nL_ON)
    #dimiourgoume lista pou periexei ola ta main paths! apo ton init_node
    list_all = []
    for k in range(len(GG.edges(init_node))):
        list_init = []
        for i in range(len(l)):
            for j in range(len(l[i])):
                if l[i][j][0] == init_node and l[i][j][1] == GG.edges(init_node)[k][1]:
                    list_init.append(l[i])
        list_all.append(list_init)
    #sorted list_init
    lista_all = []
    for j in range(len(list_all)):
        lista_all.append(sorted(list_all[j]))
    #Given an INIT NODE 
    # ALL IN ONE STROKE!!!!!
    g= GG.nodes()
    g.remove(init_node)
    for iiii in g:
        #find subtrees of root
        root = iiii
        #search in main paths for root and returns the subtree of it
        #saves also the weight of its previous edge #! 
        root_list = []
        leafs_list = []
        previous_w = float(0)
        for i in range(len(lista_all)):
            for j in range(len(lista_all[i])):
                for k in range(len(lista_all[i][j])):
                    if lista_all[i][j][k][0] == root:
                        root_edge = lista_all[i][j][k-1] #i akmi tis opoias ypologizoume to edge_efficiency
                        r_edge = root_edge #we use it later to define the efficiency
                        for ii in range(lista_all[i][j].index(lista_all[i][j][k]),len(lista_all[i][j])):
                            if lista_all[i][j][ii] not in root_list:
                                root_list.append(lista_all[i][j][ii])
                        previous_w = GG[lista_all[i][j][k-1][0]][lista_all[i][j][k-1][1]]['weight']
                    if lista_all[i][j][len(lista_all[i][j])-1][1] == root: #leaf case
                        root_edge_leaf = lista_all[i][j][len(lista_all[i][j])-1]
                        leafs_list.append(root_edge_leaf)
        #to give the weight_info to an edge, we take the end node of it and compute the weight_of its subtree
        #and then add it to the weight of it
        #weight and load of the subtree (here weight is the distance between two consecutive nodes)
        subtree_w = float(0)
        load = float(0)
        load_list = []
        if root_list == []: #leaf case
            subtree_w = 0
            previous_w = GG[root_edge_leaf[0]][root_edge_leaf[1]]['weight']
            if GG.node[root_edge_leaf[0]]['population'] == -1: #dealing with null_nodes
                load = float(0 + GG.node[root_edge_leaf[1]]['population'])
                r_edge = root_edge_leaf
            else:
                load = float(GG.node[root_edge_leaf[0]]['population'] + GG.node[root_edge_leaf[1]]['population'])
                r_edge = root_edge_leaf
        else:
            for i in range(len(root_list)):
                try:
                    subtree_w = subtree_w + GG[root_list[i][0]][root_list[i][1]]['weight']
                except:
                    print root_list[i]
                if root_list[i][0] not in load_list:
                    if GG.node[root_list[i][0]]['population'] != -1:
                        load = load + GG.node[root_list[i][0]]['population']
                    else:
                        load = load + 0
                    load_list.append(root_list[i][0])
                if root_list[i][1] not in load_list:
                    if GG.node[root_list[i][1]]['population'] != -1:
                        load = load + GG.node[root_list[i][1]]['population']
                    else:
                        load = load + 0
                    load_list.append(root_list[i][1])
        total_w = previous_w + subtree_w
        total_load = load
        #edge_efficiency = total_load / total_w #people/meters
        if total_load != 0 :
            edge_efficiency = float(total_w) / total_load #meters/people
        else:
            edge_efficiency = 0
        #gives to the edge the edge_efficiency!!!
        GG[r_edge[0]][r_edge[1]]['efficiency'] = edge_efficiency
        if (inv_or_not == 'Inv'):
            GG[r_edge[0]][r_edge[1]]['total_w'] = total_w
            GG[r_edge[0]][r_edge[1]]['total_load'] = total_load
    null_list = []
    for jk in GG.nodes(): #creates a list with null nodes
        if GG.node[jk]['population'] == -1:
            null_list.append(jk)
            
            
    toc=timeit.default_timer()
    a = int(toc - tic)
    print 'efficiency'
    print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds
    
    return [lista_all,GG,leafs_list,null_list]


#given the leaf_node with the worst efficiency computes the new efficiencys of its path if we cut it out
#moreover it removes the null_nodes from its path after the removing of itself.
def new_cluster_efs22(gg,dhn,worst_fedge1,fedge_nodes_plith,fedge_subedges_weight,fedge_subedges):
    gg_dipath, gg_dipath_nodes, dd_dipath_edges = path(gg,dhn,worst_fedge1) #path as DiGraph
    #computes the w2del
    w2del = fedge_subedges_weight
    a_node = worst_fedge1
    k = 0
    met = 1
    while k == 0:
        if a_node in gg_dipath.nodes():
            if gg_dipath.predecessors(a_node) != []:
                pre_a = gg_dipath.predecessors(a_node)[0]
                if gg.degree(pre_a) == 2:
                    w2del = w2del + gg[pre_a][a_node]['weight'] #???
                    met = met + 1
                    a_node = pre_a
                else:
                    k = 1
            else:
                break
        else:
            break
    #recalculate the vars
    for i in range(len(dd_dipath_edges)-met):
        e = dd_dipath_edges[i]
        gg[e[0]][e[1]]['total_w'] = gg[e[0]][e[1]]['total_w'] - w2del
        gg[e[0]][e[1]]['total_load'] = gg[e[0]][e[1]]['total_load'] - fedge_nodes_plith
        if gg[e[0]][e[1]]['total_load'] != 0 :
            gg[e[0]][e[1]]['efficiency'] = gg[e[0]][e[1]]['total_w']/gg[e[0]][e[1]]['total_load'] #meters/people
        else:
            edge_efficiency = 0
    #remove fedge_subedges from gg
    for e in fedge_subedges:
        if e in gg.edges():
            gg.remove_edge(e[0],e[1])
        if (e[1],e[0]) in gg.edges():
            gg.remove_edge(e[1],e[0])
    #cutoff subedges_nodes
    for n in gg.nodes():
        if gg.degree(n) == 0:
            gg.remove_node(n)


#sortarei All edges of a graph according to efficiency 
def sort_fs(gg):
    list_fs_gg = []
    for e in gg.edges():
        list_fs_gg.append([e,gg[e[0]][e[1]]["efficiency"]])
    from operator import itemgetter, attrgetter
    sorted_list_fs_gg = sorted(list_fs_gg, key=itemgetter(1))
    return sorted_list_fs_gg


#return the list with percentages of invs
#using sub_trees
def cluster_invs22(G,g,percent):
    import copy
    ggs_list = []
    #given dhn
    #finds dhn of cluster
    dhn = find_dhn(G,g)
    #gives the % of the cluster to invent
    #percent = 75 #%
    per = float(percent)/100
    errorr = 0.01
    #computes the init mass of cluster
    cluster_mass = 0
    for n in g.nodes():
        if g.node[n]['population'] != -1:
            cluster_mass = cluster_mass + g.node[n]['population']
    #initial effs
    inv_or_not = 'Inv'
    l, gg, leafs, null_l = a_graph_efficiency(g, dhn,1,inv_or_not)
    #for the sub_trees ;)
    q = a_di_main_paths(G,l)
    sub_list = att_to_subtrees(G,q)[:]
    #ggs_list.append(copy.deepcopy(gg)) 
    l_list = sort_fs(gg)[:] #sorting of edges according to fs
    worst_fedge, worst_fedge_f = l_list[len(l_list)-1] #worst f edge
    #print worst_fedge
    #find to which sub_list's digraphs the worst_fedge belongs
    for Di in sub_list:
        e = worst_fedge
        if e in Di.edges():
            D = Di
            break
        if (e[1],e[0]) in Di.edges():
            D = Di
            worst_fedge = (e[1],e[0])
            break
    #finds the edges of the subtree!!! the last one is the fedge
    fedge_subedges = fedge_sub(D,worst_fedge)[:]
    #nodes of fedge_subedges, to know the sum of their population
    fedge_nodes = edges_nodes(fedge_subedges)[:]
    #finds the population of the nodes of the subedges
    s = 0
    for n in fedge_nodes:
        if G.node[n]['population'] != -1:
            s = s + G.node[n]['population']
    fedge_nodes_plith = s
    #finds the total weight of the subtree
    w = 0
    for se in fedge_subedges:
        if se in G.edges():
            w = w + G[se[0]][se[1]]['weight']
        if (se[1],se[0]) in G.edges():
            w = w + G[se[1]][se[0]]['weight']
    fedge_subedges_weight = w
    #define the var
    end_mass = float(cluster_mass - fedge_nodes_plith)
    frac_mass = end_mass/cluster_mass
    k=1
    #print k
    #print "---"
    while frac_mass - errorr > per: #put a checker ;)
        ggs_list.append(copy.deepcopy(gg)) 
        if worst_fedge[1] in gg.nodes():
            worst_fedge1 = worst_fedge[1]
        new_cluster_efs22(gg,dhn,worst_fedge1,fedge_nodes_plith,fedge_subedges_weight,fedge_subedges)
        #print len(gg.nodes())
        #print "+-+-+"
        l_list = sort_fs(gg)[:] #sorting of edges according to fs
        worst_fedge, worst_fedge_f = l_list[len(l_list)-1] #worst f edge
        #find to which sub_list's digraphs the worst_fedge belongs
        for Di in sub_list:
            e = worst_fedge
            if e in Di.edges():
                D = Di
                break
            if (e[1],e[0]) in Di.edges():
                D = Di
                worst_fedge = (e[1],e[0])
                break
        #finds the edges of the subtree!!! the last one is the fedge
        fedge_subedges = fedge_sub(D,worst_fedge)[:]
        #nodes of fedge_subedges, to know the sum of their population
        fedge_nodes = edges_nodes(fedge_subedges)[:]
        #finds the population of the nodes of the subedges
        s = 0
        for n in fedge_nodes:
            if G.node[n]['population'] != -1:
                s = s + G.node[n]['population']
        fedge_nodes_plith = s
        #finds the total weight of the subtree
        w = 0
        for se in fedge_subedges:
            if se in G.edges():
                w = w + G[se[0]][se[1]]['weight']
            if (se[1],se[0]) in G.edges():
                w = w + G[se[1]][se[0]]['weight']
        fedge_subedges_weight = w
        #define the var
        end_mass = float(end_mass - fedge_nodes_plith)
        frac_mass = end_mass/cluster_mass
        k = k + 1
        #print worst_fedge ###use them if we want to print the between steps
        #print k
        #print end_mass, ", ", frac_mass
        #print "---"
        ###ggs_list.append(copy.deepcopy(gg))
    return ggs_list



#sub_trees
#d: The function is used when we want to calculate NOT the 100% of the area but make network designing in a smaller area.
#d: I added the input parameter 'cap_list_cost'. That was missing. I am not sure this function works.
def cluster_invs_dummy22(G,g,dhn,percentt,cap_list,cap_list_cost):
    #########75%
    cls1 = cluster_invs22(G,g,percentt)
    cls75 = cls1[len(cls1)-1]
    #gg0 = cls1[2] #o  arithmos ton nodes einai sostos? den yparxei!!!
    gg0 = cls75
    n_gg0 = []
    for n in gg0.nodes():
        n_gg0.append([n[0],n[1]])
    g75 = cluster_to_subready(G,n_gg0) #allazei ton arithmo ton nodes!!!
    #correction of number of nodes
    g75_0 = g75
    for n in g75_0.nodes():
        if n not in gg0.nodes() and n in g75.nodes():
            g75.remove_node(n)
    dist_feed_boolean=='distribution'
    clust_invs_boolean == 'clust_invs_used'
    return netwrk_cost_dummy22(G,g75,dhn,cap_list,cap_list_cost,dist_feed_boolean,clust_invs_boolean) #also works!!!



###############################################################################
####################### About Efficiencies & Invs #############################
###########################       The End        ##############################
###############################################################################



###############################################################################
################ About Normalization & Borders of Clusters ####################
##################                                          ###################
###############################################################################





###############################################################################
##############################    BORDER LINES    #############################



###############################################################################
################ About Normalization & Borders of Clusters ####################
###########################       The End        ##############################
###############################################################################




###############################################################################
################# About Perimeter & neighbourhood of Blocks ###################
###########                                                       #############
###############################################################################
#returns the nodes and the edges of the perimeter of a block with id idi
def perimeter(G,idi):
    Gx = G.copy()
    l = bid_nodes(Gx,idi)
    n0 = random.choice(l)
    l.remove(n0)
    n1 = random.choice(l)
    S_n = []
    S_e = []
    pro_n0 = Gx.neighbors(n0)[0]
    pro_n1 = Gx.neighbors(n1)[0]
    S_n.append(pro_n0)
    S_n.append(pro_n1)
    path = nx.dijkstra_path(Gx,pro_n0,pro_n1)
    for i in path:
        if i not in S_n:
            S_n.append(i)
    #create the edges of the nodes
    l_e = []
    for i in range(len(path)-1):
        l_e.append((path[i],path[i+1]))
    for i in l_e:
        if i not in S_e:
            S_e.append(i)
    #
    Gx.remove_edges_from(l_e)
    #
    path2 = nx.dijkstra_path(Gx,pro_n0,pro_n1)
    for i in path2:
        if i not in S_n:
            S_n.append(i)
    l_e2 = []
    for i in range(len(path2)-1):
        l_e2.append((path2[i],path2[i+1]))
    for i in l_e2:
        if i not in S_e:
            S_e.append(i)
    return [S_n,S_e,idi]


#checks if two blocks are neighbors
def blocks_neig(G,bid1,bid2):
    p1 = perimeter(G,bid1)[0][:]
    p2 = perimeter(G,bid2)[0][:]
    s2 = set(p2)
    inter = [v for v in p1 if v in s2]
    if len(inter) <= 1:
        return False
    else:
        return [inter,bid1,bid2]


#returns the nodes and the edges of the perimeter of a block with id idi
def perimeter_chnull(G,idi):
    Gx = G.copy()
    ll = bid_nodes(Gx,idi)
    l_null = []
    for i in ll:
        if i not in l_null:
            l_null.append(G.neighbors(i)[0])
    l_ch = convex_hull(l_null)
    l = []
    for i in l_ch:
        for j in G.neighbors(i):
            if G.node[j]['population'] != -1 and j not in l:
                l.append(j)
    n0 = random.choice(l)
    l.remove(n0)
    n1 = random.choice(l)
    S_n = []
    S_e = []
    pro_n0 = Gx.neighbors(n0)[0]
    pro_n1 = Gx.neighbors(n1)[0]
    S_n.append(pro_n0)
    S_n.append(pro_n1)
    path = nx.dijkstra_path(Gx,pro_n0,pro_n1)
    for i in path:
        if i not in S_n:
            S_n.append(i)
    #create the edges of the nodes
    l_e = []
    for i in range(len(path)-1):
        l_e.append((path[i],path[i+1]))
    for i in l_e:
        if i not in S_e:
            S_e.append(i)
    #
    Gx.remove_edges_from(l_e)
    #
    path2 = nx.dijkstra_path(Gx,pro_n0,pro_n1)
    for i in path2:
        if i not in S_n:
            S_n.append(i)
    l_e2 = []
    for i in range(len(path2)-1):
        l_e2.append((path2[i],path2[i+1]))
    for i in l_e2:
        if i not in S_e:
            S_e.append(i)
    return [S_n,S_e,idi]


#checks if two blocks are neighbors
def blocks_neig_chnull(G,bid1,bid2):
    p1 = perimeter_chnull(G,bid1)[0][:]
    p2 = perimeter_chnull(G,bid2)[0][:]
    s2 = set(p2)
    inter = [v for v in p1 if v in s2]
    if len(inter) <= 1:
        return False
    else:
        return [inter,bid1,bid2]
###############################################################################
################# About Perimeter & neighbourhood of Blocks ###################
###########################       The End        ##############################
###############################################################################



###############################################################################
######################### About Outputs, BOMs & Costs #########################
###########                                                      ##############
###############################################################################



#since we have problem with the string '' we try with one stroke to have all
#for output in .shp. (after we find the minimum cost network)
#either we use literal_eval(string)
def netwrk_cost_dummy2_not(G,g,dhn,cap_list,cap_list_cost):
    
    
    #cutoff_null_leafs0(g)
    g.node[dhn]['root_node'] = 1
    inv_or_not = 'notInv'
    l, gg, leafs, null_l = a_graph_efficiency(g,dhn,1,inv_or_not)
    q = a_di_main_paths(G,l)
    sub_list = att_to_subtrees(G,q)[:]
    cost_list = []
    network_cost = 0
    for i in range(len(sub_list)):
        D = sub_list[i]
        #for e in D.edges():
            #D_e = D[e[0]][e[1]]
            #D_e['grans'] = {}
            #D_e['ALPHA'] = {}
            #D_e['dum_cost'] = 0
        init_edges(D)
        init_null(D)
        all_cap_gran_null(D,cap_list) #gives sucgload to the null nodes for not null leafs
        cap_gran_null_null000(D,dhn,cap_list) #gives suc2gload to the null nodes for null nodes
        cap_gran_null_null_null000(D,cap_list) #gives sucggload to the null nodes 
        grans_to_edges0(D,dhn,cap_list)#okz!!!
        grans_again0(D)
        granss0(D)
        grans_to_edges_cool(D,cap_list)
        cost_to_edges0(D,cap_list_cost) #okz!!!!
        efficiency_to_edges(D,gg)
        for e in D.edges():
            network_cost = network_cost + D[e[0]][e[1]]['dum_cost']
        cost_list.append(network_cost)
        for n in D.nodes():
            if n != dhn:
                g.node[n]['sucggload'] = D.node[n]['sucggload']
                g.node[n]['sucgload'] = D.node[n]['sucgload']
                g.node[n]['suc2gload'] = D.node[n]['suc2gload']
        for e in D.edges():
            ee = (e[0],e[1])
            D_e = D[e[0]][e[1]]
            #D_e['grans'] = {}
            #D_e['grans_c'] = {}
            #D_e['ALPHA'] = {}
            if (e[0],e[1]) in g.edges():
                g[e[0]][e[1]]['grans_f'] = D[e[0]][e[1]]['grans_f']
                g[e[0]][e[1]]['grans_c'] = D[e[0]][e[1]]['grans_c']
                g[e[0]][e[1]]['grans_s'] = D[e[0]][e[1]]['grans_s']
                g[e[0]][e[1]]['grans_d'] = D[e[0]][e[1]]['grans_d']
                g[e[0]][e[1]]['gr_cost'] = D[e[0]][e[1]]['gr_cost']
                g[e[0]][e[1]]['tr_cost'] = D[e[0]][e[1]]['tr_cost']
                g[e[0]][e[1]]['dum_cost'] = D[e[0]][e[1]]['dum_cost']
                g[e[0]][e[1]]['grans'] = D[e[0]][e[1]]['grans']
                g[e[0]][e[1]]['ALPHA'] = D[e[0]][e[1]]['ALPHA']
                g[e[0]][e[1]]['efficiency'] = D[e[0]][e[1]]['efficiency']
            if (e[1],e[0]) in g.edges():
                g[e[1]][e[0]]['grans_f'] = D[e[0]][e[1]]['grans_f']
                g[e[1]][e[0]]['grans_c'] = D[e[0]][e[1]]['grans_c']
                g[e[1]][e[0]]['grans_s'] = D[e[0]][e[1]]['grans_s']
                g[e[1]][e[0]]['grans_d'] = D[e[0]][e[1]]['grans_d']
                g[e[1]][e[0]]['gr_cost'] = D[e[0]][e[1]]['gr_cost']
                g[e[1]][e[0]]['tr_cost'] = D[e[0]][e[1]]['tr_cost']
                g[e[1]][e[0]]['dum_cost'] = D[e[0]][e[1]]['dum_cost']
                g[e[1]][e[0]]['grans'] = D[e[0]][e[1]]['grans']
                g[e[1]][e[0]]['ALPHA'] = D[e[0]][e[1]]['ALPHA']
                g[e[1]][e[0]]['efficiency'] = D[e[0]][e[1]]['efficiency']
    for e in g.edges():
        g_e = g[e[0]][e[1]]
        if g_e['grans_f'] == {}:
            g.remove_edge(e[0],e[1])
    g.node[dhn]['sucggload'] = D.node[dhn]['sucggload']
    g.node[dhn]['sucgload'] = D.node[dhn]['sucgload']
    g.node[dhn]['suc2gload'] = D.node[dhn]['suc2gload']
    for u,v,d in g.edges(data=True):
        del d['ALPHA']
        del d['grans']
        del d['grans_c']
        del d['mun_code']
        del d['mun_name']
        del d['name']
        del d['population']
        del d['length']
        del d['x___gid']
        del d['building_i']
        del d['gid']
        del d['id']
        del d['x_gid']
        del d['block_id']
    for n,d in g.nodes(data=True):
        del d['suc2gload']
        del d['sucgload']
        del d['sucggload']
 
    return [g, dhn, network_cost]



#return the costs and length of the output graph of netwrk_cost_dummy2 (100%)
def costs_tr(ggg_gamma):
    s_dum_cost = 0
    s_tr_cost = 0
    s_gr_cost = 0
    s_weight = 0
    for e in ggg_gamma.edges():
        s_dum_cost = s_dum_cost + float(ggg_gamma[e[0]][e[1]]['dum_cost'])
        s_tr_cost = s_tr_cost + float(ggg_gamma[e[0]][e[1]]['tr_cost'])
        s_gr_cost = s_gr_cost + float(ggg_gamma[e[0]][e[1]]['gr_cost'])
        s_weight = s_weight + ggg_gamma[e[0]][e[1]]['weight']
    return [round(s_weight,3),round(s_dum_cost,3),round(s_tr_cost,3),round(s_gr_cost,3)]


#return the total grans of the output graph of netwrk_cost_dummy2_not (100%
def bom_grans(ggg_gamma,node100,cap_list_cost):
    e0 = ggg_gamma.edges(node100)[0]
    len_f = len(ggg_gamma[e0[0]][e0[1]]['grans_f'])
    len_s = len(ggg_gamma[e0[0]][e0[1]]['grans_s'])
    len_d = len(ggg_gamma[e0[0]][e0[1]]['grans_d'])
    l_f = [0]*len_f
    l_s = [0]*len_s
    l_d = [0]*len_d
    l_ff = l_f[:]
    l_ss = l_s[:]
    l_dd = l_d[:]
    for e in ggg_gamma.edges():
        for i in range(len_f):
            l_f[i] = l_f[i] + ggg_gamma[e[0]][e[1]]['grans_f'][i]*ggg_gamma[e[0]][e[1]]['weight']*cap_list_cost[0][i]
            l_ff[i] = l_ff[i] + ggg_gamma[e[0]][e[1]]['grans_f'][i]*ggg_gamma[e[0]][e[1]]['weight']
        for i in range(len_s):
            print 'ggg_gamma[e[0]][e[1]][grans_f][i]'
            print ggg_gamma[e[0]][e[1]]['grans_s'][i]
            print ggg_gamma[e[0]][e[1]]['weight']
            print cap_list_cost[2][i]
            print 'end'
            l_s[i] = l_s[i] + ggg_gamma[e[0]][e[1]]['grans_s'][i]*ggg_gamma[e[0]][e[1]]['weight']*cap_list_cost[2][i]
            l_ss[i] = l_ss[i] + ggg_gamma[e[0]][e[1]]['grans_s'][i]*ggg_gamma[e[0]][e[1]]['weight']
        for i in range(len_d):
            l_d[i] = l_d[i] + ggg_gamma[e[0]][e[1]]['grans_d'][i]*ggg_gamma[e[0]][e[1]]['weight']*cap_list_cost[3][i]
            l_dd[i] = l_dd[i] + ggg_gamma[e[0]][e[1]]['grans_d'][i]*ggg_gamma[e[0]][e[1]]['weight']
    L = [[l_ff,l_f],[l_ss,l_s],[l_dd,l_d]]
    LL = []
    for l in L:
        ll = []
        for i in l:
            li = []
            for j in i:
                li.append(round(j,3))
            ll.append(li)
        LL.append(ll)
    #L = [l_f,l_s,l_d]
    return LL



#for BOM given cluster and one dhn candidate
#use this in order to find the best dhn (regarding cost)
#outputs also the grans!!!

#d: INPUT: G graph, gamma: cluster coordinates, dhn_gamma: x/y coords of the initial point
# cap_list: list of granularities, cap_list_cost: list of costs, shapeFilePath: string with directory of the input shapefile.
def bom_init_dhn(G,gamma,dhn_gamma,cap_list,cap_list_cost,shapeFilePath):
    print 'bom counter'
    larissa =  nx.DiGraph.to_undirected(nx.read_shp(shapeFilePath))#d: for calculation of minimum spanning tree (MST) we need an undirected graph
    set_new_attribute_to_nodes(larissa,'population',-1.0)
    set_new_attribute_to_nodes(larissa,'building_i',-1)
    set_new_attribute_to_nodes(larissa,'block_id',-1)
    change_length_attr(larissa)
    num = find_building_edges_and_update_nodes(larissa)
    restore_attributes(larissa)
    check = [nod for nod in larissa.degree() if larissa.degree(nod) > 1 and larissa.node[nod]['population'] != -1]
    d = nx.connected_component_subgraphs(larissa) #Generate connected components as subgraphs.
    G = larissa
    population_to_int(G)
    g_gamma = cluster_to_subready(G,gamma)
    #dhn_gamma = find_dhn(G,g_gamma)
    ggg_gamma, node100, cost100 = netwrk_cost_dummy2_not(G,g_gamma,dhn_gamma,cap_list,cap_list_cost)
    c = costs_tr(ggg_gamma)[:]
    return [dhn_gamma,c[1],c,bom_grans(ggg_gamma,node100,cap_list_cost),ggg_gamma]

###############################################################################
######################### About Outputs, BOMs & Costs #########################
###########################       The End        ##############################
###############################################################################



###############################################################################
##################### About Degs & Changing the main G  #######################
##############                                                 ################
###############################################################################
#create a node on an edge e of distance l from one of the first node of that edge
#splits the given edge in a node who's em distance from the fist node of e is l
def create_degi(e,l):
    x1 = e[0][0]
    y1 = e[0][1]
    x2 = e[1][0]
    y2 = e[1][1]
    #in case x1 != x2
    #if x1 != x2:
    if x1 != x2 - 0.000005 or x1 != x2 + 0.000005:
        if x1 < x2:
            lamda = round(float(y2-y1)/float(x2-x1),8)
            xn = x1
            yn = lamda*xn + (y1 - lamda*x1)
            while adistance(e[0],(xn,yn)) < l-0.000005:
                xn = xn + 0.000005
                yn = lamda*xn + (y1 - lamda*x1)
            return (xn,yn)
        else:
            lamda = round(float(y2-y1)/float(x2-x1),8)
            xn = x1
            yn = lamda*xn + (y1 - lamda*x1)
            while adistance(e[0],(xn,yn)) < l-0.000005:
                xn = xn - 0.000005
                yn = lamda*xn + (y1 - lamda*x1)
            return (xn,yn)
    if x1 == x2 - 0.000005 or x1 == x2 + 0.000005:
        if y1 < y2:
            yn = y1
            while round(abs(yn-y2),8) < l-0.000005:
                yn = yn + 0.000005
        if y1 > y2:
            yn = y2
            while round(abs(yn-y1),8) < l-0.000005:
                yn = yn + 0.000005
        return (x1,yn)


#check if a point (x,y) belongs to an edge; (to the line this exact edge defines)
def p_to_edge(e,p): #works ;)
    x1 = e[0][0]
    y1 = e[0][1]
    x2 = e[1][0]
    y2 = e[1][1]
    xr = p[0]
    yr = p[1]
    #if p_x has equal x with the nodes that define the edge
    if x1 == xr: #- 0.000005 or x1 == xr + 0.000005:
        return True
    if x2 == xr: #- 0.000005 or x2 == xr + 0.000005:
        return True
    if x1 != x2: #- 0.000005 or x1 != x2 + 0.000005:
        lamda_e = round(float(y2-y1)/float(x2-x1),8)
        lamda_p = round(float(yr-y1)/float(xr-x1),8)
        if abs(lamda_e - lamda_p) <= 0.000005: 
            return True
        else:
            return False


###############################################################


#given a graph and a list of nodes that do not belong to it, create a new graph 
#including these nodes and the new edges have all the atts of the previous
def hyperfinalgraph(ggg_gamma,mhns_list):
    mhns_list0 = []
    for i in mhns_list:
        if i not in ggg_gamma:
            mhns_list0.append(i)
    all_l = []
    for p in mhns_list0:
        e_l0 = []
        e_l = []
        for e in ggg_gamma.edges():
            if p_to_edge(e,p):
                e_l0.append(e)
        for e in e_l0:
            dise = adistance(p,e[0]) + adistance(p,e[1])
            ew = ggg_gamma[e[0]][e[1]]['weight']
            if round(dise,4) == round(ew,4):
                e_l.append(e)
        e_w_l = []
        if e_l != []:
            for e in e_l:
                e_w_l.append([e,ggg_gamma[e[0]][e[1]]['weight']])
            from operator import itemgetter, attrgetter
            sorted_e_w_l = sorted(e_w_l, key=itemgetter(1))
            e0 = sorted_e_w_l[0][0]
            nine(ggg_gamma,e0,p)



###ggg_gamma is the MST (minimum spanning tree) graph!!! we can take it from bom_init_dhn output ;)
##returns a list with all the nn of the graph of gamma whose deg is >= d and no nnn is neighbor of them
def deg_nnn(G,ggg_gamma,d):
    #g_gamma = cluster_to_subready(G,gamma)
    g_gamma = ggg_gamma.copy()
    l = []
    l_all = []
    l_nnn = []
    for i in g_gamma.nodes():
        if g_gamma.node[i]['population'] == -1 and g_gamma.degree(i) >= d:
            l_all.append(i)
    for i in l_all:
        dnn = 0
        for j in g_gamma.neighbors(i):
            if g_gamma.node[j]['population'] == -1: #check it. we miss some ;)
                dnn = dnn + 1
        if dnn == d:
            l_nnn.append(i)
    return l_nnn


##returns a list with all the nn of the graph of gamma whose deg is 2  and no nnn is neighbor of them
#using deg_nnn0
def deg_nnn2(G,ggg_gamma):
    d3 = deg_nnn(G,ggg_gamma,3)
    d2 = deg_nnn(G,ggg_gamma,2)
    d1 = deg_nnn1(G,ggg_gamma)
    l = []
    for i in d2:
        if i not in d3:
            l.append(i)
    #
    d2_l = l[:]
    for i in d2_l:
        if i in d1:
            l.remove(i)
    return l


##returns a list with all the nn of the nnn of gamma.
def deg_nnn1(G,ggg_gamma):
    #g_gamma = cluster_to_subready(G,gamma)
    g_gamma = ggg_gamma.copy()
    l = []
    for i in g_gamma.nodes():
        if g_gamma.node[i]['population'] != -1:
            l.append(g_gamma.neighbors(i)[0])
    return l




###############################################################################
##################### About Degs & Changing the main G  #######################
###########################       The End        ##############################
###############################################################################

###############################################################################
###                          DISTRIBUTIONING                                ###
###############################################################################
###############################################################################
###




# Subgraphs for manholes used in Distribution network calculation
# d: dist_feed_boolean: a parameter which takes a string as a value: 'distribution' or 'feeder'. Used in order to 
# merge functions which are used both in feeder and distribution network calculation and differ only by some lines

def subgraphs_Func(gamma,best_dhn,dhns,dhns_info,cap_list,cap_list_cost,shapeFilePath,dist_feed_boolean):
    larissa =  nx.DiGraph.to_undirected(nx.read_shp(shapeFilePath))
    set_new_attribute_to_nodes(larissa,'population',-1.0)
    set_new_attribute_to_nodes(larissa,'building_i',-1)
    set_new_attribute_to_nodes(larissa,'block_id',-1)
    change_length_attr(larissa)
    num = find_building_edges_and_update_nodes(larissa)
    restore_attributes(larissa)
    check = [nod for nod in larissa.degree() if larissa.degree(nod) > 1 and larissa.node[nod]['population'] != -1]
    clust_invs_boolean = 'clust_invs_not_used' #parameter used in netwrk_cost_dummy22 function
    if (dist_feed_boolean=='distribution'):
        d = nx.connected_component_subgraphs(larissa)
    G = larissa
    population_to_int(G)
    if (dist_feed_boolean=='distribution'):
        g_gamma = cluster_to_subready(G,gamma)
        subsinfo = netwrk_cost_dummy22(G,g_gamma,best_dhn,cap_list,cap_list_cost,dist_feed_boolean,clust_invs_boolean) #d: function used both for feeder/distribution network
    elif (dist_feed_boolean=='feeder'):
        for i in range(len(dhns)):
            G.node[dhns[i]]['population'] = dhns_info[i][2]
        #g_gamma = cluster_to_subready(G,gamma)
        comP_dhns = best_dhn
        g_gamma = cluster_to_subready_feeder(G,gamma,comP_dhns,dhns,dhns_info)
        subsinfo = netwrk_cost_dummy22(G,g_gamma,best_dhn,cap_list,cap_list_cost,dist_feed_boolean,clust_invs_boolean) #d: function used both for feeder/distribution network
    return subsinfo[3]

#directed graph!!! returns the nn leafs
def leafs_nn(g1):
    l = []
    for i in g1.nodes():
        if g1.node[i]['population'] != -1 and g1.out_degree(i) == 0:
            l.append(i)
    return l


#directed graph!!! returns the degi nodes from the graph
def degi_gi(g1,deg3,best_dhn):
    l = []
    for i in deg3:
        if i in g1.nodes():
            l.append(i)
    if best_dhn not in l:
        l.append(best_dhn)
    return l


#lib
#returns a list with the attributes of the edges of the graph G
def edge_atts(G):
    l = []
    for i in G.edges(data=True)[2][2]:
        l.append(i)
    return l

#lib
#returns a list with the attributes of the nodes of the graph G
def node_atts(G):
    l = []
    for i in G.nodes(data=True)[0][1]:
        l.append(i)
    return l


#in a graph g, given an edge e and a node n,
#adds the edges (e[0],n), (n,e[1]) to the graph with all the atts of e
def nine(g,e,n):
    g.add_edge(e[0],n)
    g.add_edge(n,e[1])
    g[e[0]][n]['weight'] = adistance(e[0],n)
    g[n][e[1]]['weight'] = adistance(n,e[1])
    g.node[n]['population'] = -1
    g.node[n]['building_i'] = -1
    g.node[n]['block_id'] = -1
    g.node[n]['manhole'] = -1
    g.remove_edge(e[0],e[1])



#in a directed graph g, given a node n,
#create the edges with starting point the predecessor of n
#and the ending points the successors of n.
#the weights are defined as the sum of the previous edges
#at the end, n is removed from the graph g
def nine_r(g,n):
    pre_n = g.predecessors(n)[0]
    sucs_n_l = g.successors(n)
    e_l = []
    for i in sucs_n_l:
        e_l.append((pre_n, i , g[pre_n][n]['weight'] + g[n][i]['weight'] ))
    g.add_weighted_edges_from(e_l)
    g.remove_node(n)


#given a digraph removes all the nodes creating new edges using the above
#at the end the digraph has no edge with w_l < lmin
def remove_min_ns(g0_cn,lmin):
    l = [0]
    while l != []:
        l = []
        for e in g0_cn.edges():
            if g0_cn[e[0]][e[1]]['weight'] < lmin:
                l.append(e[1])
        if l != []:
            nine_r(g0_cn,l[0])
    return g0_cn


def mhnsOA(g0_cn,Os,Oe,l):
    #l = 250
    #O = cn
    #A = cns[0]
    O = Os
    A = Oe
    g0_cn_un = g0_cn.to_undirected()
    if g0_cn.node[A]['population'] == -1:
        spd_OA = nx.dijkstra_path_length(g0_cn_un, source=O, target=A)
        A_pro = A
    else:
        A_pro = g0_cn_un.neighbors(A)[0]
        spd_OA = nx.dijkstra_path_length(g0_cn_un, source=O, target=A_pro)
    l_var = l
    if l_var >= spd_OA:
        #manhole_node = O
        return O
    else:
        s = nx.dijkstra_path(g0_cn,O,A_pro)[:]
        #from s create s_l, the list of the consecutive edges from the path s
        s_l = []
        for i in range(len(s)-1):
            s_l.append((s[i],s[i+1]))
        syn = 0
        k = 0
        while syn == 0:
            e = s_l[k]
            l_w = g0_cn[e[0]][e[1]]['weight']
            if l_var <= l_w:
                manhole_node = create_degi(e,l_var)
                syn = 1
            else:
                k = k + 1
                l_var = l_var - l_w
        nine(g0_cn,e,manhole_node)
        return manhole_node


def mhnsOA_all(g0_cn,Os,Oe,l):
    mhn_l = []
    O = Os
    A = Oe
    g0_cn_un = g0_cn.to_undirected()
    if g0_cn.node[A]['population'] == -1:
        spd_OA = nx.dijkstra_path_length(g0_cn_un, source=O, target=A)
    else:
        A_pro = g0_cn_un.neighbors(A)[0]
        spd_OA = nx.dijkstra_path_length(g0_cn_un, source=O, target=A_pro)
    frac_l = int(spd_OA/l)
    kk = 0
    while kk < frac_l:
        mhn_var = mhnsOA(g0_cn,O,A,l)
        mhn_l.append(mhn_var)
        O = mhn_var
        kk = kk + 1
    return mhn_l


#in the graph subtree of g0 with root O and end A returns the list of mnhs given the reel length
def mhns(g0,O,A,l):
    g0_cn = root_tree(g0,O) #issue with the subdirtree ;) so we use 
    return mhnsOA_all(g0_cn,O,A,l)


def mhnsOA(g0,g0_cn,Os,Oe,l):
    #l = 250
    #O = cn
    #A = cns[0]
    O = Os
    A = Oe
    g0_cn_un = g0_cn.to_undirected()
    g0_un = g0.to_undirected()
    if g0_cn.node[A]['population'] == -1:
        spd_OA = nx.dijkstra_path_length(g0_un, source=O, target=A)
        A_pro = A
    else:
        A_pro = g0_cn_un.neighbors(A)[0]
        spd_OA = nx.dijkstra_path_length(g0_un, source=O, target=A_pro)
    l_var = l
    if l_var >= spd_OA:
        manhole_node = O
    else:
        s = nx.dijkstra_path(g0_un,O,A_pro)[:]
        #from s create s_l, the list of the consecutive edges from the path s
        s_l = []
        for i in range(len(s)-1):
            s_l.append((s[i],s[i+1]))
        syn = 0
        k = 0
        while syn == 0:
            e = s_l[k]
            l_w = g0_un[e[0]][e[1]]['weight']
            if l_var <= l_w:
                manhole_node = create_degi(e,l_var)
                syn = 1
            else:
                k = k + 1
                l_var = l_var - l_w
        nine(g0,e,manhole_node)
        nine(g0_cn,(O, A),manhole_node) #update g0_cn
    return [manhole_node,g0,g0_cn]


def mhnsOA_all(g0,g0_cn,Os,Oe,l):
    mhn_l = []
    O = Os
    A = Oe
    g0_cn_un = g0_cn.to_undirected()
    g0_un = g0.to_undirected()
    if g0_cn.node[A]['population'] == -1:
        spd_OA = nx.dijkstra_path_length(g0_un, source=O, target=A)
    else:
        A_pro = g0_cn_un.neighbors(A)[0]
        spd_OA = nx.dijkstra_path_length(g0_un, source=O, target=A_pro)
    frac_l = int(spd_OA/l)
    kk = 0
    while kk < frac_l:
        mhn_var, g0, g0_cn = mhnsOA(g0,g0_cn,O,A,l) #mallon prepei na valo var gia tous dyo graphous
        mhn_l.append(mhn_var)
        O = mhn_var
        kk = kk + 1
    return [mhn_l, g0, g0_cn]


def create_max_ns(g0,g0_cn,lmax):
    l = [0]
    while l != []:
        l = []
        for e in g0_cn.edges():
            if g0_cn[e[0]][e[1]]['weight'] > lmax:
                l.append(e)
        if l != []:
            e = l[0]
            mhnsOA_all(g0,g0_cn,e[0],e[1],lmax)
    return [g0,g0_cn]


#finds the outer_leafs of g0
def real_lfs(g0,lfs_g0):
    g00 = g0.copy()
    g00_un = g0.to_undirected()
    lfs_l = []
    for i in lfs_g0:
        if g00_un.neighbors(i) != []:
            if g0.out_degree(g00_un.neighbors(i)[0]) == 1:
                lfs_l.append(i)
    return lfs_l


#returns the deg3 node of n
def blng_deg3(g0,lfs_g0,deg3_g0,n):
    pre_n = g0.predecessors(n)[0]
    while pre_n not in deg3_g0:
        n = pre_n
        pre_n = g0.predecessors(n)[0]
    return pre_n


#returns the deg2 node of n #if we play with deg2 we use this one!!!
def blng_deg2(g0,lfs_g0,deg2_g0,best_dhn,n):
    pre_n = g0.predecessors(n)[0]
    while pre_n not in deg2_g0 and pre_n != best_dhn:
        n = pre_n
        pre_n = g0.predecessors(n)[0]
    return pre_n


#returns the deg3 nodes with their corresponding outer leafs
def real_lfs_with_deg3_all(g0,lfs_g0,deg3_g0):
    r_lfs_l = real_lfs(g0,lfs_g0)
    ll = []
    for i in r_lfs_l:
        ll.append([blng_deg3(g0,lfs_g0,deg3_g0,i),i])
    lc = []
    for i in ll:
        if i[0] not in lc:
            lc.append(i[0])
    lall = []
    for i in lc:
        ln = []
        for j in ll:
            if i == j[0]:
                ln.append(j[1])
        lall.append([i,ln])
    return lall


#returns the deg2 nodes with their corresponding outer leafs!!!!!!
def real_lfs_with_deg2_all(g0,lfs_g0,deg2_g0,best_dhn):
    r_lfs_l = real_lfs(g0,lfs_g0)
    ll = []
    for i in r_lfs_l:
        ll.append([blng_deg2(g0,lfs_g0,deg2_g0,best_dhn,i),i])
    lc = []
    for i in ll:
        if i[0] not in lc:
            lc.append(i[0])
    lall = []
    for i in lc:
        ln = []
        for j in ll:
            if i == j[0]:
                ln.append(j[1])
        lall.append([i,ln])
    return lall


#returns all the subleafs of the outer node n till deg3_n
def sublfs_outern3(g0,lfs_g0,deg3_g0,n):
    n0 = n
    sub_lfs_l = []
    pre_n = g0.predecessors(n)[0] #one step at at the time
    while pre_n not in deg3_g0:
        n = pre_n
        suc_l = g0.successors(n)
        for i in suc_l:
            if g0.node[i]['population'] != -1:
                sub_lfs_l.append(i)
        pre_n = g0.predecessors(n)[0]
    return [n0,sub_lfs_l]


#returns all the subleafs of the outer node n till deg2_n !!!!!
def sublfs_outern2(g0,lfs_g0,deg2_g0,best_dhn,n):
    n0 = n
    sub_lfs_l = []
    pre_n = g0.predecessors(n)[0] #one step at at the time
    while pre_n not in deg2_g0 and pre_n != best_dhn:
        n = pre_n
        suc_l = g0.successors(n)
        for i in suc_l:
            if g0.node[i]['population'] != -1:
                sub_lfs_l.append(i)
        pre_n = g0.predecessors(n)[0]
    return [n0,sub_lfs_l]


#returns the initial deg3_g0 nodes and the outer spd node of each one of them
#meaning, all the initial possible deg3_ns
def sub_mhns3(g0,lfs_g0,deg3_g0):
    lll = []
    rl = real_lfs_with_deg3_all(g0,lfs_g0,deg3_g0)
    for i in rl:
            for j in i[1]:
                lll.append([i[0], sublfs_outern3(g0,lfs_g0,deg3_g0,j)])
    #
    lll_subs = []
    for i in lll:
        cns_subs = minmaxp_sp(g0,i[1][1],i[0])[1]
        lll_subs.append([i[0], cns_subs[0] ])
    #
    all_mhns_l = deg3_g0[:]
    for i in lll_subs:
        if i[1] not in deg3_g0:
            all_mhns_l.append(i[1])
    return all_mhns_l


#returns the initial deg2_g0 nodes and the outer spd node of each one of them
#meaning, all the initial possible deg2_ns !!!!!
def sub_mhns2(g0,lfs_g0,deg2_g0,best_dhn):
    lll = []
    rl = real_lfs_with_deg2_all(g0,lfs_g0,deg2_g0,best_dhn)
    for i in rl:
            for j in i[1]:
                lll.append([i[0], sublfs_outern2(g0,lfs_g0,deg2_g0,best_dhn,j)])
    #
    lll_subs = []
    for i in lll:
        cns_subs = minmaxp_sp(g0,i[1][1],i[0])[1]
        lll_subs.append([i[0], cns_subs[0] ])
    #
    all_mhns_l = deg2_g0[:]
    for i in lll_subs:
        if i[1] not in deg2_g0:
            all_mhns_l.append(i[1])
    all_mhns_l.append(best_dhn)
    return all_mhns_l

#returns the initial deg1_g0 nodes and the outer spd node of each one of them
#meaning, all the initial possible deg1_ns !!!!!
#since the 1j nodes are the proj of nnns, all_mhns_l is the same as deg1_g0 plus
# best_dhn
def sub_mhns1(g0,lfs_g0,deg1_g0,best_dhn):
    all_mhns_l = deg1_g0[:]
    all_mhns_l.append(best_dhn)
    return all_mhns_l


#returns the deg3 node of n and the corresponding distance between them
def blng_deg3_gen(g0,lfs_g0,deg3_g0,best_dhn,n):
    pre_n = g0.predecessors(n)[0]
    w = g0[pre_n][n]['weight']
    w_all = w
    if pre_n != best_dhn:
        while pre_n not in deg3_g0:
            n = pre_n
            pre_n = g0.predecessors(n)[0]
            w = g0[pre_n][n]['weight']
            w_all = w_all + w
    return [pre_n,w_all]


#output is the all the deg3_g0 together with their leafs and the edges with the weight.
#it' s ready to define a new directed graph so we will play with it
def deg3_path_gen(g0,lfs_g0,deg3_g0,best_dhn,sl30): 
    leafs_l = []
    for i in sl30:
        if g0.node[i]['population'] != -1:
            leafs_l.append(i)
    nodes_l = []
    edges_l = []
    k = 0
    while k < len(leafs_l):
        n = leafs_l[k]
        nodes_l.append(n)
        n_var, w_var = blng_deg3_gen(g0,lfs_g0,deg3_g0,best_dhn,n)
        while n_var != best_dhn:
            if n_var not in nodes_l:
                edges_l.append([(n_var,n),w_var])
                n = n_var
                nodes_l.append(n)
                n_var, w_var = blng_deg3_gen(g0,lfs_g0,deg3_g0,best_dhn,n)
            else:
                edges_l.append([(n_var,n),w_var])
                break
        if n_var == best_dhn:
            nodes_l.append(n_var)
            edges_l.append([(n_var,n),w_var])
        k = k + 1
    #nodes_l.append(best_dhn)
    return [nodes_l, edges_l]


#define the init subtree directed graph to find mhns
#tha corresponds to sl31
def init_subdirtree(sl_0):
    sl = sl_0[:]
    init_l = []
    l = sl[1]
    for i in l:
        init_l.append((i[0][0], i[0][1], i[1]))
    gi = nx.DiGraph() #define the digraph
    gi.add_weighted_edges_from(init_l)
    for n in gi.nodes():
        gi.node[n]['population'] = -1
    return gi


def mhns_f(sl_0,g0,lmin,lmax):
    g00 = g0.copy()
    g00_cn = init_subdirtree(sl_0)
    g00_cn = remove_min_ns(g00_cn,lmin)
    g00, g00_cn = create_max_ns(g00,g00_cn,lmax)
    nodes_l = g00_cn.nodes()[:]
    for n in g00_cn.nodes():
        if g00_cn.out_degree(n) == 0:
                nodes_l.remove(n) 
    return nodes_l


def mhns_f0(sl_0,sl30,g0,lfs_g0,lmin,lmax):
    nodes_l0 = mhns_f(sl_0,g0,lmin,lmax)[:]
    #find the lfs edges of sl30
    e_l = []
    for j in sl30:
        if g0.node[j]['population'] != -1:
            e_l.append([g0.predecessors(j)[0],j])
    n_l = []
    ne_l = []
    for n in nodes_l0:
        for e in e_l:
            if p_to_edge(e,n):
                n_l.append(n)
                ne_l.append([e[0],n])
    nodes_l = nodes_l0[:]
    for i in ne_l:
        if i[0] not in nodes_l:
            nodes_l.append(i[0])
        nodes_l.remove(i[1])
    return nodes_l


#l_all0 = mhns_f0(sl_all,g0,lmin,lmax)
def dhn_mhns0(G,gamma,best_dhn,deg3,deg2,deg1,lmin,lmax,d,dhns,dhns_info,cap_list,cap_list_cost,shapeFilePath,dist_feed_boolean):
    if d==3 or d==2 or d==1 or d==32 or d==31 or d==21 or d==321:
        subs_g = subgraphs_Func(gamma,best_dhn,dhns,dhns_info,cap_list,cap_list_cost,shapeFilePath,dist_feed_boolean)
        #subs_g = subs(gamma,best_dhn,cap_list,cap_list_cost,shapeFilePath) # delete it when you feel like. Its not used any more (after merging subs() and subs0() into subgraphs_Func()
        if d == 3:
            l003 = []
            for g_var in subs_g:
                lfs_g_var = leafs_nn(g_var)[:]
                deg3_g_var = degi_gi(g_var,deg3,best_dhn)
                sl30 = sub_mhns3(g_var,lfs_g_var,deg3_g_var)
                sl_0 = deg3_path_gen(g_var,lfs_g_var,deg3_g_var,best_dhn,sl30)[:]
                l030 = mhns_f0(sl_0,sl30,g_var,lfs_g_var,lmin,lmax)
                for i in l030:
                    l003.append(i)
            return l003
        #
        elif d == 2:
            l002 = []
            for g_var in subs_g:
                lfs_g_var = leafs_nn(g_var)[:]
                deg2_g_var = degi_gi(g_var,deg2,best_dhn)
                sl20 = sub_mhns2(g_var,lfs_g_var,deg2_g_var,best_dhn)
                sl_0 = deg3_path_gen(g_var,lfs_g_var,deg2_g_var,best_dhn,sl20)[:]
                l020 = mhns_f0(sl_0,sl20,g_var,lfs_g_var,lmin,lmax)
                for i in l020:
                    l002.append(i)
            return l002
        #
        elif d == 1:
            l001 = []
            for g_var in subs_g:
                lfs_g_var = leafs_nn(g_var)[:]
                deg1_g_var = degi_gi(g_var,deg1,best_dhn)
                sl10 = sub_mhns1(g_var,lfs_g_var,deg1_g_var,best_dhn)
                deg3_g_var = degi_gi(g_var,deg3,best_dhn)
                sl30 = sub_mhns3(g_var,lfs_g_var,deg3_g_var)
                ##
                l = []
                for i in sl30:
                    if G.node[i]['population'] != -1:
                        l.append(i)
                for i in l:
                    sl10.append(i)
                ##
                sl_0 = deg3_path_gen(g_var,lfs_g_var,deg1_g_var,best_dhn,sl10)[:]
                l010 = mhns_f0(sl_0,sl10,g_var,lfs_g_var,lmin,lmax)
                for i in l010:
                    l001.append(i)
            return l001
            #
        l_all_all = []
        for g_var in subs_g:
            l_all0 = []
            deg_all = []
            deg_i_g_var = [degi_gi(g_var,deg3,best_dhn),degi_gi(g_var,deg2,best_dhn),degi_gi(g_var,deg1,best_dhn)][:]
            lfs_g_var = leafs_nn(g_var)[:]
            sl30 = sub_mhns3(g_var,lfs_g_var,deg_i_g_var[0])[:]
            l = []
            for i in sl30:
                if G.node[i]['population'] != -1:
                    l.append(i)
            if d == 321:
                deg_all = union(deg_i_g_var[0],deg_i_g_var[1])
                deg_all = union(deg_all,deg_i_g_var[2])
            if d == 32:
                deg_all = union(deg_i_g_var[0],deg_i_g_var[1])
            if d == 31:
                deg_all = union(deg_i_g_var[0],deg_i_g_var[2])
            if d == 21:
                deg_all = union(deg_i_g_var[1],deg_i_g_var[2])
            sl_Ln = deg_all[:]
            for i in l:
                if i not in deg_all:
                    sl_Ln.append(i)
            sl_all = deg3_path_gen(g_var,lfs_g_var,deg_all,best_dhn,sl_Ln)[:]
            l_all0 = mhns_f0(sl_all,sl_Ln,g_var,lfs_g_var,lmin,lmax)[:]
            l_all_all = union(l_all_all,l_all0)
        return l_all_all
    else:
        print "The possible values for the last parameter are {3, 2, 1, 32, 31, 21, 321}."



# by Dim
# Input:
# mhn_c_l: an array which contains 8 values of 0 or 1 depending which strategy we use in this scenario
# mhn_cost: an array with the costs of the manhole declared in the input form
# omhns: an array which contains the number of manholes for each strategy [1way,2ways,3ways,newManholes]
# d: type of the manhole strategy (posibble values: 3, 2, 1, 32, 31, 21, 321)
# Output: returns the total cost of all the manholes (we show this on excel tab)
# Description: Thid definition calculated the total cost of the manholes both for the DHN (distribution
# network and the feeder network.

def mhns_cost_d(gx_final,mhn_c_l,mhn_cost,omhns,d):
    if d==3 or d==2 or d==1 or d==32 or d==31 or d==21 or d==321:
        if d==3 and mhn_c_l == [0,0,0,1,0,0,1,0]: # LC +  average new manhole cost
            return omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[6]
        elif d==3 and mhn_c_l == [0,0,0,0,1,0,0,1]: # HC +  expensive new manhole cost
            return omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[7]
        # added by Dimitris cause of missing cases:
        #
        elif d==3 and mhn_c_l == [0,0,0,1,0,1,0,0]: # LC + cheap new manhole cost
            return omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[5]
        elif d==3 and mhn_c_l == [0,0,0,0,1,1,0,0]: # HC + cheap new manhole cost 
            return omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[5]
        elif d==3 and mhn_c_l == [0,0,0,1,0,0,0,1]: # LC + expensive new manhole cost
            return omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[7]
        elif d==3 and mhn_c_l == [0,0,0,0,1,0,1,0]: # HC + average new manhole cost
            return omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[6]
        # end of Dimitris additions
        #
        
        elif d==2 and mhn_c_l == [0,1,0,0,0,0,1,0]: # LC + average new manhole cost
            return omhns[1]*mhn_cost[1] + omhns[3]*mhn_cost[6]
        elif d==2 and mhn_c_l == [0,0,1,0,0,0,0,1]: # HC + expensive new manhole cost
            return omhns[1]*mhn_cost[2] + omhns[3]*mhn_cost[7]
        # added by Dimitris cause of missing cases:
        elif d==2 and mhn_c_l == [0,1,0,0,0,1,0,0]: # LC + cheap new manhole cost
            return omhns[1]*mhn_cost[1] + omhns[3]*mhn_cost[5]
        elif d==2 and mhn_c_l == [0,1,0,0,0,0,0,1]: # LC + expensive new manhole cost
            return omhns[1]*mhn_cost[1] + omhns[3]*mhn_cost[7]   
        elif d==2 and mhn_c_l == [0,0,1,0,0,1,0,0]: # HC + cheap new manhole cost
            return omhns[1]*mhn_cost[2] + omhns[3]*mhn_cost[5]
        elif d==2 and mhn_c_l == [0,0,1,0,0,0,1,0]: # HC + average new manhole cost
            return omhns[1]*mhn_cost[2] + omhns[3]*mhn_cost[6]
        # end of Dimitris additions
        #
        elif d==1 and mhn_c_l == [1,0,0,0,0,1,0,0]: # cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[3]*mhn_cost[5]
        elif d==1 and mhn_c_l == [1,0,0,0,0,0,1,0]: # average new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[3]*mhn_cost[6]
        elif d==1 and mhn_c_l == [1,0,0,0,0,0,0,1]: # expensive cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[3]*mhn_cost[7]
        #
        
        
        elif d==32 and mhn_c_l == [0,1,0,1,0,0,1,0]: # LC + LC average new manhole cost
			return omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[6]
        elif d==32 and mhn_c_l == [0,1,0,1,0,0,0,1]: # LC + LC expensive new manhole cost
            return omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[7]
        elif d==32 and mhn_c_l == [0,0,1,1,0,0,1,0]: # HC + LC average new manhole cost
            return omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[6]
        elif d==32 and mhn_c_l == [0,0,1,1,0,0,0,1]: # HC + LC expensive new manhole cost
            return omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[7]
        elif d==32 and mhn_c_l == [0,1,0,0,1,0,1,0]: # LC + HC average new manhole cost
            return omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[6]
        elif d==32 and mhn_c_l == [0,1,0,0,1,0,0,1]: # LC + HC expensive new manhole cost
            return omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[7]
        elif d==32 and mhn_c_l == [0,0,1,0,1,0,1,0]: # HC + HC average new manhole cost
            return omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[6]
        elif d==32 and mhn_c_l == [0,0,1,0,1,0,0,1]: # HC + HC expensive new manhole cost
            return omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[7]
        # added by Dimitris cause of missing cases:     
        elif d==32 and mhn_c_l == [0,1,0,1,0,1,0,0]: # LC + LC cheap new manhole cost
            return omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[5]
        elif d==32 and mhn_c_l == [0,1,0,0,1,1,0,0]: # LC + HC cheap new manhole cost
            return omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[5]
        elif d==32 and mhn_c_l == [0,0,1,1,0,1,0,0]: # HC + LC cheap new manhole cost
            return omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[5]
        elif d==32 and mhn_c_l == [0,0,1,0,1,1,0,0]: # HC + HC cheap new manhole cost
            return omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[5]
        # end of Dimitris additions
        #
        elif d==31 and mhn_c_l == [1,0,0,1,0,1,0,0]: # LC cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[5]
        elif d==31 and mhn_c_l == [1,0,0,0,1,1,0,0]: # HC cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[5]
        elif d==31 and mhn_c_l == [1,0,0,1,0,0,1,0]: # LC average new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[6]
        elif d==31 and mhn_c_l == [1,0,0,0,1,0,1,0]: # HC average new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[6]
        elif d==31 and mhn_c_l == [1,0,0,1,0,0,0,1]: # LC expensive new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[7]
        elif d==31 and mhn_c_l == [1,0,0,0,1,0,0,1]: # HC expensive new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[7]
        #
        elif d==21 and mhn_c_l == [1,1,0,0,0,1,0,0]: # LC cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[1] + omhns[3]*mhn_cost[5]
        elif d==21 and mhn_c_l == [1,0,1,0,0,1,0,0]: # HC cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[2] + omhns[3]*mhn_cost[5]
        elif d==21 and mhn_c_l == [1,1,0,0,0,0,1,0]: # LC average new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[1] + omhns[3]*mhn_cost[6]
        elif d==21 and mhn_c_l == [1,0,1,0,0,0,1,0]: # HC average new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[2] + omhns[3]*mhn_cost[6]
        elif d==21 and mhn_c_l == [1,1,0,0,0,0,0,1]: # LC expensive new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[1] + omhns[3]*mhn_cost[7]
        elif d==21 and mhn_c_l == [1,0,1,0,0,0,0,1]: # HC expensive new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[2] + omhns[3]*mhn_cost[7]
        #
        elif d==321 and mhn_c_l == [1,1,0,1,0,1,0,0]: # LC + LC cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[5]
        elif d==321 and mhn_c_l == [1,0,1,1,0,1,0,0]: # HC + LC cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[5]
        elif d==321 and mhn_c_l == [1,1,0,0,1,1,0,0]: # LC + HC cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[5]
        elif d==321 and mhn_c_l == [1,1,0,1,0,0,1,0]: # LC + LC average new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[6]
        elif d==321 and mhn_c_l == [1,0,1,1,0,0,1,0]: # HC + LC average new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[6]
        elif d==321 and mhn_c_l == [1,1,0,0,1,0,1,0]: # LC + HC average new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[6]
        elif d==321 and mhn_c_l == [1,1,0,1,0,0,0,1]: # LC + LC expensive new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[7]
        elif d==321 and mhn_c_l == [1,0,1,1,0,0,0,1]: # HC + LC expensive new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[3] + omhns[3]*mhn_cost[7]
        elif d==321 and mhn_c_l == [1,1,0,0,1,0,0,1]: # LC + HC expensive new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[1] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[7]
        # added by Dimitris cause of missing cases:  
        elif d==321 and mhn_c_l == [1,0,1,0,1,1,0,0]: # HC + HC cheap new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[5]
        elif d==321 and mhn_c_l == [1,0,1,0,1,0,0,1]: # HC + HC expensive new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[7]
        elif d==321 and mhn_c_l == [1,0,1,0,1,0,1,0]: # HC + HC average new manhole cost
            return omhns[0]*mhn_cost[0] + omhns[1]*mhn_cost[2] + omhns[2]*mhn_cost[4] + omhns[3]*mhn_cost[6] 
        # end of Dimitris additions
    else:
        print "The possible values for the last parameter are {3, 2, 1, 32, 31, 21, 321}."


#d: ShapeFilePath: a string with the location of the input shape file
#   shapeFileNameOne/shapeFileNameTwo: the names of the output shape files (one for node and one for edges)
def alphas_distribution(G,gamma,dhn_gamma,lmin,lmax,d,cap_list,cap_list_cost,shapeFileNameOne,shapeFileNameTwo,shapeFilePath):
    from ast import literal_eval


    tic=timeit.default_timer()
    
    g_gamma = cluster_to_subready(G,gamma)
    ###dhn_gamma = find_dhn(G,g_gamma)
    best_dhn = dhn_gamma
    
    print 'before bom is executed STUFF'
    bom = bom_init_dhn(G,gamma,dhn_gamma,cap_list,cap_list_cost,shapeFilePath) # is executed once per cluster (3 clusters = 3 executions)


    ggg_gamma = bom[4]
	
    
    toc=timeit.default_timer()
    a = int(toc - tic)
    print 'stuff_bomInit'
    print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds
    
    tic=timeit.default_timer()
    deg3 = deg_nnn(G,ggg_gamma,3)
    deg2 = deg_nnn2(G,ggg_gamma)
    deg1 = deg_nnn1(G,ggg_gamma)
    #d: contains a list with the coordinates of all manholes
    
    dhns = [] #d: not used for distribution network (only for feeder) - need to pass in subgraphs()
    dhns_info = [] #d: not used for distribution network (only for feeder) - need to pass in subgraphs()
    dist_feed_boolean = 'distribution' #d: parameter to pass into subgraphs definition
    mhns_list0 = dhn_mhns0(G,gamma,best_dhn,deg3,deg2,deg1,lmin,lmax,d,dhns,dhns_info,cap_list,cap_list_cost,shapeFilePath,dist_feed_boolean)
    #print mhns_list0
    mhns_list = []
    for i in mhns_list0:
        if i not in mhns_list:
            mhns_list.append(i)
    mhns_list.remove(best_dhn)

    #
    hyperfinalgraph(G,mhns_list)
    #
    g0_gamma = cluster_to_subready(G,gamma)

    ggg0_gamma, node1000, cost1000, subgs = netwrk_cost_dummy000sub(G,g0_gamma,dhn_gamma,cap_list,cap_list_cost,dist_feed_boolean)
    
   
    for u,v,d in ggg0_gamma.edges(data=True):
        if 'ALPHA' in d:
            del d['ALPHA']
        if 'grans' in d:
            del d['grans']
        if 'grans_c' in d:
            del d['grans_c']
        if 'mun_code' in d:
            del d['mun_code']
        if 'mun_name' in d:
            del d['mun_name']
        if 'name' in d:
            del d['name']
        if 'population' in d:
            del d['population']
        if 'length' in d:
            del d['length']
        if 'x___gid' in d:
            del d['x___gid']
        if 'building_i' in d:
            del d['building_i']
        if 'gid' in d:
            del d['gid']
        if 'id' in d:
            del d['id']
        if 'x_gid' in d:
            del d['x_gid']
        if 'block_id' in d:
            del d['block_id']
        if 'gid_01' in d:
            del d['gid_01']
        if 'manhole' in d:
            del d['manhole']
    #
    for n,d in ggg0_gamma.nodes(data=True):
        if 'suc2gload' in d:
            del d['suc2gload']
        if 'sucgload' in d:
            del d['sucgload']
        if 'sucggload' in d:
            del d['sucggload']
    #
    
    # d: Assigning the manhole strategy to the nodes of the graph which are manholes
    for n in mhns_list:
        if n in mhns_list and n in deg1 and ggg0_gamma.node[n]['population'] == -1:
            ggg0_gamma.node[n]['manhole'] = 1 # 1 way
        if n in mhns_list and n in deg2 and ggg0_gamma.node[n]['population'] == -1:
            ggg0_gamma.node[n]['manhole'] = 2 # 2 way
        if n in mhns_list and n in deg3 and ggg0_gamma.node[n]['population'] == -1:
            ggg0_gamma.node[n]['manhole'] = 3 # 3 way
        if n in mhns_list and ggg0_gamma.node[n]['population'] == -1 and n not in deg1 and n not in deg2 and n not in deg3:
            ggg0_gamma.node[n]['manhole'] = 0 # new manhole 

    # d: the following 4 lists are populated with tuples which contain the 
    # coordinates of each manhole. 
    # sl3 is the array with the coordinates for 3way manhole strategy
    # sl2 is the array with the coordinates for 2way manhole strategy
    # sl1 is the array with the coordinates for 1way manhole strategy
    # sl0 is the array with the coordinates for any newly placed manholes
    # They look like this: [(364743.530378, 4385079.9983749995), (364812.686628, 4385297.4983749995), (364886.118282, 4385165.991057999), (364893.35920099996, 4385141.373393999), (364873.612911, 4385208.506802),...]
    sl3 = []
    sl2 = []
    sl1 = []
    sl0 = []
    for n in ggg0_gamma.nodes():
        if ggg0_gamma.node[n]['manhole'] == 1:
            sl1.append(n)
        if ggg0_gamma.node[n]['manhole'] == 2:
            sl2.append(n)
        if ggg0_gamma.node[n]['manhole'] == 3:
            sl3.append(n)
        if ggg0_gamma.node[n]['manhole'] == 0: #the new nodes that created
            sl0.append(n)
    #
 

    
    #creation of a directed graph in order to compute the cost of each mhn
    subgs_edges = []
    for gs in subgs:
        for e in gs.edges():
            subgs_edges.append(e)
    #
    ggg0_gamma_di = nx.DiGraph() #define the digraph
    ggg0_gamma_di.add_edges_from(subgs_edges)
    ###give to manholes the splices; all except dhn node ;)
    for n in ggg0_gamma.nodes(): #initialize manholes_splices
        ggg0_gamma.node[n]['#splices'] = -1
    #
    for i in mhns_list:
        e = (ggg0_gamma_di.predecessors(i)[0],i) #edge of i in digraph
        gin = 0
        edge_fibers = literal_eval(ggg0_gamma[e[0]][e[1]]['grans_f'])[:]
        for j in range(len(edge_fibers)):
            gin = gin + edge_fibers[j]*cap_list[0][j]
        ggg0_gamma.node[i]['#splices'] = 2*gin
    ####
    #for dhn ;)
    gin_all = 0
    
    for i in range(len(ggg0_gamma_di.successors(dhn_gamma))):
        gin = 0
        e = (dhn_gamma, ggg0_gamma_di.successors(dhn_gamma)[i])
        edge_fibers = literal_eval(ggg0_gamma[e[0]][e[1]]['grans_f'])[:]
        #print edge_fibers
        for j in range(len(edge_fibers)):
            gin = gin + edge_fibers[j]*cap_list[0][j]
        gin_all = gin_all + gin
    ggg0_gamma.node[dhn_gamma]['#splices'] = 2*gin_all
    #
    write_shp(ggg0_gamma,'python/output/DistributionNetwork',shapeFileNameOne,shapeFileNameTwo)
    
    toc=timeit.default_timer()
    a = int(toc - tic)
    print 'stuff_rest'
    print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds
    
    
    return [ggg0_gamma, [sl1,sl2,sl3,sl0], bom, dhn_gamma]


#d: ShapeFilePath: a string with the location of the input shape file
#   shapeFileNameOne/shapeFileNameTwo: the names of the output shape files (one for node and one for edges)
def alphas_feeder(G,comP_dhns,dhns,dhns_splices,dhns_info,lmin,lmax,d,cap_list,cap_list_cost,cap_list_feed,cap_list_cost_feed,shapeFileNameOne,shapeFileNameTwo,shapeFilePath):
    
    from ast import literal_eval
    g_feeder = feeder_graph(G,comP_dhns,dhns)
    init_edges(g_feeder)
    #give to dhns the #splices attribute
    for ds in dhns_splices:
        g_feeder.node[ds[0]]['#splices'] = ds[1]
    #
    init_nodes(g_feeder,comP_dhns,dhns)
    #
    gamma = dhns[:]
    for i in g_feeder.nodes():
        for j in dhns:
            if G.node[i]['population'] == -1 and i not in gamma:
                gamma.append(i)
    #
    for i in range(len(dhns)):
        G.node[dhns[i]]['population'] = dhns_info[i][2]
    #
    #g_gamma = cluster_to_subready(G,gamma)
    g_gamma = cluster_to_subready_feeder(G,gamma,comP_dhns,dhns,dhns_info)
    dhn_gamma = comP_dhns
    best_dhn = dhn_gamma
    
    #
    ggg_gamma0, node100, cost100 = netwrk_cost_dummy2_not(G,g_gamma,dhn_gamma,cap_list,cap_list_cost)
    
    
    
    c = costs_tr(ggg_gamma0)[:]
    #
    bom = [dhn_gamma,c[1],c,bom_grans(ggg_gamma0,node100,cap_list_cost),ggg_gamma0][:]
    ggg_gamma = bom[4]
    

    deg3 = deg_nnn(G,ggg_gamma,3)
    deg2 = deg_nnn2(G,ggg_gamma)
    deg1 = deg_nnn1(G,ggg_gamma)
    
    #d: contains a list with the coordinates of all manholes
    dist_feed_boolean = 'feeder' #d: parameter to pass into subgraphs definition
    mhns_list0 = dhn_mhns0(G,gamma,best_dhn,deg3,deg2,deg1,lmin,lmax,d,dhns,dhns_info,cap_list,cap_list_cost,shapeFilePath,dist_feed_boolean)
    
    
    #print mhns_list0
    
    #d: Create a list with all the coordinates of the manholes
    mhns_list = []
    for i in mhns_list0:
        if i not in mhns_list:
            mhns_list.append(i)
    mhns_list.remove(best_dhn)
    #
    hyperfinalgraph(G,mhns_list)
    #
    g0_gamma = cluster_to_subready_feeder(G,gamma,comP_dhns,dhns,dhns_info)
    ##############
    ggg0_gamma, node1000, cost1000, subgs = netwrk_cost_dummy000sub(G,g0_gamma,dhn_gamma,cap_list,cap_list_cost,dist_feed_boolean)
    


    #
    for u,v,d in ggg0_gamma.edges(data=True):
        if 'ALPHA' in d:
            del d['ALPHA']
        if 'grans' in d:
            del d['grans']
        if 'grans_c' in d:
            del d['grans_c']
        if 'mun_code' in d:
            del d['mun_code']
        if 'mun_name' in d:
            del d['mun_name']
        if 'name' in d:
            del d['name']
        if 'population' in d:
            del d['population']
        if 'length' in d:
            del d['length']
        if 'x___gid' in d:
            del d['x___gid']
        if 'building_i' in d:
            del d['building_i']
        if 'gid' in d:
            del d['gid']
        if 'id' in d:
            del d['id']
        if 'x_gid' in d:
            del d['x_gid']
        if 'block_id' in d:
            del d['block_id']
        if 'gid_01' in d:
            del d['gid_01']
        if 'manhole' in d:
            del d['manhole']
    #
    for n,d in ggg0_gamma.nodes(data=True):
        if 'suc2gload' in d:
            del d['suc2gload']
        if 'sucgload' in d:
            del d['sucgload']
        if 'sucggload' in d:
            del d['sucggload']
    
    
    
    # d: Assigning the manhole strategy to the nodes of the graph which are manholes
    for n in mhns_list:
        if n in mhns_list and n in deg1 and ggg0_gamma.node[n]['population'] == -1:
            ggg0_gamma.node[n]['manhole'] = 1
            
        if n in mhns_list and n in deg2 and ggg0_gamma.node[n]['population'] == -1:
            ggg0_gamma.node[n]['manhole'] = 2
            
        if n in mhns_list and n in deg3 and ggg0_gamma.node[n]['population'] == -1:
            ggg0_gamma.node[n]['manhole'] = 3
            
        if n in mhns_list and ggg0_gamma.node[n]['population'] == -1 and n not in deg1 and n not in deg2 and n not in deg3:
            ggg0_gamma.node[n]['manhole'] = 0
           
   

   
    # d: the following 4 lists are populated with tuples which contain the 
    # coordinates of each manhole. 
    # sl3 is the array with the coordinates for 3way manhole strategy
    # sl2 is the array with the coordinates for 2way manhole strategy
    # sl1 is the array with the coordinates for 1way manhole strategy
    # sl0 is the array with the coordinates for any newly placed manholes
    # They look like this: [(364743.530378, 4385079.9983749995), (364812.686628, 4385297.4983749995), (364886.118282, 4385165.991057999), (364893.35920099996, 4385141.373393999), (364873.612911, 4385208.506802),...]
    sl3 = []
    sl2 = []
    sl1 = []
    sl0 = []
    for n in ggg0_gamma.nodes():
        if ggg0_gamma.node[n]['manhole'] == 1:
            sl1.append(n)
        if ggg0_gamma.node[n]['manhole'] == 2:
            sl2.append(n)
        if ggg0_gamma.node[n]['manhole'] == 3:
            sl3.append(n)
        if ggg0_gamma.node[n]['manhole'] == 0: #the new nodes that created
            sl0.append(n)
    #
    
    
    #creation of a directed graph in order to compute the cost of each mhn
    subgs_edges = []
    for gs in subgs:
        for e in gs.edges():
            subgs_edges.append(e)
    #
    ggg0_gamma_di = nx.DiGraph() #define the digraph
    ggg0_gamma_di.add_edges_from(subgs_edges)
    ###give to manholes the splices; all except dhn node ;)
    for n in ggg0_gamma.nodes(): #initialize manholes_splices
        ggg0_gamma.node[n]['#splices'] = -1
    #
    for i in mhns_list:
        e = (ggg0_gamma_di.predecessors(i)[0],i) #edge of i in digraph
        gin = 0
        edge_fibers = literal_eval(ggg0_gamma[e[0]][e[1]]['grans_f'])[:]
        for j in range(len(edge_fibers)):
            gin = gin + edge_fibers[j]*cap_list[0][j]

        #ggg0_gamma.node[i]['#splices'] = 2*gin
        ggg0_gamma.node[i]['#splices'] = gin
    #for dhn
    gin_all = 0
    for i in range(len(ggg0_gamma_di.successors(dhn_gamma))):
        gin = 0
        e = (dhn_gamma, ggg0_gamma_di.successors(dhn_gamma)[i])
        edge_fibers = literal_eval(ggg0_gamma[e[0]][e[1]]['grans_f'])[:]
        #print edge_fibers
        for j in range(len(edge_fibers)):
            gin = gin + edge_fibers[j]*cap_list[0][j]
        gin_all = gin_all + gin
    #ggg0_gamma.node[dhn_gamma]['#splices'] = 2*gin_all
    ggg0_gamma.node[dhn_gamma]['#splices'] = gin_all
    #
    for n in dhns:
        gransf_l = literal_eval(ggg0_gamma[n][ggg0_gamma_di.predecessors(n)[0]]['grans_f'])[:]
        s = 0
        for i in range(len(gransf_l)):
            s = s + gransf_l[i]*cap_list_feed[0][i]
        ggg0_gamma.node[n]['#splices'] = s
    ss = 0
    for i in dhns_info:
        ss = ss + i[2]
    ggg0_gamma.node[comP_dhns]['population'] = ss
    write_shp(ggg0_gamma,'python/output/centralOffice',shapeFileNameOne,shapeFileNameTwo)
    return [ggg0_gamma, [sl1,sl2,sl3,sl0], bom, dhn_gamma, ggg0_gamma_di]


# d: Creates an array with the length of specific values. Eg. the total number of manholes
# for each strategy (1-way, 2ways etc.)
def omhns_cl_def(l_ath1):
    omhns_cl = []
    for l in l_ath1:
        omhns_cl.append(len(l))
    return omhns_cl


###############################################################################
####################### using literal_eval(string) ############################
#############################     The End      ################################


###############################################################################
###                             FEEDERING                                   ###
###############################################################################
###############################################################################
###############################################################################

def feeder_graph(G,comP_dhns,dhns):
    return cluster_to_subgraph_f(G,dhns,comP_dhns)[0]


def init_nodes(g_feeder,comP_dhns,dhns):
    for n in g_feeder.nodes():
        if n == comP_dhns:
            g_feeder.node[n]['CO'] = 1
        else:
            g_feeder.node[n]['CO'] = -1
        if n in dhns:
            g_feeder.node[n]['dhn'] = 1
        else:
            g_feeder.node[n]['dhn'] = -1
        if n not in dhns and n != comP_dhns:
            g_feeder.node[n]['#splices'] = -1


def cap_gran_cost_feed(DD,cost_node,cap_list_feed):
    D = DD
    c_node = cost_node
    load_p = D.node[c_node]['#splices']
    #computing
    #the input list of the next cap_gran is the sum of the previous output of it
    cap_gran_list = []
    res_gran_list = []
    m = load_p #init time
    for i in range(len(cap_list_feed)-1):
        b_list = cap_list_feed[i][:] #one gran at the time
        res_gran_list = cap_gran(m,b_list)[:] #output of cap_gran
        cap_gran_list.append(res_gran_list) #append it to final gran list
        res_gran = 0 #compute the sum of lmnts of the res_gran_list in order to have them as input to the next cap_list lmnt
        for j in range(len(res_gran_list)):
            res_gran = res_gran + res_gran_list[j]
        m = res_gran
    cap_gran_list.append([1])
    return cap_gran_list


###compute the grans according to the above input table for each dhn node
def cap_gran_cost_feed_costall(G,g_feeder,comP_dhns,dhns,cap_list_feed,cap_list_cost_feed):
    e_all_l = []
    nL_all_l = []
    e_ll = []
    for dhns_node in dhns:
        cgcf = []
        cgcf = cap_gran_cost_feed(g_feeder,dhns_node,cap_list_feed)[:] 
        #create the list of nodes of the path from comP_dhns to dhn_node
        nL = []
        nL = nx.dijkstra_path(G,comP_dhns,dhns_node) 
        nL_len = nx.dijkstra_path_length(G,comP_dhns,dhns_node)
        nL_all_l.append(nL)
        #create the list of edges of the path from comP_dhns to dhn_node
        e_l = []
        for j in range(len(nL)-1):
            e_l.append((nL[j], nL[j+1]))
            e_ll.append((nL[j], nL[j+1]))
        e_all_l.append([e_l,nL_len])
        #
        gran_cost_list = []
        for c in range(len(cgcf)):
            c_l = []
            for i in range(len(cgcf[c])):
                c_l.append(cgcf[c][i]*cap_list_cost_feed[c][i])
            gran_cost_list.append(c_l)
        #summation of gran_cost_list lmnts; total cost
        s_all = 0
        for c in gran_cost_list:
            s = 0
            for i in c:
                s = s + i
            s_all = s_all + s
        #give to edges the atts
        for e in e_l:
            if e in g_feeder.edges():
                g_feeder[e[0]][e[1]]['gr_cost'] = g_feeder[e[0]][e[1]]['weight'] * s_all
                g_feeder[e[0]][e[1]]['grans_d'] = cgcf[3]
                g_feeder[e[0]][e[1]]['grans_f'] = cgcf[0]
                g_feeder[e[0]][e[1]]['grans_s'] = cgcf[2]
                g_feeder[e[0]][e[1]]['tr_cost'] = g_feeder[e[0]][e[1]]['weight'] * 7 #trenching cost
                g_feeder[e[0]][e[1]]['dum_cost'] = g_feeder[e[0]][e[1]]['gr_cost'] + g_feeder[e[0]][e[1]]['tr_cost']
            else:
                g_feeder[e[1]][e[0]]['gr_cost'] = g_feeder[e[0]][e[1]]['weight'] * s_all
                g_feeder[e[1]][e[0]]['grans_d'] = cgcf[3]
                g_feeder[e[1]][e[0]]['grans_f'] = cgcf[0]
                g_feeder[e[1]][e[0]]['grans_s'] = cgcf[2]
                g_feeder[e[1]][e[0]]['tr_cost'] = g_feeder[e[0]][e[1]]['weight'] * 7 #trenching cost
                g_feeder[e[1]][e[0]]['dum_cost'] = g_feeder[e[0]][e[1]]['gr_cost'] + g_feeder[e[0]][e[1]]['tr_cost']
    #############create the digraph in order to play with the manholes
    gw = nx.DiGraph() #define and initialize the digraph
    gw.add_edges_from(e_ll)
    for e in gw.edges():
        gw[e[0]][e[1]]['gr_cost'] = g_feeder[e[0]][e[1]]['gr_cost']
        gw[e[0]][e[1]]['grans_d'] = g_feeder[e[0]][e[1]]['grans_d']
        gw[e[0]][e[1]]['grans_f'] = g_feeder[e[0]][e[1]]['grans_f']
        gw[e[0]][e[1]]['grans_s'] = g_feeder[e[0]][e[1]]['grans_s']
        gw[e[0]][e[1]]['tr_cost'] = g_feeder[e[0]][e[1]]['tr_cost']
        gw[e[0]][e[1]]['dum_cost'] = g_feeder[e[0]][e[1]]['dum_cost']
        gw[e[0]][e[1]]['weight'] = g_feeder[e[0]][e[1]]['weight']
    for n in gw.nodes():
        gw.node[n]['#splices'] = g_feeder.node[n]['#splices']
        gw.node[n]['CO'] = g_feeder.node[n]['CO']
        gw.node[n]['dhn'] = g_feeder.node[n]['dhn']
    for n in gw.nodes():
        gw.node[n]['manhole'] = -1
        gw.node[n]['population'] = -1
    ###########total cost of grans
    gr_d_all = []
    gr_f_all = []
    gr_s_all = []
    for j in range(len(e_all_l)):
        gr_d_l = []
        gr_f_l = []
        gr_s_l = []
        e = e_all_l[j][0][0]
        w = e_all_l[j][1]
        for i in g_feeder[e[0]][e[1]]['grans_d']:
            gr_d_l.append(i*w)
        for i in g_feeder[e[0]][e[1]]['grans_f']:
            gr_f_l.append(i*w)
        for i in g_feeder[e[0]][e[1]]['grans_s']:
            gr_s_l.append(i*w)
        gr_d_all.append(gr_d_l)
        gr_f_all.append(gr_f_l)
        gr_s_all.append(gr_s_l)
    #
    gr_fsd_all = [gr_f_all,gr_s_all,gr_d_all]
    fsd_all = []
    for gr_s_all0 in gr_fsd_all:
        fs_all = []
        for i in range(len(gr_s_all0[0])):
            fs_all.append(0)
        for i in range(len(gr_s_all0)):
            #print len(gr_s_all[i])
            for j in range(len(gr_s_all0[i])):
                #print gr_s_all[i][j]
                fs_all[j] = fs_all[j] + gr_s_all0[i][j]
        fsd_all.append(fs_all)
    #rounding
    for i in range(len(fsd_all)):
        for j in range(len(fsd_all[i])):
            fsd_all[i][j] = round(fsd_all[i][j],3)
    ###########
    #for shp we have to make strings everything
    for e in g_feeder.edges():
        g_feeder[e[0]][e[1]]['grans_f'] = str(g_feeder[e[0]][e[1]]['grans_f'])
        g_feeder[e[0]][e[1]]['grans_s'] = str(g_feeder[e[0]][e[1]]['grans_s'])
        g_feeder[e[0]][e[1]]['grans_d'] = str(g_feeder[e[0]][e[1]]['grans_d'])
        g_feeder[e[0]][e[1]]['gr_cost'] = str(g_feeder[e[0]][e[1]]['gr_cost'])
        g_feeder[e[0]][e[1]]['tr_cost'] = str(g_feeder[e[0]][e[1]]['tr_cost'])
        g_feeder[e[0]][e[1]]['dum_cost'] = str(g_feeder[e[0]][e[1]]['dum_cost'])
    #
    for u,v,d in g_feeder.edges(data=True):
        if 'ALPHA' in d:
            del d['ALPHA']
        if 'grans' in d:
            del d['grans']
        if 'grans_c' in d:
            del d['grans_c']
        if 'mun_code' in d:
            del d['mun_code']
        if 'mun_name' in d:
            del d['mun_name']
        if 'name' in d:
            del d['name']
        if 'population' in d:
            del d['population']
        if 'length' in d:
            del d['length']
        if 'x___gid' in d:
            del d['x___gid']
        if 'building_i' in d:
            del d['building_i']
        if 'gid' in d:
            del d['gid']
        if 'id' in d:
            del d['id']
        if 'x_gid' in d:
            del d['x_gid']
        if 'block_id' in d:
            del d['block_id']
        if 'gid_01' in d:
            del d['gid_01']
        if 'manhole' in d:
            del d['manhole']
    #
    for n,d in g_feeder.nodes(data=True):
        if 'block_id' in d:
            del d['block_id']
        if 'building_i' in d:
            del d['building_i']
    #write_shp(g_feeder,'/home/bluesman/Dropbox/NGNMarcostuff/LarissasPython/aa_scratch/shps/check1/best_CO')
    return [gw,fsd_all,e_all_l,nL_all_l]



def mhns_f0(sl_0,sl30,g0,lfs_g0,lmin,lmax):
    nodes_l0 = mhns_f(sl_0,g0,lmin,lmax)[:]
    #find the lfs edges of sl30
    e_l = []
    for j in sl30:
        if g0.node[j]['population'] != -1:
            e_l.append([g0.predecessors(j)[0],j])
    n_l = []
    ne_l = []
    for n in nodes_l0:
        for e in e_l:
            if p_to_edge(e,n):
                n_l.append(n)
                ne_l.append([e[0],n])
    nodes_l = nodes_l0[:]
    for i in ne_l:
        if i[0] not in nodes_l:
            nodes_l.append(i[0])
        nodes_l.remove(i[1])
    return nodes_l


 # Function: prepare_shapefile. 
    # Description: Takes as input the path of the initial shapefile and the numberOfClusters, prepares the graph 
    # and returns the graph G
    # Input: shapefile path, the number of clusters
    # Output: graph G         
def prepare_shapefile(shpfile,numberOfClusters):
    larissa =  nx.DiGraph.to_undirected(nx.read_shp(shpfile))#forNetX
    #Initializing NSF    
    set_new_attribute_to_nodes(larissa,'population',-1.0)
    set_new_attribute_to_nodes(larissa,'building_i',-1)
    set_new_attribute_to_nodes(larissa,'block_id',-1)
    set_new_attribute_to_nodes(larissa,'manhole',-1)
    # set an attribute which indicates the cluster number
    #set_new_attribute_to_nodes(larissa,'cluster',numberOfClusters)

    change_length_attr(larissa)
    num = find_building_edges_and_update_nodes(larissa)
    restore_attributes(larissa)
    check = [nod for nod in larissa.degree() if larissa.degree(nod) > 1 and larissa.node[nod]['population'] != -1]
    ###d = nx.connected_component_subgraphs(larissa)        
    #Initialize Main Graph G
    G = larissa.copy()
    population_to_int(G)
    return G
