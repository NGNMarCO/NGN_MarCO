
tmp folder: contains a number of text files that are created during the runtime of the algorithm.
These files contain non human-readable data, which are created using Python 'pickle' module.
We use this method to transfer data from one Python module (e.g. Clustering module) to another 
(e.g. Distribution Network module) while at the same time the structure and format of the data is not lost.
This way we bypass the process of returning data through Python to PHP and from there passing them again 
through PHP exec() command to the next Python module.
