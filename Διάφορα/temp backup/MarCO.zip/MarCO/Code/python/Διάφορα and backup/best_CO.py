###############################################################################
###                              Best CO                                    ###
###############################################################################
###############################################################################
# run it with all_n
import sys
import networkx as nx
import matplotlib.pyplot as plt
import math
import random
from heapq import heappop, heappush
import copy
import profile
from all_caps import (set_new_attribute_to_nodes,change_length_attr,find_building_edges_and_update_nodes,restore_attributes,population_to_int,
                      alphas_distribution,omhns_cl_def,mhns_cost_d,cluster_invs_dummy22,cluster_to_subready,find_best_CO)


############################ Distribution Input ###############################
###############################################################################
#About Normalized Shp File
larissa =  nx.DiGraph.to_undirected(nx.read_shp('aa_scratch0/dimitris_shapefile/larissa_dimitris_subset.shp'))#forNetX

#Initializing NSF
set_new_attribute_to_nodes(larissa,'population',-1.0)
set_new_attribute_to_nodes(larissa,'building_i',-1)
set_new_attribute_to_nodes(larissa,'block_id',-1)
set_new_attribute_to_nodes(larissa,'manhole',-1)
change_length_attr(larissa)
num = find_building_edges_and_update_nodes(larissa)
restore_attributes(larissa)
check = [nod for nod in larissa.degree() if larissa.degree(nod) > 1 and larissa.node[nod]['population'] != -1]
###d = nx.connected_component_subgraphs(larissa)

#Initialize Main Graph G
G = larissa.copy()
population_to_int(G)

############################# Feeder Input ####################################
###############################################################################
#About Grans Input
#cap_fc_feed = [24,48,96,144,192] #fibres/cable
#cap_fc_feed = [96,192] #fibres/cable
#cap_cs_feed = [1] #cable/subduct must not be deleted!!!
#cap_sd_feed = [7,14] #subduct/duct
#cap_d_feed = [1]
#cap_list_feed = [cap_fc_feed,cap_cs_feed,cap_sd_feed,cap_d_feed]
cap_list_feed = [[96,192],[1],[7,14],[1]]

#cap_fc_cost_feed = [1.0,1.08,1.15,1.2,1.24]
#cap_fc_cost_feed = [1.15,1.40]
#cap_cs_cost_feed = [0.0] 
#cap_sd_cost_feed = [2,3]
#cap_d_cost_feed = [1]
#cap_list_cost_feed = [cap_fc_cost_feed,cap_cs_cost_feed,cap_sd_cost_feed,cap_d_cost_feed]
cap_list_cost_feed = [[1.15,1.40],[0.0],[2,3],[1]]

#About DHNs and CO input
#dhns = [(365222.84984, 4387176.276393999),(365005.328577, 4385404.523798),(363957.65778099996, 4386449.375297)]
#dhns_info = [[365222.84984, 4387176.276393999,1632],[365005.328577, 4385404.523798,2400],[363957.65778099996, 4386449.375297,912]]


dhns =  [(365238.936628, 4385304.4983749995), (364967.530378, 4385309.4983749995)]
dhns_info =  [[365238.936628, 4385304.4983749995, 1570],[364967.530378, 4385309.4983749995, 3188]]


#dhns = [(365686.570444, 4384412.112225), (365390.72734499996, 4387044.1195829995), (365533.54899599997, 4387283.611186), (364113.269751, 4386680.914063), (363431.780377, 4386293.9983749995), (363113.263642, 4386012.833346), (363996.271509, 4385827.315316), (365390.72734499996, 4387044.1195829995), (363964.212036, 4386766.3944769995)]

#dhns_info = [[365686.570444, 4384412.112225,850], [365390.72734499996, 4387044.1195829995, 789], [365533.54899599997, 4387283.611186, 801], [364113.269751, 4386680.914063,780], [363431.780377, 4386293.9983749995,673], [363113.263642, 4386012.833346,879], [363996.271509, 4385827.315316, 680], [365390.72734499996, 4387044.1195829995, 802], [363964.212036, 4386766.3944769995,770]]

#comP_dhns = (364848.405377, 4386402.498373)#
rr = 0.1
#CO_cost = 10000

#About Minimum, Maximum Blow-Reel Distance, Kind of Manholes and Cost
#lmin = 0
#lmax = 500
#d = 3 #The possible values are {3, 2, 1, 32, 31, 21, 321}
#mhn_cost = [20,100,500,100,500,20,100,500]
#mhn_c_l =  [0,0,0,1,0,0,1,0]
###############################################################################

#import timeit
#tic=timeit.default_timer()

fbCO = find_best_CO(G,dhns,dhns_info,rr,cap_list_feed)
print fbCO

#toc=timeit.default_timer()
#a = int(toc - tic)
#print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds

###############################################################################
#####                              Time                                   #####

#[(365160.874127, 4385700.498374), 75774.92]

#real    10m53.929s
#user    10m47.074s
#sys    0m0.678s

#comP_dhns = (364744.780377, 4386165.498373)
###############################################################################

################################ The End ######################################
###############################################################################
###                              Best CO                                    ###
###############################################################################
###############################################################################
###############################################################################

