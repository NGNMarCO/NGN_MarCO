####################################################################################################
# 1) GET INPUT DATA FROM A CSV FILE
# 2) RUN CLUSTERING ALGORITH AND OUTPUS A CSV FILE WITH CLUSTER COORDS
# 3) RUN BESTDHNS FUNCTION IN ORDER TO FIND THE BEST LOCATION TO PLACE THE DISTRIBUTION HUB NODE
# 4) RUN DISTRIBUTION_STUFF TO GET SHAPE FILES WITH EDGES/NODES AND PRINT COSTS
####################################################################################################
####################################################################################################
# IMPORT LIBS AND FILES
##########################################################################

import networkx as nx
import timeit
import csv
from all_caps import (set_new_attribute_to_nodes,change_length_attr,find_building_edges_and_update_nodes,restore_attributes,population_to_int,
akcom0_smsms_fixed_norm,norm_akcom0_smsms_fixed_norm,print_mass,akcom0_smsms_fixed_norm_max_mass_only,find_best_dhn,alphas_distribution,omhns_cl_def,
mhns_cost_d,cluster_invs_dummy22,cluster_to_subready,find_best_CO,alphas_feeder)



##########################################################################
# READ THE CSV FILE WITH THE INPUT DATA
##########################################################################
finput = open('CSV_Inputs/input_dataBuilding.csv')
csv_input = csv.reader(finput,delimiter=';')
csv_input.next()
inputs = []
for row in csv_input:
    #print(row)
    inputs.extend(row)   
shapeFilePath = inputs[0]
numberOfClusters = inputs[1]
##########################################################################
# CREATE GRAPH USING THE SHAPE FILE
##########################################################################
larissa =  nx.DiGraph.to_undirected(nx.read_shp(shapeFilePath))#forNetX
##########################################################################
# SET EXTRA ATTRIBUTES TO NODES -  Initializing NSF
##########################################################################
set_new_attribute_to_nodes(larissa,'population',-1.0)
set_new_attribute_to_nodes(larissa,'building_i',-1)
set_new_attribute_to_nodes(larissa,'block_id',-1)
set_new_attribute_to_nodes(larissa,'manhole',-1)
change_length_attr(larissa)
num = find_building_edges_and_update_nodes(larissa)
restore_attributes(larissa)
check = [nod for nod in larissa.degree() if larissa.degree(nod) > 1 and larissa.node[nod]['population'] != -1]
###d = nx.connected_component_subgraphs(larissa)
##########################################################################
# INITIALIZE MAIN GRAPH: G
##########################################################################
G = larissa.copy()
population_to_int(G)
numberOfClusters = int(numberOfClusters) # CONVERT STRINT TO INT
cls00 = akcom0_smsms_fixed_norm(G,numberOfClusters) #equal masses
cls000 = norm_akcom0_smsms_fixed_norm(cls00,numberOfClusters)
#print(cls000[0])
#print(cls000[1])
##########################################################################
# SAVE THE COORDINATES FOR THE CLUSTER POINTS INTO A CSV
##########################################################################
with open('CSV_Inputs/clusterCoordsNorm.csv', 'w') as fp:
    writer = csv.writer(fp, delimiter=',')
    for counterOne in cls000:
        #print(counterOne)
        for counterTwo in counterOne:
            #print(counterTwo[0])
            #print(counterTwo[1])
            # ADD VALUE TO CSV
            data = [[counterTwo[0],counterTwo[1]]]
            writer.writerows(data)
##########################################################################
# EXECUTE PRINT_MASS FUNCTION
##########################################################################        
l = print_mass(G,cls000)[:]
print(l)
##########################################################################
# EXECUTE akcom0_smsms_fixed_norm_max_mass_only FUNCTION
##########################################################################  
mplith = akcom0_smsms_fixed_norm_max_mass_only(G,numberOfClusters) #1976



# LOOP FOR EVERY CLUSTER GROUP
for clusterNumber in range(0,numberOfClusters):
##########################################################################
# EXECUTE best_dhns
########################################################################## 
    '''
    gamma = cls000[clusterNumber][:]
    shapeFileNameOne = 'nodesDistributionHubNetwork'+str(clusterNumber)
    shapeFileNameTwo = 'edgesDistributionHubNetwork'+str(clusterNumber)
    #print(shapeFileNameOne)     
    #print(gamma)
    cap_list = [[1,2,4,8,24,48,96,144],[1],[7,24],[1]]
    cap_list_cost = [[1.0,1.08,1.15,1.2,1.24,1.3,1.4,1.48],[0.0],[2,3],[1]]
    rr = 0.1 # values in [0,1], if it is 0 then just take the comP, 

    tic=timeit.default_timer()

    fbd = find_best_dhn(G,gamma,rr,cap_list,cap_list_cost)
    print fbd

    toc=timeit.default_timer()
    a = int(toc - tic)
    print str(a/60)+ " mins and " + str(a%60)+ " secs" #elapsed time in seconds



    ##########################################################################
    # EXECUTE distribution_stuff
    ########################################################################## 
    ##########################################################################
    # INPUTS FOR THE REQUIRED FUNCTION
    ########################################################################## 
    dhn_gamma = fbd[1][:] # OUTPUT FROM best_dhns - THE X,Y COORDS OF THE BEST LOCATION FOR THE DISTRIBUTION HUB
    DHN_cost = 3000 # INPUT - THE COST OF THE KV
    lmin = 0 # MIN DISTANCE TO PLACE MANHOLE
    lmax = 2000 # MAX DISTANCE TO PLACE MANHOLE
    d = 3 # MANHOLE STRATEGY
    mhn_cost = [20,100,500,100,500,20,100,500] # COST OF MANHOLES BASED ON STRATEGY
    mhn_c_l =  [0,0,0,1,0,0,1,0] # COST OF MANHOLES BASED ON STRATEGY - BASED ON THE ABOVE
    p = 100 # PERCENTAGE OF COVERAGE
    ##########################################################################
    # Distribution Run
    ##########################################################################

    
    ath = alphas_distribution(G,gamma,dhn_gamma,lmin,lmax,d,cap_list,cap_list_cost,shapeFileNameOne,shapeFileNameTwo)
    omhns_cl = omhns_cl_def(ath[1])
    mhns_costing = mhns_cost_d(ath[0],mhn_c_l,mhn_cost,omhns_cl,d)
    bomd = ath[2][:]
    ##########################################################################
    # Distribution Output
    ##########################################################################
    if p == 100:
        out_distribution = [ath[2][3],ath[2][2],omhns_cl, mhns_costing]
    else:
        gf, nf, cf = cluster_invs_dummy22(G,cluster_to_subready(G,ath[0].nodes()),dhn_gamma,p,cap_list)
        ath = alphas_distribution(G,gf.nodes(),dhn_gamma,lmin,lmax,d,cap_list,cap_list_cost,shapeFileNameOne,shapeFileNameTwo)[:]
        omhns_cl = omhns_cl_def(ath[1])[:]
        mhns_costing = mhns_cost_d(ath[0],mhn_c_l,mhn_cost,omhns_cl,d)
        bomd = ath[2][:]
        #dhn_gamma = ath[3]
        out_distribution = [ath[2][3],ath[2][2],omhns_cl, mhns_costing][:]
    ###############################################################################
    ############################ Distribution Output ##############################
    ###############################################################################
    print "------------------------------------------------------------------------"
    print "~" + str(p) + "% of the Network"
    print "---"
    print "Length of f/c Grans " + str(cap_list[0]) + " is: " + str(bomd[3][0][0]),"m"
    print "---"
    print "Length of s/d Grans " + str(cap_list[2]) + " is: " + str(bomd[3][1][0]),"m"
    print "---"
    print "Length of d Grans " + str(cap_list[3]) + " is: " + str(bomd[3][2][0]),"m"
    print "---"
    print "Total Feeder Network Length: " + str(bomd[2][0]),"m"
    print "---"
    print "Total Feeder Network Cost: " + str(bomd[2][1] + mhns_costing + DHN_cost), "$"
    print "---"
    print "Total Feeder Network Trench Cost: " + str(bomd[2][2]),"$"
    print "---"
    print "Total Feeder Network Gran Cost: " + str(bomd[2][3]),"$"
    print "---"
    print "Number of Manholes Oneway: " + str(omhns_cl[0])
    print "---"
    print "Number of Manholes Twoway: " + str(omhns_cl[1])
    print "---"
    print "Number of Manholes Threeway: " + str(omhns_cl[2])
    print "---"
    print "Number of New Manholes: " + str(omhns_cl[3])
    print "---"
    print "Manholes Cost: ", mhns_costing,"$"  #correct it because of 1
    print "---"
    print "Number of Splices in DHN: " + str(ath[0].node[dhn_gamma]['#splices'])
    print "---"
    print "DHN cost: " + str(DHN_cost)
    print "------------------------------------------------------------------------"
    ################################ The End ######################################
    
    ##########################################################################
    # EXECUTE best_CO.py - FIND BEST LOCATION TO LOCATE CENTRAL OFFICE
    ########################################################################## 
    '''
    
    
    cap_list_feed = [[96,192],[1],[7,14],[1]]
    cap_list_cost_feed = [[1.15,1.40],[0.0],[2,3],[1]]
    #About DHNs and CO input
    #dhns = [(365238.936628, 4385304.4983749995),(364967.530378, 4385309.4983749995)]
    #dhns_info = [[365238.936628, 4385304.4983749995,1632],[364967.530378, 4385309.4983749995,2400]]
    
    dhns = [(365238.936628, 4385304.4983749995),(364967.530378, 4385309.4983749995)]
    dhns_info = [[365238.936628, 4385304.4983749995,1632],[364967.530378, 4385309.4983749995,2400]]
    
    
    
    rr = 0.1
    fbCO = find_best_CO(G,dhns,dhns_info,rr,cap_list_feed)
    print fbCO
    
    '''
    
    ##########################################################################
    # EXECUTE feeder_stuff.py
    ########################################################################## 
    
    
    cap_list_feed = [[96,192],[1],[7,14],[1]]
    cap_list_cost_feed = [[1.15,1.40],[0.0],[2,3],[1]]
    cap_list = cap_list_feed[:]
    cap_list_cost = cap_list_cost_feed[:]
    CO_cost = 10000
    #comP_dhns = (365160.874127, 4385700.498374) #best one taken from best_CO.py
    comP_dhns = (364986.436628, 4385252.4983749995) #best one taken from best_CO.py
    
    
    
    #dhns = [(365222.84984, 4387176.276393999),(365005.328577, 4385404.523798),(363957.65778099996, 4386449.375297)]
    #dhns_info = [[365222.84984, 4387176.276393999,1632],[365005.328577, 4385404.523798,2400],[363957.65778099996, 4386449.375297,912]]
    

    dhns_splices = []
    s = 0
    for i in range(len(dhns_info)):
        s = s + dhns_info[i][2]
    dhns_splices.append([comP_dhns,s])
    for i in range(len(dhns)):
        dhns_splices.append([dhns[i],dhns_info[i][2]])


    #About Minimum, Maximum Blow-Reel Distance, Kind of Manholes and Cost
    lmin = 0
    lmax = 500
    d = 3 #The possible values are {3, 2, 1, 32, 31, 21, 321}
    mhn_cost = [20,100,500,100,500,20,100,500]
    mhn_c_l =  [0,0,0,1,0,0,1,0]
    ###############################################################################

    ############################### Feeder Run ####################################
    ###############################################################################
    ath = alphas_feeder(G,comP_dhns,dhns,dhns_splices,dhns_info,lmin,lmax,d,cap_list,cap_list_cost,cap_list_feed,cap_list_cost_feed)
    omhns_cl = omhns_cl_def(ath[1])
    mhns_costing = mhns_cost_d(ath[0],mhn_c_l,mhn_cost,omhns_cl,d)
    bomd = ath[2][:]
    gx_final = ath[0].copy()
    out_feeder = [ath[2][3],ath[2][2],omhns_cl, mhns_costing]
    ###############################################################################

    ############################# Feeder Output ###################################
    ###############################################################################
    cost_net = bomd[2][1] + mhns_costing + CO_cost

    print "------------------------------------------------------------------------"
    print "Length of f/c Grans " + str(cap_list_feed[0]) + " is: " + str(out_feeder[0][0]),"m"
    print "---"
    print "Length of s/d Grans " + str(cap_list_feed[2]) + " is: " + str(out_feeder[0][1]),"m"
    print "---"
    print "Length of d Grans " + str(cap_list_feed[3]) + " is: " + str(out_feeder[0][2]),"m"
    print "---"
    print "Total Feeder Network Length: " + str(out_feeder[1][0]),"m"
    print "---"
    print "Total Feeder Network Cost: " + str(out_feeder[1][1] + out_feeder[3] + CO_cost), "$"
    print "---"
    print "Total Feeder Network Trench Cost: " + str(out_feeder[1][2]),"$"
    print "---"
    print "Total Feeder Network Gran Cost: " + str(out_feeder[1][3]),"$"
    print "---"
    print "Number of Manholes Oneway: " + str(out_feeder[2][0])
    print "---"
    print "Number of Manholes Twoway: " + str(out_feeder[2][1])
    print "---"
    print "Number of Manholes Threeway: " + str(out_feeder[2][2])
    print "---"
    print "Number of New Manholes: " + str(out_feeder[2][3])
    print "---"
    print "Manholes Cost: " + str(out_feeder[3]),"$"
    print "---"
    print "Number of Splices in CO: " + str(gx_final.node[comP_dhns]['#splices'])
    print "---"
    print "CO cost: " + str(CO_cost)
    print "---"
    print "Number of Splices in DHNs: ", 
    for n in dhns: 
        print str(gx_final.node[n]['#splices']) + ".",
    print ""
    print "------------------------------------------------------------------------"
    ################################ The End ######################################
    ###############################################################################
    ###                             FEEDERING                                   ###
    ###############################################################################
    ###############################################################################
    ###############################################################################
    ###############################################################################
    '''
