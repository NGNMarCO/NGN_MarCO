# READ A CSV FILE WITH THE INPUT DATA
import csv
import ast
finput = open('input_dataBuilding.csv')
csv_input = csv.reader(finput,delimiter=';')
csv_input.next()
inputs = []
for row in csv_input:
    #print(row)
    inputs.extend(row)
    
#print(inputs)

shape = inputs[0]
kk = inputs[1]
cap_fc = inputs[3]
cap_list_cost_d = inputs[4]


cap_list_cost_d = ast.literal_eval(cap_list_cost_d)
#print(type(cap_fc))
print(cap_list_cost_d[1])
