# CONNECT TO POSTGRESQL DATABASE
import sys
import networkx as nx
import matplotlib.pyplot as plt
import math
import random
from heapq import heappop, heappush
import psycopg2 #to access database with python


'''
G =  nx.DiGraph.to_undirected(nx.read_shp('./aa_scratch0/axons_larissa_with_buildings6_sub0.shp'))
for x in G:
    print (x)
'''

try:
    conn = psycopg2.connect("dbname='rural' user='postgres' host='localhost' password='postgres'")
except:
    print "I am unable to connect to the database"
    
cur = conn.cursor()
cur.execute("""SELECT * from imgrural""")
rows = cur.fetchall()

for row in rows:
    print "   ", row[1]