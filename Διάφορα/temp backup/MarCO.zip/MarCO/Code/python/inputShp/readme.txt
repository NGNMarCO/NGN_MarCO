This folder contains the input shape files for the Python algorithm (already processed so they are suitable for 
the code).

