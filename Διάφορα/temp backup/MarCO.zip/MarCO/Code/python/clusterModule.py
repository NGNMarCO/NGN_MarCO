####################################################################################################
# 1) GET INPUT DATA FROM A CSV FILE
# 2) RUN CLUSTERING ALGORITH AND OUTPUS A CSV FILE WITH CLUSTER COORDS
####################################################################################################
####################################################################################################
# IMPORT LIBS AND FILES
##########################################################################

import networkx as nx
import timeit
import csv
import sys # read variables passed from PHP exec
import json # convert a string to list of lists
import pickle # for serialization/deserialization of cluster coords (passing to distributionNetModule)
from all_functions import (set_new_attribute_to_nodes,change_length_attr,find_building_edges_and_update_nodes,restore_attributes,population_to_int,
akcom0_smsms_fixed_norm,norm_akcom0_smsms_fixed_norm,print_mass,akcom0_smsms_fixed_norm_max_mass_only,omhns_cl_def,cluster_to_subready,write_shp,prepare_shapefile)


##########################################################################
# GET THE INPUTS FROM TEXTFIELDS
##########################################################################
numberOfClusters = int(sys.argv[1])
shapeFilePath =  sys.argv[2]
##########################################################################
# CREATE GRAPH USING THE SHAPE FILE
##########################################################################
larissa =  nx.DiGraph.to_undirected(nx.read_shp(shapeFilePath))#forNetX
#Initializing NSF
set_new_attribute_to_nodes(larissa,'population',-1.0)
set_new_attribute_to_nodes(larissa,'building_i',-1)
set_new_attribute_to_nodes(larissa,'block_id',-1)
set_new_attribute_to_nodes(larissa,'manhole',-1)

change_length_attr(larissa)
# num correspnd to the total number of buildings
num = find_building_edges_and_update_nodes(larissa)

restore_attributes(larissa)
check = [nod for nod in larissa.degree() if larissa.degree(nod) > 1 and larissa.node[nod]['population'] != -1]
#Initialize Main Graph G
G = larissa.copy()
population_to_int(G)

##########################################################################
# EXECUTE CLUSTERING ALGORITHM: equal masses
##########################################################################
#cls00 = akcom0_fixed(G,kk)[:] # the function is deleted from all_functions.py (exists in backup dropbox - all_caps.py)
#cls00 = akcom0_smsms_fixed(G,kk)[:] # the function is deleted from all_functions.py (exists in backup dropbox - all_caps.py)
cls00 = akcom0_smsms_fixed_norm(G,numberOfClusters) #equal masses
cls000 = norm_akcom0_smsms_fixed_norm(cls00,numberOfClusters)
l = print_mass(G,cls000)[:] # Is a list with the population of each Cluster
populationPerCluster = l
print(populationPerCluster)
mplith = akcom0_smsms_fixed_norm_max_mass_only(G,numberOfClusters) #1976

# Execute prepare_shapefile() function
G = prepare_shapefile(shapeFilePath,numberOfClusters)

##########################################################################
# RETRIEVE THE NUMBER OF BUILDINGS IN EACH CLUSTER AND SAVE THEM IN LIST
########################################################################## 
buildingsPerCluster = []
for x in range(0,numberOfClusters): 
    G_sub = G.subgraph(cls000[x])
    sumOfBuildings = 0
    for x in G_sub:
        if (G_sub.node[x]['building_i']<>-1):
            sumOfBuildings = sumOfBuildings+1
    buildingsPerCluster.append(sumOfBuildings)
print buildingsPerCluster

# Create csv file and save the outputs
with open('python/csv/outputMetrics.csv', 'w') as fp:
    writer = csv.writer(fp, delimiter=';')
    writer.writerow(["populationPerCluster", populationPerCluster])
    writer.writerow(["buildingsPerCluster",buildingsPerCluster])
  
 
##########################################################################
# CREATE SHAPEFILE WITH ALL THE CLUSTERS
########################################################################## 
for numberOfClusters in range(0,numberOfClusters): 
	# d: set the attribute "cluster" in each node and a value of the corresponding cluster that 
	#the node belongs
	set_new_attribute_to_nodes(G.subgraph(cls000[numberOfClusters]),'cluster',numberOfClusters) 
shapefile_edges = 'clusterEdges_'
shapefile_nodes = 'clusterNodes_'
write_shp(G,'python/output/cluster',shapefile_nodes,shapefile_edges)
##########################################################################
# Save the cluster coordinates in order to load it later in distributionNetModule.py
##########################################################################
with open('python/tmp/clusterCoords.txt', 'wb') as f:
	pickle.dump(cls000, f)

# Return Data to PHP
#print cls000



