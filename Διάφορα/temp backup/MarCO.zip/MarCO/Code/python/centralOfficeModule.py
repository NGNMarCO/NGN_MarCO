####################################################################################################
# 1) RUN BEST CENTRAL OFFICE FUNCTION IN ORDER TO FIND THE BEST LOCATION TO PLACE THE CO NODE
# 2) RUN FEEDER_STUFF TO GET SHAPE FILES WITH EDGES/NODES AND PRINT COSTS
####################################################################################################
####################################################################################################
# IMPORT LIBS AND FILES
##########################################################################

import networkx as nx
import timeit
import csv
import sys # read variables passed from PHP exec
import json # convert a string to list of lists
import pickle

from all_functions import (set_new_attribute_to_nodes,change_length_attr,find_building_edges_and_update_nodes,restore_attributes,population_to_int,
akcom0_smsms_fixed_norm,norm_akcom0_smsms_fixed_norm,print_mass,akcom0_smsms_fixed_norm_max_mass_only,find_best_dhn,alphas_distribution,omhns_cl_def,
mhns_cost_d,cluster_invs_dummy22,cluster_to_subready,find_best_CO,alphas_feeder,write_shp,prepare_shapefile)

##########################################################################
# GET THE INPUTS FROM TEXTFIELDS
##########################################################################
numberOfClusters = int(sys.argv[1])
shapeFilePath =  sys.argv[2]
cap_list_feed = json.loads("["+sys.argv[3]+"]")
cap_list_cost_feed = json.loads("["+sys.argv[4]+"]")
CO_cost = int(sys.argv[5]) # INPUT - THE COST OF THE KV
lmin_co = int(sys.argv[6]) # MIN DISTANCE TO PLACE MANHOLE
lmax_co = int(sys.argv[7]) # MAX DISTANCE TO PLACE MANHOLE
mhn_cost = json.loads(sys.argv[8]) # COST OF MANHOLES BASED ON STRATEGY
mhn_c_l =  json.loads(sys.argv[9])  # PARAMETERS FOR MANHOLE STRATEGY/NEW COST OF MAHOLE/LOW COST/HIGH COST MANHOLE
d =  int(sys.argv[10]) # TYPE OF STRATEGY TO BE USED FOR THE MANHOLES - VALUES: {3, 2, 1, 32, 31, 21, 321}


rr = 0.1


##########################################################################
# GET THE CLUSTER COORDINATES FROM TEXT FILE
##########################################################################
with open('python/tmp/clusterCoords.txt' ,'rb') as f:
	cls000 = pickle.load(f)
##########################################################################
# CREATE GRAPH USING THE SHAPE FILE
##########################################################################
larissa =  nx.DiGraph.to_undirected(nx.read_shp(shapeFilePath))#forNetX
#Initializing NSF
set_new_attribute_to_nodes(larissa,'population',-1.0)
set_new_attribute_to_nodes(larissa,'building_i',-1)
set_new_attribute_to_nodes(larissa,'block_id',-1)
set_new_attribute_to_nodes(larissa,'manhole',-1)

change_length_attr(larissa)
num = find_building_edges_and_update_nodes(larissa)
restore_attributes(larissa)
check = [nod for nod in larissa.degree() if larissa.degree(nod) > 1 and larissa.node[nod]['population'] != -1]

#Initialize Main Graph G
G = larissa.copy()
population_to_int(G)
##############################################################################
#RUN


l = print_mass(G,cls000)[:]
mplith = akcom0_smsms_fixed_norm_max_mass_only(G,numberOfClusters) #1976
   
##########################################################################
# EXECUTE best_CO.py - FIND BEST LOCATION TO LOCATE CENTRAL OFFICE
########################################################################## 


#About DHNs and CO input
#list_all_dhn_info = [[365238.936628, 4385304.4983749995, 1570]]
    


##########################################################################
# GET THE dhns AND dhns_info FROM TEXT FILE
##########################################################################
with open('python/tmp/dhns.txt' ,'rb') as f:
	dhns = pickle.load(f)  

with open('python/tmp/dhns_info.txt' ,'rb') as g:
	dhns_info = pickle.load(g)


print dhns
print dhns_info
#dhns =  [(365238.936628, 4385304.4983749995),(364967.530378, 4385309.4983749995) ]
#dhns_info =  [[365238.936628, 4385304.4983749995, 1558], [364967.530378, 4385309.4983749995, 3200]]

#dhns =  [(365356.561628, 4385334.998374), (364961.936628, 4385150.4983749995), (365203.811627, 4385476.498374), (365058.374128, 4385184.9983749995), (364830.217878, 4385386.9983749995)]
#dhns_info =  [[365356.561628, 4385334.998374, 770], [364961.936628, 4385150.4983749995, 848], [365203.811627, 4385476.498374, 904], [365058.374128, 4385184.9983749995, 856], [364830.217878, 4385386.9983749995, 1380]] 

#dhns = [(365356.561628, 4385334.998374), (365067.061627, 4385448.498374), (365024.061628, 4385173.4983749995), (364843.092878, 4385311.4983749995)]
#dhns_info = [[365356.561628, 4385334.998374, 910], [365067.061627, 4385448.498374, 1006], [365024.061628, 4385173.4983749995, 990], [364843.092878, 4385311.4983749995, 1852]]

#d = 2 #The possible values are {3, 2, 1, 32, 31, 21, 321}
#mhn_c_l =  [0,1,0,0,0,0,1,0]

fbCO = find_best_CO(G,dhns,dhns_info,rr,cap_list_feed,cap_list_cost_feed)

cap_list = cap_list_feed[:]
print cap_list
cap_list_cost = cap_list_cost_feed[:]
comP_dhns = fbCO[0] #best one taken from best_CO.py
print comP_dhns
# Create an array which contains the number of splices for each KV (taken by input array: dhns_info)
dhns_splices = []
s = 0
for i in range(len(dhns_info)):
    s = s + dhns_info[i][2]
dhns_splices.append([comP_dhns,s])
for i in range(len(dhns)):
    dhns_splices.append([dhns[i],dhns_info[i][2]])

###############################################################################

############################### Feeder Run ####################################
###############################################################################
shapeFileNameCoOne = "CentralOffice1"
shapeFileNameCoTwo = "CentralOffice2"


ath_co = alphas_feeder(G,comP_dhns,dhns,dhns_splices,dhns_info,lmin_co,lmax_co,d,cap_list,cap_list_cost,cap_list_feed,cap_list_cost_feed,shapeFileNameCoOne,shapeFileNameCoTwo,shapeFilePath)
omhns_cl_co = omhns_cl_def(ath_co[1]) # definition explained in all_functions.py
print omhns_cl_co
mhns_costing_co = mhns_cost_d(ath_co[0],mhn_c_l,mhn_cost,omhns_cl_co,d) # definition explained in all_functions.py
print mhns_costing_co
bomd_co = ath_co[2][:]
gx_final = ath_co[0].copy()
out_feeder = [ath_co[2][3],ath_co[2][2],omhns_cl_co, mhns_costing_co]
###############################################################################

############################# Feeder Output ###################################
###############################################################################
cost_net = bomd_co[2][1] + mhns_costing_co + CO_cost


# Append more outputs in csv file
with open('python/csv/outputMetrics.csv', 'a') as fp:
	writer = csv.writer(fp, delimiter=';')
	writer.writerow(["Central Office"])
	writer.writerow(["Length of f/c Grans (m)", str(cap_list_feed[0]) + " is: " + str(bomd_co[3][0][0])])
	writer.writerow(["Length of s/d Grans (m)", str(cap_list_feed[2]) + " is: " + str(bomd_co[3][1][0])])
	writer.writerow(["Length of d Grans (m)", str(cap_list_feed[3]) + " is: " + str(bomd_co[3][2][0])])
	writer.writerow(["Unit Costs", str(cap_list_cost_feed)])   
	writer.writerow(["Total Feeder Network Length (m)", str(bomd_co[2][0])])
	writer.writerow(["Total Feeder Network Cost ($)",  str(bomd_co[2][1] + mhns_costing_co + CO_cost)])
	writer.writerow(["Total Feeder Network Trench Cost ($)", str(bomd_co[2][2])])
	writer.writerow(["Total Feeder Network Gran Cost ($)", str(bomd_co[2][3])])
	writer.writerow(["Number of Manholes Oneway", str(omhns_cl_co[0])])
	writer.writerow(["Number of Manholes Twoway", str(omhns_cl_co[1])])
	writer.writerow(["Number of Manholes Threeway", str(omhns_cl_co[2])])
	writer.writerow(["Number of New Manholes", str(omhns_cl_co[3])])
	writer.writerow(["Manholes Cost ($)", str(mhns_costing_co)])
	writer.writerow(["Number of Splices in CO", str(gx_final.node[comP_dhns]['#splices'])])
	writer.writerow(["CO cost", str(CO_cost)])
	for n in dhns: 
		writer.writerow(["Number of Splices in DHNs",str(gx_final.node[n]['#splices'])])
		
