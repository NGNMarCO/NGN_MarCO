

all_function.py: contains all the python definitions written by Thanasis and used to do the clustering, 
the network designing, output the shape files etc.

main.py: the code is currently executed through this file. 
Next steps: to seperate into modules the functions in main file so its possible to execute them seperately.
